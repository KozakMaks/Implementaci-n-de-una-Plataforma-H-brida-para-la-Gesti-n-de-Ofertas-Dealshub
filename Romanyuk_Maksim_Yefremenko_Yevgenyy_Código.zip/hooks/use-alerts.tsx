"use client"

import { useState, useEffect } from "react"
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  updateDoc,
  doc,
  getDocs,
  type Timestamp, // Ensure Timestamp is imported
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
// No need to import Alert from "@/types" if it's defined locally

// Define Alert interface locally or ensure it's correctly imported if defined globally
export interface Alert {
  id: string
  userId: string // User to whom the alert belongs
  type:
    | "comment" // Generic comment, might be deprecated in favor of specific ones
    | "vote" // Generic vote, might be deprecated
    | "deal" // Generic deal alert
    | "message" // Private message
    | "chat_request" // Chat request
    | "deal_comment_own" // Comment on user's own deal
    | "deal_vote_own" // Vote on user's own deal
    | "subscribed_deal_comment" // Comment on a deal the user follows/subscribed to
  content: string
  relatedId?: string // e.g., dealId, chatId
  relatedSubId?: string // e.g., commentId
  createdAt: Timestamp // Firestore Timestamp
  read: boolean
  triggeringUserId?: string // User who triggered the alert
  triggeringUserName?: string
  dealTitle?: string // Denormalized deal title
}

export function useAlerts(limitCount = 10) {
  const { user } = useAuth()
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Fetch alerts for the current user
  useEffect(() => {
    if (!user) {
      setAlerts([])
      setUnreadCount(0)
      setLoading(false)
      return
    }

    setLoading(true)
    const q = query(
      collection(db, "alerts"),
      where("userId", "==", user.uid),
      orderBy("createdAt", "desc"),
      limit(limitCount),
    )

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const alertsData: Alert[] = []
        let unread = 0

        snapshot.forEach((doc) => {
          // Ensure data matches the Alert interface, especially createdAt
          const data = doc.data()
          const alert: Alert = {
            id: doc.id,
            userId: data.userId,
            type: data.type,
            content: data.content,
            relatedId: data.relatedId,
            relatedSubId: data.relatedSubId,
            createdAt: data.createdAt, // This should be a Firestore Timestamp
            read: data.read,
            triggeringUserId: data.triggeringUserId,
            triggeringUserName: data.triggeringUserName,
            dealTitle: data.dealTitle,
          }
          alertsData.push(alert)
          if (!alert.read) unread++
        })

        setAlerts(alertsData)
        setUnreadCount(unread)
        setLoading(false)
        setError(null)
      },
      (err) => {
        console.error("Error fetching alerts:", err)
        setError("Failed to load notifications")
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [user, limitCount])

  // Mark a single alert as read
  const markAlertAsRead = async (alertId: string) => {
    if (!user) return

    try {
      const alertRef = doc(db, "alerts", alertId)
      await updateDoc(alertRef, {
        read: true,
      })
      // Optimistically update local state
      setAlerts((prevAlerts) =>
        prevAlerts.map((alert) => (alert.id === alertId ? { ...alert, read: true } : alert)),
      )
      setUnreadCount((prev) => (prev > 0 ? prev - 1 : 0))
    } catch (error) {
      console.error("Error marking alert as read:", error)
    }
  }

  // Mark all alerts as read
  const markAllAsRead = async () => {
    if (!user) return

    try {
      const q = query(collection(db, "alerts"), where("userId", "==", user.uid), where("read", "==", false))

      const snapshot = await getDocs(q)
      const batch = snapshot.docs.map((docToUpdate) => updateDoc(docToUpdate.ref, { read: true }))
      await Promise.all(batch)
      // Optimistically update local state
      setAlerts((prevAlerts) => prevAlerts.map((alert) => ({ ...alert, read: true })))
      setUnreadCount(0)
    } catch (error) {
      console.error("Error marking all alerts as read:", error)
    }
  }

  return {
    alerts,
    unreadCount,
    loading,
    error,
    markAlertAsRead,
    markAllAsRead,
  }
}
