"use client"

import { useState, useEffect, useCallback } from "react"
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  getDoc,
  getDocs,
  doc,
  serverTimestamp,
  increment,
  Timestamp,
} from "firebase/firestore"
import { db } from "@/lib/firebase" // storage will be used from here if needed by an upload function
import { useAuth } from "@/hooks/use-auth"
import type { Conversation, Message, ChatRequest, User } from "@/types"

export function useChat() {
  const { user } = useAuth()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [chatRequests, setChatRequests] = useState<ChatRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Fetch conversations for the current user
  useEffect(() => {
    if (!user) {
      setConversations([])
      setLoading(false)
      return
    }

    setLoading(true)
    const q = query(
      collection(db, "conversations"),
      where("participants", "array-contains", user.uid),
      orderBy("updatedAt", "desc"),
    )

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const conversationsData: Conversation[] = []
        snapshot.forEach((doc) => {
          conversationsData.push({ id: doc.id, ...doc.data() } as Conversation)
        })
        setConversations(conversationsData)
        setLoading(false)
        setError(null)
      },
      (err) => {
        console.error("Error fetching conversations:", err)
        setError("Failed to load conversations")
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [user])

  // Fetch chat requests for the current user
  useEffect(() => {
    if (!user) {
      setChatRequests([])
      return
    }

    const q = query(
      collection(db, "chatRequests"),
      where("receiverId", "==", user.uid),
      where("status", "==", "pending"),
      orderBy("createdAt", "desc"),
    )

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const requestsData: ChatRequest[] = []
        snapshot.forEach((doc) => {
          requestsData.push({ id: doc.id, ...doc.data() } as ChatRequest)
        })
        setChatRequests(requestsData)
      },
      (err) => {
        console.error("Error fetching chat requests:", err)
      },
    )

    return () => unsubscribe()
  }, [user])

  // Get messages for a specific conversation
  const getMessages = useCallback(
    (conversationId: string, callback: (messages: Message[]) => void) => {
      if (!user || !conversationId) return () => {}

      const q = query(
        collection(db, "messages"),
        where("conversationId", "==", conversationId),
        orderBy("createdAt", "asc"),
      )

      return onSnapshot(
        q,
        (snapshot) => {
          const messagesData: Message[] = []
          snapshot.forEach((doc) => {
            messagesData.push({ id: doc.id, ...doc.data() } as Message)
          })
          callback(messagesData)
        },
        (err) => {
          console.error("Error fetching messages:", err)
        },
      )
    },
    [user],
  )

  // Send a message in a conversation
  const sendMessage = useCallback(
    async (conversationId: string, receiverId: string, content: string, imageUrl?: string) => {
      if (!user || (!content.trim() && !imageUrl)) return null

      try {
        const messageData: any = {
          conversationId,
          senderId: user.uid,
          receiverId,
          content: content.trim(),
          createdAt: serverTimestamp(),
          read: false,
        }
        if (imageUrl) {
          messageData.imageUrl = imageUrl
          if (!content.trim()) {
            // If only image, set content to placeholder
            messageData.content = "[Imagen]"
          }
        }

        const messageRef = await addDoc(collection(db, "messages"), messageData)

        // Create an alert for the receiver
        const alertContent = imageUrl
          ? `${user.displayName || "Alguien"} te envió una imagen.`
          : `${user.displayName || "Alguien"}: ${content.substring(0, 30)}${content.length > 30 ? "..." : ""}`

        await addDoc(collection(db, "alerts"), {
          userId: receiverId,
          type: "message",
          content: alertContent,
          relatedId: conversationId,
          createdAt: serverTimestamp(),
          read: false,
        })

        // Update conversation with last message
        const conversationRef = doc(db, "conversations", conversationId)
        await updateDoc(conversationRef, {
          lastMessage: messageData.content, // Use the potentially modified content
          lastMessageTime: serverTimestamp(),
          updatedAt: serverTimestamp(),
          [`unreadCount.${receiverId}`]: increment(1),
        })

        return messageRef.id
      } catch (error) {
        console.error("Error sending message:", error)
        return null
      }
    },
    [user],
  )

  // Mark messages as read
  const markMessagesAsRead = useCallback(
    async (conversationId: string) => {
      if (!user || !conversationId) return

      try {
        // Update conversation unread count
        const conversationRef = doc(db, "conversations", conversationId)
        await updateDoc(conversationRef, {
          [`unreadCount.${user.uid}`]: 0,
        })

        // Mark messages as read
        const q = query(
          collection(db, "messages"),
          where("conversationId", "==", conversationId),
          where("receiverId", "==", user.uid),
          where("read", "==", false),
        )

        const snapshot = await getDocs(q)
        const batchUpdates = snapshot.docs.map((messageDoc) => updateDoc(messageDoc.ref, { read: true }))
        await Promise.all(batchUpdates)
      } catch (error) {
        console.error("Error marking messages as read:", error)
      }
    },
    [user],
  )

  // Send a chat request to another user
  const sendChatRequest = useCallback(
    async (receiverId: string, message: string) => {
      if (!user || !message.trim()) return null

      try {
        const q = query(collection(db, "conversations"), where("participants", "array-contains", user.uid))
        const snapshot = await getDocs(q)
        let existingConversation: Conversation | null = null
        snapshot.forEach((doc) => {
          const conversation = doc.data() as Conversation
          if (conversation.participants.includes(receiverId)) {
            existingConversation = { id: doc.id, ...conversation }
          }
        })

        if (existingConversation) {
          await sendMessage(existingConversation.id, receiverId, message)
          return { type: "existing", conversationId: existingConversation.id }
        }

        const userDoc = await getDoc(doc(db, "users", user.uid))
        const userData = userDoc.data() as User

        const chatRequestRef = await addDoc(collection(db, "chatRequests"), {
          senderId: user.uid,
          senderName: userData.displayName || user.email?.split("@")[0] || "User",
          senderPhotoURL: user.photoURL || null,
          receiverId,
          message,
          status: "pending",
          createdAt: serverTimestamp(),
        })

        await addDoc(collection(db, "alerts"), {
          userId: receiverId,
          type: "chat_request",
          content: `${userData.displayName || "Alguien"} quiere chatear contigo`,
          relatedId: chatRequestRef.id,
          createdAt: serverTimestamp(),
          read: false,
        })

        return { type: "request", requestId: chatRequestRef.id }
      } catch (error) {
        console.error("Error sending chat request:", error)
        return null
      }
    },
    [user, sendMessage],
  )

  // Handle a chat request (accept or decline)
  const handleChatRequest = useCallback(
    async (requestId: string, accept: boolean) => {
      if (!user) return null

      try {
        const requestRef = doc(db, "chatRequests", requestId)
        const requestDoc = await getDoc(requestRef)
        if (!requestDoc.exists()) throw new Error("Chat request not found")
        const request = requestDoc.data() as ChatRequest

        await updateDoc(requestRef, { status: accept ? "accepted" : "declined" })

        if (accept) {
          const [senderDoc, receiverDoc] = await Promise.all([
            getDoc(doc(db, "users", request.senderId)),
            getDoc(doc(db, "users", request.receiverId)),
          ])
          const senderData = senderDoc.data() as User
          const receiverData = receiverDoc.data() as User

          const conversationRef = await addDoc(collection(db, "conversations"), {
            participants: [request.senderId, request.receiverId],
            participantsInfo: {
              [request.senderId]: {
                displayName: senderData.displayName || "User",
                photoURL: senderData.photoURL || null,
              },
              [request.receiverId]: {
                displayName: receiverData.displayName || "User",
                photoURL: receiverData.photoURL || null,
              },
            },
            lastMessage: request.message,
            lastMessageTime: Timestamp.now(),
            unreadCount: { [request.senderId]: 0, [request.receiverId]: 1 },
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })

          await addDoc(collection(db, "alerts"), {
            userId: request.senderId,
            type: "message",
            content: `${receiverData.displayName || "Alguien"} aceptó tu solicitud de chat`,
            relatedId: conversationRef.id,
            createdAt: serverTimestamp(),
            read: false,
          })

          await addDoc(collection(db, "messages"), {
            conversationId: conversationRef.id,
            senderId: request.senderId,
            receiverId: request.receiverId,
            content: request.message,
            createdAt: serverTimestamp(), // Use serverTimestamp for consistency
            read: false,
          })
          return conversationRef.id
        }
        return null
      } catch (error) {
        console.error("Error handling chat request:", error)
        return null
      }
    },
    [user],
  )

  const createConversation = useCallback(
    async (otherUserId: string, initialMessage: string) => {
      if (!user || !initialMessage.trim()) return null

      try {
        const q = query(collection(db, "conversations"), where("participants", "array-contains", user.uid))
        const snapshot = await getDocs(q)
        let existingConversation: Conversation | null = null
        snapshot.forEach((doc) => {
          const conversation = doc.data() as Conversation
          if (conversation.participants.includes(otherUserId)) {
            existingConversation = { id: doc.id, ...conversation }
          }
        })

        if (existingConversation) {
          await sendMessage(existingConversation.id, otherUserId, initialMessage)
          return existingConversation.id
        }

        const [currentUserDoc, otherUserDoc] = await Promise.all([
          getDoc(doc(db, "users", user.uid)),
          getDoc(doc(db, "users", otherUserId)),
        ])
        const currentUserData = currentUserDoc.data() as User
        const otherUserData = otherUserDoc.data() as User

        const conversationRef = await addDoc(collection(db, "conversations"), {
          participants: [user.uid, otherUserId],
          participantsInfo: {
            [user.uid]: {
              displayName: currentUserData.displayName || "User",
              photoURL: currentUserData.photoURL || null,
            },
            [otherUserId]: {
              displayName: otherUserData.displayName || "User",
              photoURL: otherUserData.photoURL || null,
            },
          },
          lastMessage: initialMessage,
          lastMessageTime: Timestamp.now(),
          unreadCount: { [user.uid]: 0, [otherUserId]: 1 },
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        })

        await addDoc(collection(db, "messages"), {
          conversationId: conversationRef.id,
          senderId: user.uid,
          receiverId: otherUserId,
          content: initialMessage,
          createdAt: serverTimestamp(),
          read: false,
        })
        return conversationRef.id
      } catch (error) {
        console.error("Error creating conversation:", error)
        return null
      }
    },
    [user, sendMessage],
  )

  return {
    conversations,
    chatRequests,
    loading,
    error,
    getMessages,
    sendMessage,
    markMessagesAsRead,
    sendChatRequest,
    handleChatRequest,
    createConversation,
  }
}
