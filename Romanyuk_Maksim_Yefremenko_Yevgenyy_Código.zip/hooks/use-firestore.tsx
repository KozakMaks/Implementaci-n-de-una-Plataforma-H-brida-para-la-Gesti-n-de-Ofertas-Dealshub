"use client"

import { useState, useEffect } from "react"
import {
  collection,
  query,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  serverTimestamp,
  type DocumentData,
  type QueryConstraint,
} from "firebase/firestore"
import { db } from "@/lib/firebase"

// Get a collection with real-time updates
export const useCollection = (collectionName: string, constraints: QueryConstraint[] = [], deps: any[] = []) => {
  const [documents, setDocuments] = useState<DocumentData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (constraints.length === 0 && collectionName !== "users") {
      // Skip empty queries except for users collection
      setDocuments([])
      setLoading(false)
      return () => {}
    }

    setLoading(true)

    try {
      const q = query(collection(db, collectionName), ...constraints)

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const results: DocumentData[] = []
          snapshot.forEach((doc) => {
            results.push({ id: doc.id, ...doc.data() })
          })
          setDocuments(results)
          setLoading(false)
          setError(null)
        },
        (err) => {
          console.error("Error fetching collection:", err)
          setError("Failed to fetch data. Please try again later.")
          setLoading(false)
          setDocuments([])
        },
      )

      return () => unsubscribe()
    } catch (err) {
      console.error("Error setting up collection query:", err)
      setError("Failed to set up data query. Please try again later.")
      setLoading(false)
      setDocuments([])
      return () => {}
    }
  }, [...deps])

  return { documents, loading, error }
}

// Get a document with real-time updates
export const useDocument = (collectionName: string, docId: string, deps: any[] = []) => {
  const [document, setDocument] = useState<DocumentData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!docId) {
      setDocument(null)
      setLoading(false)
      return
    }

    setLoading(true)
    const docRef = doc(db, collectionName, docId)

    const unsubscribe = onSnapshot(
      docRef,
      (doc) => {
        if (doc.exists()) {
          setDocument({ id: doc.id, ...doc.data() })
        } else {
          setDocument(null)
        }
        setLoading(false)
        setError(null)
      },
      (err) => {
        console.error("Error fetching document:", err)
        setError("Failed to fetch document")
        setLoading(false)
      },
    )

    return () => unsubscribe()
  }, [collectionName, docId, ...deps])

  return { document, loading, error }
}

// Add a document to a collection
export const addDocument = async (collectionName: string, data: any) => {
  try {
    const docRef = await addDoc(collection(db, collectionName), {
      ...data,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
    return { id: docRef.id }
  } catch (error) {
    console.error("Error adding document:", error)
    throw error
  }
}

// Update a document
export const updateDocument = async (collectionName: string, docId: string, data: any) => {
  try {
    const docRef = doc(db, collectionName, docId)
    await updateDoc(docRef, {
      ...data,
      updatedAt: serverTimestamp(),
    })
    return true
  } catch (error) {
    console.error("Error updating document:", error)
    throw error
  }
}

// Delete a document
export const deleteDocument = async (collectionName: string, docId: string) => {
  try {
    const docRef = doc(db, collectionName, docId)
    await deleteDoc(docRef)
    return true
  } catch (error) {
    console.error("Error deleting document:", error)
    throw error
  }
}
