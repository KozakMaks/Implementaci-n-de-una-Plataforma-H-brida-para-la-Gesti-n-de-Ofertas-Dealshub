"use client"

import { useState, useEffect } from "react"
import { collection, doc, getDoc, getDocs, query, where, updateDoc, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"

// Define the available roles in the system
export type UserRole = "user" | "moderator" | "admin"

export function useRoles(userId: string | null | undefined) {
  const [role, setRole] = useState<UserRole>("user")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Check and update role whenever userId changes
  useEffect(() => {
    if (!userId) {
      setRole("user")
      setLoading(false)
      return
    }

    setLoading(true)

    // Check if user is in superAdmins collection first
    const checkAdminStatus = async () => {
      try {
        const adminDocRef = doc(db, "superAdmins", userId)
        const adminDoc = await getDoc(adminDocRef)

        if (adminDoc.exists() && adminDoc.data().role === "admin") {
          setRole("admin")

          // Update user document with admin role
          const userRef = doc(db, "users", userId)
          const userDoc = await getDoc(userRef)

          if (userDoc.exists()) {
            // Only update if different
            if (userDoc.data().role !== "admin") {
              await updateDoc(userRef, { role: "admin" })
            }
          }

          setLoading(false)
          return true
        }
        return false
      } catch (err) {
        console.error("Error checking admin status:", err)
        return false
      }
    }

    // Check if user is a moderator based on upvotes
    const checkModeratorStatus = async () => {
      try {
        // Get user document to check current role
        const userRef = doc(db, "users", userId)
        const userDoc = await getDoc(userRef)

        if (userDoc.exists()) {
          // If user is already an admin, don't change their role
          if (userDoc.data().role === "admin") {
            setRole("admin")
            setLoading(false)
            return
          }

          // Get all deals from this user
          const q = query(collection(db, "deals"), where("publisherId", "==", userId))
          const dealsSnapshot = await getDocs(q)

          // Calculate total upvotes across all deals
          let totalUpvotes = 0
          dealsSnapshot.forEach((dealDoc) => {
            totalUpvotes += dealDoc.data().upvotes || 0
          })

          // Check if user should be promoted to moderator
          if (totalUpvotes >= 100) {
            // Check if role needs to be updated
            if (userDoc.data().role !== "moderator") {
              await updateDoc(userRef, { role: "moderator" })
            }
            setRole("moderator")
          } else {
            // Set role to current role or default to "user"
            setRole(userDoc.data().role || "user")
          }
        } else {
          // Default to user if user document doesn't exist yet
          setRole("user")
        }

        setLoading(false)
      } catch (err) {
        console.error("Error checking moderator status:", err)
        setError("Failed to check user role")
        setLoading(false)
      }
    }

    // First check if admin, then check for moderator if not admin
    const checkRole = async () => {
      const isAdmin = await checkAdminStatus()
      if (!isAdmin) {
        await checkModeratorStatus()
      }
    }

    checkRole()

    // Set up a listener for upvotes changes
    // This way, when a user's deals receive upvotes, their role is automatically updated
    const unsubscribe = onSnapshot(
      query(collection(db, "deals"), where("publisherId", "==", userId)),
      async () => {
        // When deals change (like upvotes), recheck moderator status
        // Skip if user is already an admin (admins shouldn't downgrade)
        if (role !== "admin") {
          await checkModeratorStatus()
        }
      },
      (err) => {
        console.error("Error listening to deals changes:", err)
      },
    )

    return () => unsubscribe()
  }, [userId, role])

  return { role, loading, error }
}
