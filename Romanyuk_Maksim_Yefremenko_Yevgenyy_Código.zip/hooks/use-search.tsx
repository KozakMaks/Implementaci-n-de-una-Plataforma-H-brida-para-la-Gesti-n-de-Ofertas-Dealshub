"use client"

import { useState, useEffect } from "react"
import {
  collection,
  query,
  orderBy,
  limit,
  getDocs,
  startAfter,
  type DocumentData,
  type QueryDocumentSnapshot,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Deal } from "@/types"

export function useSearch(searchQuery: string, pageSize = 12) {
  const [deals, setDeals] = useState<Deal[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [lastVisible, setLastVisible] = useState<QueryDocumentSnapshot<DocumentData> | null>(null)

  // Function to search deals
  const searchDeals = async (isLoadMore = false) => {
    if (!searchQuery.trim()) {
      setDeals([])
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Create a query to search deals
      // We'll search in title and description fields
      const searchTerms = searchQuery
        .toLowerCase()
        .split(" ")
        .filter((term) => term.length > 0)

      if (searchTerms.length === 0) {
        setDeals([])
        setLoading(false)
        return
      }

      // Create base query
      let q = query(collection(db, "deals"), orderBy("title"), limit(pageSize))

      // If loading more, start after the last visible document
      if (isLoadMore && lastVisible) {
        q = query(collection(db, "deals"), orderBy("title"), startAfter(lastVisible), limit(pageSize))
      }

      const querySnapshot = await getDocs(q)

      // Filter results client-side based on search terms
      const results: Deal[] = []
      querySnapshot.forEach((doc) => {
        const deal = { id: doc.id, ...doc.data() } as Deal

        // Check if any search term is in the title or description
        const matchesSearch = searchTerms.some(
          (term) =>
            deal.title.toLowerCase().includes(term) ||
            (deal.description && deal.description.toLowerCase().includes(term)),
        )

        if (matchesSearch) {
          results.push(deal)
        }
      })

      // Update last visible document for pagination
      const lastDoc = querySnapshot.docs[querySnapshot.docs.length - 1]
      setLastVisible(lastDoc)
      setHasMore(querySnapshot.docs.length === pageSize)

      // Update deals state
      if (isLoadMore) {
        setDeals((prevDeals) => [...prevDeals, ...results])
      } else {
        setDeals(results)
      }
    } catch (err) {
      console.error("Error searching deals:", err)
      setError("Error al buscar chollos. Por favor, inténtalo de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  // Load deals when search query changes
  useEffect(() => {
    searchDeals()
  }, [searchQuery])

  const loadMore = () => {
    searchDeals(true)
  }

  return { deals, loading, error, hasMore, loadMore }
}
