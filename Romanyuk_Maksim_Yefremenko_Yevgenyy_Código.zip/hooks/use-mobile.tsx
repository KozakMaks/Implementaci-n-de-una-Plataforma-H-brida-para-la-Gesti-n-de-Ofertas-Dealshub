"use client" // Ensure this is at the top if not already present for client-side hooks
import { useState, useEffect } from "react"

export function useMobile(query = "(max-width: 767px)"): boolean {
  const [matches, setMatches] = useState(false)

  useEffect(() => {
    // Ensure window is defined (runs only on client-side)
    if (typeof window === "undefined") {
      return
    }

    const mediaQueryList = window.matchMedia(query)
    const listener = () => setMatches(mediaQueryList.matches)

    listener() // Set initial state
    mediaQueryList.addEventListener("change", listener)

    return () => mediaQueryList.removeEventListener("change", listener)
  }, [query])

  return matches
}
