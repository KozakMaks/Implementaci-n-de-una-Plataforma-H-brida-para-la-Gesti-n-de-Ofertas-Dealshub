"use client"

import { useState, useEffect } from "react"
import {
  collection,
  query,
  where,
  getDocs,
  addDoc,
  deleteDoc,
  doc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"

export type VoteType = "up" | "down" | null

export function useVotes(dealId: string) {
  const { user } = useAuth()
  const [currentVote, setCurrentVote] = useState<VoteType>(null)
  const [voteId, setVoteId] = useState<string | null>(null)
  const [isVoting, setIsVoting] = useState(false)
  const [voteCount, setVoteCount] = useState({ upvotes: 0, downvotes: 0 })
  const [loading, setLoading] = useState(true)

  // Fetch the current user's vote
  useEffect(() => {
    const fetchUserVote = async () => {
      if (!user || !dealId) {
        setLoading(false)
        return
      }

      try {
        const q = query(collection(db, "votes"), where("userId", "==", user.uid), where("dealId", "==", dealId))

        const snapshot = await getDocs(q)

        if (!snapshot.empty) {
          const voteDoc = snapshot.docs[0]
          const voteData = voteDoc.data()
          setCurrentVote(voteData.voteType as VoteType)
          setVoteId(voteDoc.id)
        } else {
          setCurrentVote(null)
          setVoteId(null)
        }
      } catch (error) {
        console.error("Error fetching vote status:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUserVote()
  }, [user, dealId])

  // Fetch total vote counts
  useEffect(() => {
    const fetchVoteCounts = async () => {
      if (!dealId) return

      try {
        const upvoteQuery = query(collection(db, "votes"), where("dealId", "==", dealId), where("voteType", "==", "up"))

        const downvoteQuery = query(
          collection(db, "votes"),
          where("dealId", "==", dealId),
          where("voteType", "==", "down"),
        )

        const upvoteSnapshot = await getDocs(upvoteQuery)
        const downvoteSnapshot = await getDocs(downvoteQuery)

        setVoteCount({
          upvotes: upvoteSnapshot.size,
          downvotes: downvoteSnapshot.size,
        })

        // Update the deal document with the latest vote counts
        const dealRef = doc(db, "deals", dealId)
        await updateDoc(dealRef, {
          upvotes: upvoteSnapshot.size,
          downvotes: downvoteSnapshot.size,
          updatedAt: serverTimestamp(),
        })
      } catch (error) {
        console.error("Error fetching vote counts:", error)
      }
    }

    fetchVoteCounts()
  }, [dealId, currentVote])

  const handleVote = async (voteType: VoteType) => {
    if (!user || isVoting || !dealId) return

    setIsVoting(true)

    try {
      if (currentVote === voteType) {
        // User is removing their vote
        if (voteId) {
          await deleteDoc(doc(db, "votes", voteId))
          setCurrentVote(null)
          setVoteId(null)
        }
      } else {
        // User is changing their vote or voting for the first time
        if (voteId) {
          // Update existing vote
          await updateDoc(doc(db, "votes", voteId), {
            voteType,
            updatedAt: serverTimestamp(),
          })
        } else {
          // Create new vote
          const voteRef = await addDoc(collection(db, "votes"), {
            dealId,
            userId: user.uid,
            voteType,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          })
          setVoteId(voteRef.id)
        }
        setCurrentVote(voteType)
      }
    } catch (error) {
      console.error("Error handling vote:", error)
    } finally {
      setIsVoting(false)
    }
  }

  return {
    currentVote,
    voteCount,
    isVoting,
    loading,
    handleVote,
  }
}
