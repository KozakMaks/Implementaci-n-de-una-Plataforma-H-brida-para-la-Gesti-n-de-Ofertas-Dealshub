"use client"

import { useState, useEffect } from "react"
import { doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"

export function useUserData(userId: string | null | undefined) {
  const [userData, setUserData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchUserData = async () => {
      if (!userId) {
        setUserData(null)
        setLoading(false)
        return
      }

      try {
        setLoading(true)
        const userDoc = await getDoc(doc(db, "users", userId))

        if (userDoc.exists()) {
          setUserData({ id: userDoc.id, ...userDoc.data() })
        } else {
          setUserData(null)
        }
        setError(null)
      } catch (err) {
        console.error("Error fetching user data:", err)
        setError("Failed to fetch user data")
        setUserData(null)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [userId])

  return { userData, loading, error }
}
