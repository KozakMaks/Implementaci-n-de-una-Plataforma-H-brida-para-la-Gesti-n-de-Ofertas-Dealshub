"use client"

import { useState, useEffect, createContext, useContext, type ReactNode } from "react"
import {
  type User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  signInWithPopup,
} from "firebase/auth"
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore"
import { auth, db, googleProvider } from "@/lib/firebase"
import { useRoles, type UserRole } from "@/hooks/use-roles"
// Changed from default to named import
import { LoginModal } from "@/components/auth/login-modal"
// Changed from default to named import
import { SignupModal } from "@/components/auth/signup-modal"

interface AuthContextType {
  user: User | null
  loading: boolean
  role: UserRole
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, displayName: string) => Promise<void>
  logOut: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
  signInWithGoogle: () => Promise<void>
  showLoginModal: boolean
  setShowLoginModal: (show: boolean) => void
  showSignupModal: boolean
  setShowSignupModal: (show: boolean) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const { role, loading: roleLoading } = useRoles(user?.uid)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user)
      if (!user) {
        setLoading(false)
      }
    })

    return () => unsubscribe()
  }, [])

  useEffect(() => {
    if (!user || !roleLoading) {
      setLoading(false)
    }
  }, [user, roleLoading])

  const signIn = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password)
  }

  const signUp = async (email: string, password: string, displayName: string) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user
    const finalDisplayName = displayName.trim() ? displayName : email.split("@")[0]

    await setDoc(doc(db, "users", user.uid), {
      uid: user.uid,
      email,
      displayName: finalDisplayName,
      createdAt: serverTimestamp(),
      reputation: 0,
      badges: [],
      role: "user",
    })
  }

  const logOut = async () => {
    await signOut(auth)
  }

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email)
  }

  const signInWithGoogle = async () => {
    const userCredential = await signInWithPopup(auth, googleProvider)
    const user = userCredential.user
    const userDoc = await getDoc(doc(db, "users", user.uid))

    if (!userDoc.exists()) {
      const displayName = user.displayName || user.email?.split("@")[0] || `User_${user.uid.substring(0, 5)}`
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        email: user.email,
        displayName: displayName,
        photoURL: user.photoURL,
        createdAt: serverTimestamp(),
        reputation: 0,
        badges: [],
        role: "user",
      })
    }
  }

  // Renamed onSwitchToSignup to avoid conflict with SignupModal's onSignupClick
  const handleSwitchToSignupFromLogin = () => {
    setShowLoginModal(false)
    setShowSignupModal(true)
  }

  // Renamed onSwitchToLogin to avoid conflict with LoginModal's onLoginClick
  const handleSwitchToLoginFromSignup = () => {
    setShowSignupModal(false)
    setShowLoginModal(true)
  }

  const value = {
    user,
    loading,
    role,
    signIn,
    signUp,
    logOut,
    resetPassword,
    signInWithGoogle,
    showLoginModal,
    setShowLoginModal,
    showSignupModal,
    setShowSignupModal,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSignupClick={handleSwitchToSignupFromLogin} // Changed prop name
      />
      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onLoginClick={handleSwitchToLoginFromSignup} // Changed prop name
      />
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
