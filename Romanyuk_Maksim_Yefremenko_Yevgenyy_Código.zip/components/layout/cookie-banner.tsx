"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Cookie } from "lucide-react"

export function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const consentDismissed = localStorage.getItem("cookieConsentDismissed")
    if (!consentDismissed) {
      setIsVisible(true)
    }
  }, [])

  const handleAccept = () => {
    setIsVisible(false)
    localStorage.setItem("cookieConsentDismissed", "true")
  }

  if (!isVisible) {
    return null
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-secondary text-secondary-foreground p-4 shadow-md">
      <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Cookie className="h-6 w-6" />
          <p className="text-sm">
            Utilizamos cookies para mejorar tu experiencia. Al continuar navegando, aceptas nuestro uso de cookies.
          </p>
        </div>
        <Button onClick={handleAccept} size="sm">
          Aceptar
        </Button>
      </div>
    </div>
  )
}
