"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  Home,
  Search,
  Bell,
  MessageSquare,
  User,
  Menu,
  X,
  PlusCircle,
  LogOut,
  Sparkles,
  Shield,
  ShieldCheck,
  ArrowRight,
  Loader2,
  LogIn,
  UserPlus,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import { useUserData } from "@/hooks/use-user-data"
// Import the NotificationIndicator
import { NotificationIndicator } from "@/components/layout/notification-indicator"
import { collection, query as firestoreQuery, orderBy, limit, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Deal } from "@/types"

// Debounce function to limit how often a function is called
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => {
      clearTimeout(handler)
    }
  }, [value, delay])

  return debouncedValue
}

export function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logOut, role } = useAuth()
  const { userData } = useUserData(user?.uid)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Deal[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showSearchDropdown, setShowSearchDropdown] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)

  // Debounce search query to avoid too many requests
  const debouncedSearchQuery = useDebounce(searchQuery, 300)

  // Get the display name from userData if available, otherwise from user
  const displayName = userData?.displayName || user?.displayName || (user?.email ? user.email.split("@")[0] : "User")

  // Get the first letter of the display name for the avatar fallback
  const avatarInitial = displayName ? displayName.charAt(0).toUpperCase() : "U"

  // Function to search deals for the dropdown
  const searchDealsForDropdown = async (searchText: string) => {
    if (!searchText.trim() || searchText.length < 2) {
      setSearchResults([])
      setIsSearching(false)
      return
    }

    try {
      setIsSearching(true)

      // Create a query to search deals
      const searchTerms = searchText
        .toLowerCase()
        .split(" ")
        .filter((term) => term.length > 0)

      // Create base query - using Firebase's query function with a different name
      const dealsRef = collection(db, "deals")
      const dealsQuery = firestoreQuery(
        dealsRef,
        orderBy("title"),
        limit(10), // Get a few more than we need for better filtering
      )

      const querySnapshot = await getDocs(dealsQuery)

      // Filter results client-side based on search terms
      const results: Deal[] = []
      querySnapshot.forEach((doc) => {
        const deal = { id: doc.id, ...doc.data() } as Deal

        // Check if any search term is in the title or description
        const matchesSearch = searchTerms.some(
          (term) =>
            deal.title.toLowerCase().includes(term) ||
            (deal.description && deal.description.toLowerCase().includes(term)),
        )

        if (matchesSearch) {
          results.push(deal)
        }
      })

      // Only take the first 3 results
      setSearchResults(results.slice(0, 3))
    } catch (err) {
      console.error("Error searching deals for dropdown:", err)
      setSearchResults([])
    } finally {
      setIsSearching(false)
    }
  }

  // Effect to search when debounced query changes
  useEffect(() => {
    if (debouncedSearchQuery) {
      searchDealsForDropdown(debouncedSearchQuery)
    } else {
      setSearchResults([])
    }
  }, [debouncedSearchQuery])

  // Effect to close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearchDropdown(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      // Navigate to search page with query
      router.push(`/buscar?q=${encodeURIComponent(searchQuery.trim())}`)
      setSearchQuery("") // Clear the search input after search
      setShowSearchDropdown(false)
    }
  }

  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchQuery(value)
    setShowSearchDropdown(value.length > 0)
  }

  const handleSearchResultClick = (dealId: string) => {
    router.push(`/chollo/${dealId}`)
    setSearchQuery("")
    setShowSearchDropdown(false)
  }

  const handleNotificationClick = () => {
    router.push("/alertas")
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const handleLogout = async () => {
    try {
      await logOut()
    } catch (error) {
      console.error("Error logging out:", error)
    }
  }

  const navLinks = [
    { href: "/", label: "Inicio", icon: Home },
    { href: "/private", label: "Mensajes", icon: MessageSquare },
    { href: "/recomendacion", label: "Para Ti", icon: Sparkles },
  ]

  // Format price with euro symbol
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-ES", {
      style: "currency",
      currency: "EUR",
      minimumFractionDigits: 2,
    }).format(price)
  }

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2 md:gap-4">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMenu}>
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>

            <Link href="/" className="flex items-center gap-2">
              <span className="text-xl font-bold text-primary">DealHub</span>
            </Link>

            <nav className="hidden md:flex items-center gap-4">
              {navLinks.map((link) => {
                const Icon = link.icon
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "flex items-center gap-1 text-sm font-medium transition-colors hover:text-primary",
                      pathname === link.href ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {link.label}
                  </Link>
                )
              })}
            </nav>
          </div>

          <div className="hidden md:flex items-center gap-4 flex-1 mx-4">
            <div className="relative flex-1 max-w-md" ref={searchRef}>
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Buscar chollos..."
                    className="w-full pl-8"
                    value={searchQuery}
                    onChange={handleSearchInputChange}
                    onFocus={() => setShowSearchDropdown(searchQuery.length > 0)}
                  />
                </div>
              </form>

              {/* Search results dropdown */}
              {showSearchDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-md shadow-lg z-50 max-h-[300px] overflow-auto">
                  {isSearching ? (
                    <div className="flex items-center justify-center p-4">
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      <span>Buscando...</span>
                    </div>
                  ) : searchResults.length > 0 ? (
                    <>
                      <div className="p-2">
                        {searchResults.map((deal) => (
                          <div
                            key={deal.id}
                            className="p-2 hover:bg-accent rounded-md cursor-pointer"
                            onClick={() => handleSearchResultClick(deal.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex-1 min-w-0">
                                <p className="font-medium truncate">{deal.title}</p>
                                <p className="text-sm text-muted-foreground truncate">
                                  {deal.description?.substring(0, 60)}
                                  {deal.description && deal.description.length > 60 ? "..." : ""}
                                </p>
                              </div>
                              <div className="ml-2 text-primary font-semibold">{formatPrice(deal.discountedPrice)}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div
                        className="p-2 border-t flex items-center justify-center hover:bg-accent cursor-pointer"
                        onClick={handleSearch}
                      >
                        <span className="text-primary font-medium">Ver todos los resultados</span>
                        <ArrowRight className="ml-1 h-4 w-4 text-primary" />
                      </div>
                    </>
                  ) : searchQuery.length > 0 ? (
                    <div className="p-4 text-center text-muted-foreground">
                      No se encontraron resultados para "{searchQuery}"
                    </div>
                  ) : null}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Add prominent "Añadir Chollo" button */}
            {user && (
              <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium">
                <Link href="/add-deal" className="flex items-center gap-2">
                  <PlusCircle className="h-4 w-4" />
                  <span className="hidden lg:inline">Añadir Chollo</span>
                </Link>
              </Button>
            )}

            {user ? (
              <>
                {/* Fix for nested <a> tags - use Button instead of Link */}
                <Button variant="ghost" size="icon" className="relative" onClick={handleNotificationClick}>
                  <NotificationIndicator />
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.photoURL || undefined} alt={displayName} />
                        <AvatarFallback>{avatarInitial}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href={`/perfil/${user.uid}`} className="cursor-pointer">
                        <User className="mr-2 h-4 w-4" />
                        <span>Perfil</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/private" className="cursor-pointer">
                        <MessageSquare className="mr-2 h-4 w-4" />
                        <span>Mensajes</span>
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/alertas" className="cursor-pointer">
                        <Bell className="mr-2 h-4 w-4" />
                        <span>Alertas</span>
                      </Link>
                    </DropdownMenuItem>
                    {user && (role === "admin" || role === "moderator") && (
                      <>
                        <DropdownMenuSeparator />
                        {role === "admin" && (
                          <DropdownMenuItem asChild>
                            <Link href="/admin" className="cursor-pointer">
                              <Shield className="mr-2 h-4 w-4" />
                              <span>Panel de Administrador</span>
                            </Link>
                          </DropdownMenuItem>
                        )}
                        {role === "moderator" && (
                          <DropdownMenuItem asChild>
                            <Link href="/moderator" className="cursor-pointer">
                              <ShieldCheck className="mr-2 h-4 w-4" />
                              <span>Panel de Moderador</span>
                            </Link>
                          </DropdownMenuItem>
                        )}
                      </>
                    )}
                    {/* The separator before logout should always be there if the user is logged in */}
                    {user && <DropdownMenuSeparator />}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Cerrar Sesión</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                {/* Desktop buttons */}
                <div className="hidden md:flex items-center gap-2">
                  <Button variant="ghost" onClick={() => setShowLoginModal(true)}>
                    Iniciar Sesión
                  </Button>
                  <Button onClick={() => setShowSignupModal(true)}>Registrarse</Button>
                </div>

                {/* Mobile dropdown */}
                <div className="md:hidden">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <User className="h-5 w-5" />
                        <span className="sr-only">Abrir menú de usuario</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => setShowLoginModal(true)} className="cursor-pointer">
                        <LogIn className="mr-2 h-4 w-4" />
                        <span>Iniciar Sesión</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setShowSignupModal(true)} className="cursor-pointer">
                        <UserPlus className="mr-2 h-4 w-4" />
                        <span>Registrarse</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t p-4">
            <div className="mb-4" ref={searchRef}>
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Buscar chollos..."
                    className="w-full pl-8"
                    value={searchQuery}
                    onChange={handleSearchInputChange}
                    onFocus={() => setShowSearchDropdown(searchQuery.length > 0)}
                  />
                </div>
              </form>

              {/* Mobile search results dropdown */}
              {showSearchDropdown && (
                <div className="mt-1 bg-background border rounded-md shadow-lg z-50 max-h-[300px] overflow-auto">
                  {isSearching ? (
                    <div className="flex items-center justify-center p-4">
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      <span>Buscando...</span>
                    </div>
                  ) : searchResults.length > 0 ? (
                    <>
                      <div className="p-2">
                        {searchResults.map((deal) => (
                          <div
                            key={deal.id}
                            className="p-2 hover:bg-accent rounded-md cursor-pointer"
                            onClick={() => handleSearchResultClick(deal.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex-1 min-w-0">
                                <p className="font-medium truncate">{deal.title}</p>
                                <p className="text-sm text-muted-foreground truncate">
                                  {deal.description?.substring(0, 40)}
                                  {deal.description && deal.description.length > 40 ? "..." : ""}
                                </p>
                              </div>
                              <div className="ml-2 text-primary font-semibold">{formatPrice(deal.discountedPrice)}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div
                        className="p-2 border-t flex items-center justify-center hover:bg-accent cursor-pointer"
                        onClick={handleSearch}
                      >
                        <span className="text-primary font-medium">Ver todos los resultados</span>
                        <ArrowRight className="ml-1 h-4 w-4 text-primary" />
                      </div>
                    </>
                  ) : searchQuery.length > 0 ? (
                    <div className="p-4 text-center text-muted-foreground">
                      No se encontraron resultados para "{searchQuery}"
                    </div>
                  ) : null}
                </div>
              )}
            </div>

            <nav className="grid gap-2">
              {/* Add prominent "Añadir Chollo" button for mobile */}
              {user && (
                <Link
                  href="/add-deal"
                  className="flex items-center justify-center gap-2 p-3 rounded-md text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <PlusCircle className="h-4 w-4" />
                  Añadir Chollo
                </Link>
              )}

              {navLinks.map((link) => {
                const Icon = link.icon
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "flex items-center gap-2 p-2 rounded-md text-sm font-medium transition-colors hover:bg-accent",
                      pathname === link.href ? "bg-accent" : "",
                    )}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Icon className="h-4 w-4" />
                    {link.label}
                  </Link>
                )
              })}
              {user && (
                <>
                  <Link
                    href="/alertas"
                    className="flex items-center gap-2 p-2 rounded-md text-sm font-medium transition-colors hover:bg-accent"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Bell className="h-4 w-4" />
                    Alertas
                  </Link>
                  {role === "admin" && (
                    <Link
                      href="/admin"
                      className="flex items-center gap-2 p-2 rounded-md text-sm font-medium transition-colors hover:bg-accent"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <Shield className="h-4 w-4" />
                      Panel de Administrador
                    </Link>
                  )}
                  {role === "moderator" && (
                    <Link
                      href="/moderator"
                      className="flex items-center gap-2 p-2 rounded-md text-sm font-medium transition-colors hover:bg-accent"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <ShieldCheck className="h-4 w-4" />
                      Panel de Moderador
                    </Link>
                  )}
                  <Link
                    href={`/perfil/${user.uid}`}
                    className="flex items-center gap-2 p-2 rounded-md text-sm font-medium transition-colors hover:bg-accent"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <User className="h-4 w-4" />
                    Perfil
                  </Link>
                </>
              )}
            </nav>
          </div>
        )}
      </header>

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSignupClick={() => {
          setShowLoginModal(false)
          setShowSignupModal(true)
        }}
      />

      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onLoginClick={() => {
          setShowSignupModal(false)
          setShowLoginModal(true)
        }}
      />
    </>
  )
}
