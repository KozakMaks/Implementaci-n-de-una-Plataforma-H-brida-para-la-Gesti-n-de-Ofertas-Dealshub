import type { ReactNode } from "react"

interface NoDataProps {
  title: string
  description?: string
  icon?: ReactNode
}

export function NoData({ title, description, icon }: NoDataProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {icon && <div className="mb-4 text-muted-foreground">{icon}</div>}
      <h3 className="mb-2 text-xl font-semibold">{title}</h3>
      {description && <p className="text-muted-foreground">{description}</p>}
    </div>
  )
}
