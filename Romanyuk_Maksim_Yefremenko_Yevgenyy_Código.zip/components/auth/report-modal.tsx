"use client"

import { useState } from "react"
import { collection, addDoc, query, where, getDocs, serverTimestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"

interface ReportModalProps {
  isOpen: boolean
  onClose: () => void
  dealId: string
  dealTitle: string
}

const REPORT_REASONS = [
  { id: "unavailable", label: "Deal is no longer available" },
  { id: "misleading", label: "False or misleading" },
  { id: "offensive", label: "Offensive content" },
  { id: "other", label: "Other" },
]

export function ReportModal({ isOpen, onClose, dealId, dealTitle }: ReportModalProps) {
  const { user } = useAuth()
  const [reason, setReason] = useState<string>("")
  const [comment, setComment] = useState<string>("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [alreadyReported, setAlreadyReported] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)

  // Check if user has already reported this deal
  const checkExistingReport = async () => {
    if (!user) return false

    try {
      const q = query(collection(db, "reports"), where("dealId", "==", dealId), where("userId", "==", user.uid))
      const snapshot = await getDocs(q)
      return !snapshot.empty
    } catch (error) {
      console.error("Error checking existing report:", error)
      return false
    }
  }

  const handleSubmit = async () => {
    if (!user) {
      setShowLoginModal(true)
      return
    }

    if (!reason) {
      setError("Please select a reason for reporting")
      return
    }

    if (reason === "other" && !comment.trim()) {
      setError("Please provide details for your report")
      return
    }

    setIsSubmitting(true)
    setError(null)

    try {
      // Check if already reported
      const hasReported = await checkExistingReport()
      if (hasReported) {
        setAlreadyReported(true)
        setIsSubmitting(false)
        return
      }

      // Add report to Firestore
      await addDoc(collection(db, "reports"), {
        dealId,
        dealTitle,
        userId: user.uid,
        userName: user.displayName || user.email?.split("@")[0] || "Anonymous",
        reason,
        comment: reason === "other" ? comment : "",
        status: "pending",
        createdAt: serverTimestamp(),
      })

      setSuccess(true)
    } catch (error) {
      console.error("Error submitting report:", error)
      setError("Failed to submit report. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleClose = () => {
    // Reset state when closing
    setReason("")
    setComment("")
    setError(null)
    setSuccess(false)
    setAlreadyReported(false)
    onClose()
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Report Deal</DialogTitle>
            <DialogDescription>
              Please let us know why you're reporting this deal. This helps us maintain quality content.
            </DialogDescription>
          </DialogHeader>

          {success ? (
            <div className="py-6 text-center">
              <CheckCircle className="mx-auto h-12 w-12 text-green-500" />
              <h3 className="mt-2 text-lg font-medium">Thank you for your report</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Your report has been submitted and will be reviewed by our team.
              </p>
              <Button onClick={handleClose} className="mt-4">
                Close
              </Button>
            </div>
          ) : alreadyReported ? (
            <div className="py-6 text-center">
              <AlertCircle className="mx-auto h-12 w-12 text-amber-500" />
              <h3 className="mt-2 text-lg font-medium">Already Reported</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                You have already reported this deal. Our team will review it soon.
              </p>
              <Button onClick={handleClose} className="mt-4">
                Close
              </Button>
            </div>
          ) : (
            <>
              {error && (
                <Alert variant="destructive" className="my-2">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="py-4">
                <RadioGroup value={reason} onValueChange={setReason}>
                  {REPORT_REASONS.map((reportReason) => (
                    <div key={reportReason.id} className="flex items-center space-x-2 py-2">
                      <RadioGroupItem value={reportReason.id} id={reportReason.id} />
                      <Label htmlFor={reportReason.id}>{reportReason.label}</Label>
                    </div>
                  ))}
                </RadioGroup>

                {reason === "other" && (
                  <div className="mt-4">
                    <Label htmlFor="comment">Please provide details</Label>
                    <Textarea
                      id="comment"
                      placeholder="Tell us more about the issue..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={handleClose} disabled={isSubmitting}>
                  Cancel
                </Button>
                <Button onClick={handleSubmit} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Submit Report"
                  )}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSignupClick={() => {
          setShowLoginModal(false)
          setShowSignupModal(true)
        }}
      />

      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onLoginClick={() => {
          setShowSignupModal(false)
          setShowLoginModal(true)
        }}
      />
    </>
  )
}
