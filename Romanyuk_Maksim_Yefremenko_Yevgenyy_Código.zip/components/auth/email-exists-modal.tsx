"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface EmailExistsModalProps {
  isOpen: boolean
  onClose: () => void
  onLoginClick: () => void
}

export function EmailExistsModal({ isOpen, onClose, onLoginClick }: EmailExistsModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Correo ya registrado</DialogTitle>
        </DialogHeader>
        <DialogDescription className="py-4">
          Ya existe una cuenta con este correo. ¿Quieres iniciar sesión en su lugar?
        </DialogDescription>
        <DialogFooter className="flex justify-between sm:justify-between">
          <Button onClick={onLoginClick} className="flex-1 mr-2">
            Iniciar sesión
          </Button>
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancelar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
