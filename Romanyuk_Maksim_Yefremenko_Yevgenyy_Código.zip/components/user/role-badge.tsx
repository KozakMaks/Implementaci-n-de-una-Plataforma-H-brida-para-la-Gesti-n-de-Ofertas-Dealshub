import { Badge } from "@/components/ui/badge"
import type { UserRole } from "@/hooks/use-roles"

interface RoleBadgeProps {
  role: UserRole
  className?: string
}

export function RoleBadge({ role, className }: RoleBadgeProps) {
  // Define variant and label based on role
  let variant: "outline" | "secondary" | "destructive" | "default" = "outline"
  let label = "Usuario"

  switch (role) {
    case "admin":
      variant = "destructive"
      label = "Administrador"
      break
    case "moderator":
      variant = "default"
      label = "Moderador"
      break
    default:
      variant = "outline"
      label = "Usuario"
  }

  return (
    <Badge variant={variant} className={className}>
      {label}
    </Badge>
  )
}
