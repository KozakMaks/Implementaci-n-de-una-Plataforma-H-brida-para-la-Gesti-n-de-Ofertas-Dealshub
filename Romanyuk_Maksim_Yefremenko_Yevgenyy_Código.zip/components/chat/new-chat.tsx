"use client"

import type React from "react"
import { useState, useEffect, useCallback, useRef } from "react"
import { useChat } from "@/hooks/use-chat"
import { useAuth } from "@/hooks/use-auth"
import { searchUsers } from "@/app/actions/search-users"
import type { User as AppUserType } from "@/types"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger, // Use the standard DialogTrigger
} from "@/components/ui/dialog"
import { Popover, PopoverContent, PopoverTrigger as PopoverUITrigger } from "@/components/ui/popover" // Alias PopoverTrigger
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageSquarePlus, Loader2, Search, X } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

function debounce<F extends (...args: any[]) => any>(func: F, waitFor: number) {
  let timeout: NodeJS.Timeout | null = null
  const debounced = (...args: Parameters<F>) => {
    if (timeout !== null) {
      clearTimeout(timeout)
    }
    timeout = setTimeout(() => func(...args), waitFor)
  }
  return debounced as (...args: Parameters<F>) => void
}

interface NewChatProps {
  onChatCreated: (conversationId: string) => void
  userId?: string
  userName?: string
}

export function NewChat({ onChatCreated, userId, userName }: NewChatProps) {
  const { user: currentUser, loading: isLoadingAuth } = useAuth()
  const { sendChatRequest } = useChat()

  const [open, setOpen] = useState(false)
  const [popoverOpen, setPopoverOpen] = useState(false)
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<AppUserType[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [searchError, setSearchError] = useState<string | null>(null)
  const [selectedRecipient, setSelectedRecipient] = useState<AppUserType | null>(null)

  const searchInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!open) {
      setMessage("")
      setError(null)
      setSuccess(null)
      setSearchQuery("")
      setSearchResults([])
      setSearchError(null)
      setSelectedRecipient(null)
      setPopoverOpen(false)
    }
  }, [open])

  const performSearch = async (query: string) => {
    if (isLoadingAuth) return
    if (!currentUser) {
      setSearchError("Debes iniciar sesión para buscar usuarios.")
      setPopoverOpen(false)
      return
    }
    if (query.trim().length < 1) {
      setSearchResults([])
      setPopoverOpen(false)
      return
    }

    setIsSearching(true)
    setSearchError(null)
    const result = await searchUsers(query, currentUser.uid)
    if (result.success && result.users) {
      setSearchResults(result.users)
      setPopoverOpen(result.users.length > 0 || (query.trim().length > 0 && !result.error))
    } else {
      setSearchResults([])
      setSearchError(result.error || "No se pudo realizar la búsqueda.")
      setPopoverOpen(true)
    }
    setIsSearching(false)
  }

  const debouncedSearch = useCallback(debounce(performSearch, 300), [currentUser, isLoadingAuth])

  useEffect(() => {
    if (!userId && searchQuery.trim().length > 0) {
      debouncedSearch(searchQuery)
    } else if (!userId && searchQuery.trim().length === 0) {
      setSearchResults([])
      setPopoverOpen(false)
    }
  }, [searchQuery, debouncedSearch, userId])

  const handleSelectRecipient = (user: AppUserType) => {
    setSelectedRecipient(user)
    setSearchQuery("")
    setSearchResults([])
    setPopoverOpen(false)
  }

  const clearSelectedRecipient = () => {
    setSelectedRecipient(null)
    setSearchQuery("")
    setSearchResults([])
    setSearchError(null)
    setPopoverOpen(false)
    searchInputRef.current?.focus()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const finalRecipientId = selectedRecipient?.uid || userId
    if (!finalRecipientId || !message.trim() || isSubmitting) return

    setIsSubmitting(true)
    setError(null)
    setSuccess(null)
    try {
      const result = await sendChatRequest(finalRecipientId, message)
      if (result) {
        if (result.type === "existing") {
          onChatCreated(result.conversationId)
        } else {
          setSuccess("¡Solicitud de chat enviada con éxito!")
        }
        setTimeout(() => setOpen(false), result.type === "existing" ? 0 : 2000)
      } else {
        setError("Error al enviar la solicitud de chat.")
      }
    } catch (err) {
      setError("Ha ocurrido un error. Por favor, inténtalo de nuevo.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const isDirectChat = !!userId

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <MessageSquarePlus className="h-4 w-4" />
          <span>{isDirectChat ? `Chatear con ${userName || "Usuario"}` : "Nuevo Chat"}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isDirectChat ? `Enviar mensaje a ${userName}` : "Iniciar una nueva conversación"}</DialogTitle>
          <DialogDescription>
            {isDirectChat
              ? "Tu mensaje iniciará una conversación o se enviará como una solicitud."
              : "Busca a un usuario para enviarle una solicitud de chat."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          {!isDirectChat && (
            <div className="space-y-2">
              {selectedRecipient ? (
                <div className="flex items-center justify-between rounded-md border p-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={selectedRecipient.photoURL || undefined} />
                      <AvatarFallback>{selectedRecipient.displayName?.[0]?.toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{selectedRecipient.displayName}</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={clearSelectedRecipient} className="h-7 w-7">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
                  <PopoverUITrigger asChild>
                    <div className="relative">
                      <Input
                        ref={searchInputRef}
                        id="searchUser"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Escribe un nombre de usuario..."
                        disabled={isLoadingAuth}
                        className="pr-10"
                        autoComplete="off"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                        {isSearching ? (
                          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                        ) : (
                          <Search className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  </PopoverUITrigger>
                  <PopoverContent
                    className="w-[var(--radix-popover-trigger-width)] p-0"
                    align="start"
                    sideOffset={5}
                    onOpenAutoFocus={(e) => e.preventDefault()}
                  >
                    {isLoadingAuth && <p className="text-xs text-muted-foreground p-2">Cargando autenticación...</p>}
                    {searchError && <p className="text-sm text-destructive p-2">{searchError}</p>}

                    {!isLoadingAuth &&
                      !searchError &&
                      (searchResults.length > 0 || (searchQuery.trim().length > 0 && !isSearching)) && (
                        <ScrollArea className="max-h-48">
                          <div className="p-1">
                            {searchResults.length > 0
                              ? searchResults.map((userResult) => (
                                  <div
                                    key={userResult.uid}
                                    onClick={() => handleSelectRecipient(userResult)}
                                    className="flex cursor-pointer items-center gap-3 rounded-md p-2 hover:bg-accent"
                                  >
                                    <Avatar className="h-8 w-8">
                                      <AvatarImage src={userResult.photoURL || undefined} />
                                      <AvatarFallback>{userResult.displayName?.[0]?.toUpperCase()}</AvatarFallback>
                                    </Avatar>
                                    <span className="text-sm">{userResult.displayName}</span>
                                  </div>
                                ))
                              : searchQuery.trim().length > 0 &&
                                !isSearching && (
                                  <p className="text-sm text-muted-foreground p-2 text-center">
                                    No se encontraron usuarios.
                                  </p>
                                )}
                          </div>
                        </ScrollArea>
                      )}
                  </PopoverContent>
                </Popover>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="message">Mensaje</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Escribe tu mensaje..."
              required
              disabled={isLoadingAuth || (!selectedRecipient && !isDirectChat)}
            />
          </div>

          {error && (
            <Alert variant="destructive" className="mt-2">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {success && (
            <Alert className="mt-2">
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          <DialogFooter>
            <Button
              type="submit"
              disabled={isSubmitting || isLoadingAuth || (!selectedRecipient && !isDirectChat) || !message.trim()}
            >
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Enviar Mensaje"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
