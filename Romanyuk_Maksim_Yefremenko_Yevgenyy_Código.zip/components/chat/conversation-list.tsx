"use client"

import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { useAuth } from "@/hooks/use-auth"
import type { Conversation } from "@/types"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface ConversationListProps {
  conversations: Conversation[]
  selectedId: string | null
  onSelect: (conversationId: string) => void
}

export function ConversationList({ conversations, selectedId, onSelect }: ConversationListProps) {
  const { user } = useAuth()

  if (!user) return null

  return (
    <div className="divide-y">
      {conversations.map((conversation) => {
        // Find the other participant
        const otherParticipantId = conversation.participants.find((id) => id !== user.uid) || ""
        const otherParticipant = conversation.participantsInfo?.[otherParticipantId] || {
          displayName: "Usuario",
          photoURL: null,
        }

        // Get unread count for current user
        const unreadCount = conversation.unreadCount?.[user.uid] || 0

        return (
          <button
            key={conversation.id}
            className={`w-full px-4 py-3 text-left transition-colors hover:bg-accent ${
              selectedId === conversation.id ? "bg-accent" : ""
            }`}
            onClick={() => onSelect(conversation.id)}
          >
            <div className="flex items-center gap-3">
              <Link
                href={`/perfil/${otherParticipantId}`}
                onClick={(e) => e.stopPropagation()}
                className="transition-transform hover:scale-105"
              >
                <Avatar className="h-10 w-10 ring-offset-2 transition-all hover:ring-2 hover:ring-primary">
                  <AvatarImage src={otherParticipant.photoURL || undefined} alt={otherParticipant.displayName} />
                  <AvatarFallback>
                    {otherParticipant.displayName ? otherParticipant.displayName.charAt(0).toUpperCase() : "U"}
                  </AvatarFallback>
                </Avatar>
              </Link>
              <div className="flex-1 overflow-hidden">
                <Link
                  href={`/perfil/${otherParticipantId}`}
                  onClick={(e) => e.stopPropagation()}
                  className="font-medium transition-colors hover:text-primary hover:underline"
                >
                  {otherParticipant.displayName}
                </Link>
                <p className="truncate text-sm text-muted-foreground">{conversation.lastMessage}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <div className="text-xs text-muted-foreground">
                  {conversation.lastMessageTime
                    ? formatDistanceToNow(new Date(conversation.lastMessageTime.toDate()), {
                        addSuffix: true,
                        locale: es,
                      })
                    : "recientemente"}
                </div>
                {unreadCount > 0 && (
                  <Badge variant="default" className="h-5 w-5 rounded-full p-0 text-center text-xs">
                    {unreadCount}
                  </Badge>
                )}
              </div>
            </div>
          </button>
        )
      })}
    </div>
  )
}
