"use client"

import { useState } from "react"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { useChat } from "@/hooks/use-chat"
import type { ChatRequest } from "@/types"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, X } from "lucide-react"

interface ChatRequestsProps {
  onAccept: (conversationId: string) => void
}

export function ChatRequests({ onAccept }: ChatRequestsProps) {
  const { chatRequests, handleChatRequest } = useChat()
  const [processingIds, setProcessingIds] = useState<Set<string>>(new Set())

  const handleAccept = async (requestId: string) => {
    setProcessingIds((prev) => new Set(prev).add(requestId))
    try {
      const conversationId = await handleChatRequest(requestId, true)
      if (conversationId) {
        onAccept(conversationId)
      }
    } finally {
      setProcessingIds((prev) => {
        const newSet = new Set(prev)
        newSet.delete(requestId)
        return newSet
      })
    }
  }

  const handleDecline = async (requestId: string) => {
    setProcessingIds((prev) => new Set(prev).add(requestId))
    try {
      await handleChatRequest(requestId, false)
    } finally {
      setProcessingIds((prev) => {
        const newSet = new Set(prev)
        newSet.delete(requestId)
        return newSet
      })
    }
  }

  if (chatRequests.length === 0) {
    return null
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Solicitudes de Chat</CardTitle>
        <CardDescription>Personas que quieren chatear contigo</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {chatRequests.map((request: ChatRequest) => (
            <div key={request.id} className="flex items-start gap-4 border-b pb-4 last:border-0 last:pb-0">
              <Avatar className="h-10 w-10">
                <AvatarImage src={request.senderPhotoURL || undefined} alt={request.senderName} />
                <AvatarFallback>{request.senderName ? request.senderName.charAt(0).toUpperCase() : "U"}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">{request.senderName}</h4>
                  <span className="text-xs text-muted-foreground">
                    {request.createdAt
                      ? formatDistanceToNow(new Date(request.createdAt.toDate()), {
                          addSuffix: true,
                          locale: es,
                        })
                      : "recientemente"}
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{request.message}</p>
                <div className="mt-2 flex gap-2">
                  <Button
                    size="sm"
                    className="h-8"
                    onClick={() => handleAccept(request.id)}
                    disabled={processingIds.has(request.id)}
                  >
                    <Check className="mr-1 h-4 w-4" />
                    Aceptar
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8"
                    onClick={() => handleDecline(request.id)}
                    disabled={processingIds.has(request.id)}
                  >
                    <X className="mr-1 h-4 w-4" />
                    Rechazar
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
