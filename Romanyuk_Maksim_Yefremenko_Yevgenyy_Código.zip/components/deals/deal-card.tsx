"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { ChevronUp, ChevronDown, MessageSquare, Star, Flag, Clock, TicketPercent } from "lucide-react"
import { collection, query, where, getDocs, addDoc, deleteDoc, serverTimestamp, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import type { Deal as DealType } from "@/types"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import { ReportModal } from "@/components/deals/report-modal"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useVotes } from "@/hooks/use-votes"
import { formatUsername } from "@/utils/format-username"
import { formatPriceForDisplay } from "@/lib/formatters"

interface DealCardProps {
  deal: DealType
}

export function DealCard({ deal }: DealCardProps) {
  const { user } = useAuth()
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)
  const [showReportModal, setShowReportModal] = useState(false)
  const [isFavoriting, setIsFavoriting] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)
  const [favoriteId, setFavoriteId] = useState<string | null>(null)

  const { currentVote, voteCount, isVoting, handleVote } = useVotes(deal.id)

  useEffect(() => {
    const checkFavoriteStatus = async () => {
      if (!user) {
        setIsFavorite(false)
        return
      }
      try {
        const q = query(collection(db, "favorites"), where("userId", "==", user.uid), where("dealId", "==", deal.id))
        const snapshot = await getDocs(q)
        if (!snapshot.empty) {
          setIsFavorite(true)
          setFavoriteId(snapshot.docs[0].id)
        } else {
          setIsFavorite(false)
          setFavoriteId(null)
        }
      } catch (error) {
        console.error("Error checking favorite status:", error)
      }
    }
    checkFavoriteStatus()
  }, [user, deal.id])

  const voteScore = voteCount.upvotes - voteCount.downvotes

  let dateToFormat: Date | null = null
  if (deal.createdAt) {
    if (typeof deal.createdAt === "string") {
      dateToFormat = new Date(deal.createdAt)
    } else if (typeof (deal.createdAt as any).toDate === "function") {
      dateToFormat = (deal.createdAt as any).toDate()
    } else if (deal.createdAt instanceof Date) {
      dateToFormat = deal.createdAt
    }
  }

  const formattedDate = dateToFormat
    ? formatDistanceToNow(dateToFormat, { addSuffix: true, locale: es })
    : "recientemente"

  const onVote = async (voteType: "up" | "down") => {
    if (deal.isExpired) return
    if (!user) {
      setShowLoginModal(true)
      return
    }
    await handleVote(voteType === currentVote ? null : voteType)
  }

  const handleFavorite = async () => {
    if (!user) {
      setShowLoginModal(true)
      return
    }
    if (isFavoriting) return
    setIsFavoriting(true)
    try {
      if (isFavorite && favoriteId) {
        await deleteDoc(doc(db, "favorites", favoriteId))
        setIsFavorite(false)
        setFavoriteId(null)
      } else {
        const docRef = await addDoc(collection(db, "favorites"), {
          userId: user.uid,
          dealId: deal.id,
          dealTitle: deal.title,
          createdAt: serverTimestamp(),
        })
        setIsFavorite(true)
        setFavoriteId(docRef.id)
      }
    } catch (error) {
      console.error("Error favoriting:", error)
      setIsFavorite(!isFavorite)
    } finally {
      setIsFavoriting(false)
    }
  }

  const renderBadges = () => {
    if (deal.isExpired) {
      return (
        <Badge variant="outline" className="border-orange-500 text-orange-500">
          <Clock className="mr-1 h-3 w-3" /> Caducado
        </Badge>
      )
    }
    return (
      <Link
        href={`/categoria/${encodeURIComponent(deal.category)}`}
        onClick={(e) => e.stopPropagation()} // Prevents the parent Link from firing
        className="relative z-10" // Ensures the link is clickable above the parent
      >
        <Badge variant="outline" className="cursor-pointer hover:bg-accent">
          {deal.category}
        </Badge>
      </Link>
    )
  }

  return (
    <>
      <Card
        className={`overflow-hidden transition-all hover:shadow-lg ${deal.isExpired ? "opacity-70 grayscale" : ""}`}
      >
        <Link href={`/chollo/${deal.id}`} className="block group">
          <div className="relative aspect-[16/10] overflow-hidden">
            <Image
              src={deal.imageUrl || "/placeholder.svg?height=300&width=500&query=deal+card+image"}
              alt={deal.title}
              fill
              className="object-cover transition-transform group-hover:scale-105"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="bg-primary text-primary-foreground text-xs px-1.5 py-0.5">
                  {deal.discountPercentage}% OFF
                </Badge>
                <div className="flex items-center gap-1 text-white">
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span className="text-xs">{deal.commentCount || 0}</span>
                </div>
              </div>
            </div>
            {deal.isExpired && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                <Badge
                  variant="outline"
                  className="border-2 border-orange-500 bg-black/70 px-2.5 py-1 text-base font-semibold text-orange-500"
                >
                  <Clock className="mr-1.5 h-4 w-4" /> CADUCADO
                </Badge>
              </div>
            )}
          </div>
        </Link>

        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center gap-0.5">
              <Button
                variant={currentVote === "up" ? "default" : "ghost"}
                size="icon"
                className={`h-7 w-7 rounded-full ${currentVote === "up" ? "bg-green-500 hover:bg-green-600 text-white" : "text-muted-foreground"} ${deal.isExpired ? "opacity-50 cursor-not-allowed" : ""}`}
                onClick={() => onVote("up")}
                disabled={isVoting || deal.isExpired}
              >
                <ChevronUp className="h-4.5 w-4.5" />
                <span className="sr-only">Votar positivo</span>
              </Button>
              <span className="text-xs font-semibold tabular-nums">{voteScore}</span>
              <Button
                variant={currentVote === "down" ? "default" : "ghost"}
                size="icon"
                className={`h-7 w-7 rounded-full ${currentVote === "down" ? "bg-red-500 hover:bg-red-600 text-white" : "text-muted-foreground"} ${deal.isExpired ? "opacity-50 cursor-not-allowed" : ""}`}
                onClick={() => onVote("down")}
                disabled={isVoting || deal.isExpired}
              >
                <ChevronDown className="h-4.5 w-4.5" />
                <span className="sr-only">Votar negativo</span>
              </Button>
            </div>
            <div className="flex-1 min-w-0">
              <Link href={`/chollo/${deal.id}`} className="block">
                <h3 className="font-semibold text-base line-clamp-2 hover:text-primary transition-colors">
                  {deal.title}
                </h3>
              </Link>
              <p className="mt-0.5 text-xs text-muted-foreground line-clamp-1">{deal.description}</p>
              <div className="mt-1.5 flex items-center justify-between flex-wrap gap-x-2 gap-y-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="text-md font-bold text-primary">{formatPriceForDisplay(deal.discountedPrice)}</span>
                  {deal.originalPrice > deal.discountedPrice && (
                    <span className="text-xs text-muted-foreground line-through">
                      {formatPriceForDisplay(deal.originalPrice)}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  {renderBadges()}
                  {deal.couponCode && (
                    <TooltipProvider delayDuration={100}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Badge
                            variant="outline"
                            className="border-amber-400 text-amber-600 bg-amber-50 hover:bg-amber-100 cursor-pointer text-xs px-1.5 py-0.5"
                          >
                            <TicketPercent className="h-3.5 w-3.5" />
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent className="bg-background border-border shadow-lg">
                          <p className="text-xs">
                            Cupón: <strong className="text-primary">{deal.couponCode}</strong>
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>

        <CardFooter className="border-t p-3">
          <div className="flex w-full items-center justify-between text-xs">
            <div className="text-muted-foreground truncate">
              Por {formatUsername({ displayName: deal.publisherName || "Usuario" }, "User")} - {formattedDate}
            </div>
            <div className="flex items-center gap-0.5">
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleFavorite} disabled={isFavoriting}>
                <Star
                  className={`h-4 w-4 ${isFavorite ? "fill-yellow-400 text-yellow-500" : "text-muted-foreground"}`}
                />
                <span className="sr-only">Favorito</span>
              </Button>
              {!deal.isExpired && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-muted-foreground hover:text-destructive"
                  onClick={() => setShowReportModal(true)}
                >
                  <Flag className="h-4 w-4" />
                  <span className="sr-only">Reportar</span>
                </Button>
              )}
            </div>
          </div>
        </CardFooter>
      </Card>

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSignupClick={() => {
          setShowLoginModal(false)
          setShowSignupModal(true)
        }}
      />
      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onLoginClick={() => {
          setShowSignupModal(false)
          setShowLoginModal(true)
        }}
      />
      <ReportModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        dealId={deal.id}
        dealTitle={deal.title}
      />
    </>
  )
}
