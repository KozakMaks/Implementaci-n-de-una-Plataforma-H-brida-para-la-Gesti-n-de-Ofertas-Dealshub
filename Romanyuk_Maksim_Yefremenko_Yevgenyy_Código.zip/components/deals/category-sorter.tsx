"use client"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export type CategorySortOption = "newest" | "popular" | "mostVoted" | "mostCommented"

interface CategorySorterProps {
  onSortChange: (value: CategorySortOption) => void
  currentSort: CategorySortOption
}

export function CategorySorter({ onSortChange, currentSort }: CategorySorterProps) {
  return (
    <Select value={currentSort} onValueChange={(value) => onSortChange(value as CategorySortOption)}>
      <SelectTrigger className="w-[180px] h-9 text-sm">
        <SelectValue placeholder="Ordenar por" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="newest">Más recientes</SelectItem>
        <SelectItem value="popular">Más populares</SelectItem>
        <SelectItem value="mostVoted">Más votados</SelectItem>
        <SelectItem value="mostCommented">Más comentados</SelectItem>
      </SelectContent>
    </Select>
  )
}
