"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Filter, SlidersHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { formatNumberForDisplay, parseNumberFromDisplay } from "@/lib/formatters" // Corrected imports

const CATEGORIES = [
  "Electrónica",
  "Moda",
  "Hogar y Jardín",
  "Belleza",
  "Deportes",
  "Juguetes",
  "Alimentación",
  "Viajes",
  "Servicios",
  "Otros",
]

const MIN_PRICE_DIFFERENCE = 50
const MAX_PRICE = 1000
const DEBOUNCE_DELAY = 500

interface DealFilterProps {
  onFilterChange: (filters: any) => void
}

export function DealFilter({ onFilterChange }: DealFilterProps) {
  const [sortBy, setSortBy] = useState("newest")
  const [priceRange, setPriceRange] = useState([0, MAX_PRICE])
  const [minPriceInput, setMinPriceInput] = useState("0")
  const [maxPriceInput, setMaxPriceInput] = useState(
    formatNumberForDisplay(MAX_PRICE, { minimumFractionDigits: 0, maximumFractionDigits: 0 }),
  )
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [discountMin, setDiscountMin] = useState(0)
  const [priceInputError, setPriceInputError] = useState<string | null>(null)

  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    setMinPriceInput(formatNumberForDisplay(priceRange[0], { minimumFractionDigits: 0, maximumFractionDigits: 2 }))
    setMaxPriceInput(
      priceRange[1] === MAX_PRICE
        ? `${formatNumberForDisplay(MAX_PRICE, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}+`
        : formatNumberForDisplay(priceRange[1], { minimumFractionDigits: 0, maximumFractionDigits: 2 }),
    )
  }, [priceRange])

  const handleSortChange = (value: string) => {
    setSortBy(value)
    onFilterChange({ sortBy: value, priceRange, selectedCategories, discountMin })
  }

  const handlePriceSliderChange = (value: number[]) => {
    let [min, max] = value
    if (max - min < MIN_PRICE_DIFFERENCE && max !== MAX_PRICE) {
      // Allow max to be MAX_PRICE even if diff is small
      if (min === priceRange[0]) {
        max = Math.min(MAX_PRICE, min + MIN_PRICE_DIFFERENCE)
      } else {
        min = Math.max(0, max - MIN_PRICE_DIFFERENCE)
      }
    }
    const newRange = [Math.max(0, min), Math.min(MAX_PRICE, max)]
    setPriceRange(newRange)
    onFilterChange({ sortBy, priceRange: newRange, selectedCategories, discountMin })
  }

  const applyPriceInputs = () => {
    const min = parseNumberFromDisplay(minPriceInput)
    let max = parseNumberFromDisplay(maxPriceInput.replace("+", ""))

    if (isNaN(min) || isNaN(max)) {
      setPriceInputError("Por favor, introduce números válidos.")
      return false
    }
    if (min < 0) {
      setPriceInputError("Los precios no pueden ser negativos.")
      return false
    }
    if (max > MAX_PRICE) max = MAX_PRICE
    if (min >= max) {
      setPriceInputError("El precio mínimo debe ser menor que el precio máximo.")
      return false
    }
    if (max - min < MIN_PRICE_DIFFERENCE && max !== MAX_PRICE) {
      setPriceInputError(
        `La diferencia mínima debe ser de al menos ${formatNumberForDisplay(MIN_PRICE_DIFFERENCE, { style: "currency", currency: "EUR" })}.`,
      )
      return false
    }

    const newRange = [min, max]
    setPriceRange(newRange)
    onFilterChange({ sortBy, priceRange: newRange, selectedCategories, discountMin })
    setPriceInputError(null)
    return true
  }

  const handleMinPriceInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMinPriceInput(e.target.value)
    setPriceInputError(null)
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current)
    debounceTimerRef.current = setTimeout(applyPriceInputs, DEBOUNCE_DELAY)
  }

  const handleMaxPriceInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMaxPriceInput(e.target.value.replace("+", ""))
    setPriceInputError(null)
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current)
    debounceTimerRef.current = setTimeout(applyPriceInputs, DEBOUNCE_DELAY)
  }

  const handleCategoryChange = (category: string, checked: boolean) => {
    const updatedCategories = checked
      ? [...selectedCategories, category]
      : selectedCategories.filter((c) => c !== category)
    setSelectedCategories(updatedCategories)
    onFilterChange({ sortBy, priceRange, selectedCategories: updatedCategories, discountMin })
  }

  const handleDiscountChange = (value: number[]) => {
    setDiscountMin(value[0])
    onFilterChange({ sortBy, priceRange, selectedCategories, discountMin: value[0] })
  }

  const clearFilters = () => {
    setSortBy("newest")
    setPriceRange([0, MAX_PRICE])
    setSelectedCategories([])
    setDiscountMin(0)
    setPriceInputError(null)
    onFilterChange({ sortBy: "newest", priceRange: [0, MAX_PRICE], selectedCategories: [], discountMin: 0 })
  }

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current)
    }
  }, [])

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 gap-1">
              <Filter className="h-4 w-4" />
              <span className="hidden sm:inline">Ordenar</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuLabel>Ordenar por</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuRadioGroup value={sortBy} onValueChange={handleSortChange}>
              <DropdownMenuRadioItem value="newest">Más recientes</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="popular">Más populares</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="discount">Mayor descuento</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="price-low">Precio: De menor a mayor</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="price-high">Precio: De mayor a menor</DropdownMenuRadioItem>
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 gap-1">
              <SlidersHorizontal className="h-4 w-4" />
              <span className="hidden sm:inline">Filtros</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] sm:w-[400px]">
            <SheetHeader>
              <SheetTitle>Filtros</SheetTitle>
              <SheetDescription>Refina tu búsqueda con estos filtros</SheetDescription>
            </SheetHeader>

            <div className="mt-6 space-y-6">
              <div className="space-y-3">
                <h3 className="text-sm font-medium">Ordenar por</h3>
                <RadioGroup value={sortBy} onValueChange={handleSortChange}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="newest" id="filter-newest" />
                    <Label htmlFor="filter-newest">Más recientes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="popular" id="filter-popular" />
                    <Label htmlFor="filter-popular">Más populares</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="discount" id="filter-discount" />
                    <Label htmlFor="filter-discount">Mayor descuento</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="price-low" id="filter-price-low" />
                    <Label htmlFor="filter-price-low">Precio: De menor a mayor</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="price-high" id="filter-price-high" />
                    <Label htmlFor="filter-price-high">Precio: De mayor a menor</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-medium">Rango de precio</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="min-price">Mínimo (€)</Label>
                    <Input
                      id="min-price"
                      type="text"
                      inputMode="decimal"
                      value={minPriceInput}
                      onChange={handleMinPriceInputChange}
                      className="h-8"
                      placeholder="0"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="max-price">Máximo (€)</Label>
                    <Input
                      id="max-price"
                      type="text"
                      inputMode="decimal"
                      value={maxPriceInput}
                      onChange={handleMaxPriceInputChange}
                      className="h-8"
                      placeholder={`${formatNumberForDisplay(MAX_PRICE, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}+`}
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Usa coma (,) para decimales.</p>
                {priceInputError && <p className="text-xs text-red-500">{priceInputError}</p>}

                <div className="pt-2">
                  <Slider
                    value={priceRange}
                    min={0}
                    max={MAX_PRICE}
                    step={10}
                    onValueChange={handlePriceSliderChange}
                    className="py-4"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatNumberForDisplay(priceRange[0], { style: "currency", currency: "EUR" })}</span>
                    <span>
                      {priceRange[1] === MAX_PRICE
                        ? `${formatNumberForDisplay(MAX_PRICE, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}+ €`
                        : formatNumberForDisplay(priceRange[1], { style: "currency", currency: "EUR" })}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Nota: {formatNumberForDisplay(MAX_PRICE, { style: "currency", currency: "EUR" })}+ significa "
                  {formatNumberForDisplay(MAX_PRICE, { style: "currency", currency: "EUR" })} y más". La diferencia
                  mínima entre precios debe ser de al menos{" "}
                  {formatNumberForDisplay(MIN_PRICE_DIFFERENCE, { style: "currency", currency: "EUR" })}.
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">Descuento mínimo</h3>
                  <span className="text-xs text-muted-foreground">{discountMin}%</span>
                </div>
                <Slider defaultValue={[discountMin]} min={0} max={100} step={5} onValueChange={handleDiscountChange} />
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-medium">Categorías</h3>
                <div className="grid grid-cols-2 gap-2">
                  {CATEGORIES.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-filter-${category.replace(/\s+/g, "-")}`}
                        checked={selectedCategories.includes(category)}
                        onCheckedChange={(checked) => handleCategoryChange(category, checked as boolean)}
                      />
                      <Label htmlFor={`category-filter-${category.replace(/\s+/g, "-")}`}>{category}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <Button onClick={clearFilters} variant="outline" className="w-full">
                Limpiar filtros
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      <div className="text-sm text-muted-foreground">
        {(selectedCategories.length > 0 || priceRange[0] > 0 || priceRange[1] < MAX_PRICE || discountMin > 0) && (
          <Button variant="link" onClick={clearFilters} className="h-auto p-0">
            Limpiar todos los filtros
          </Button>
        )}
      </div>
    </div>
  )
}
