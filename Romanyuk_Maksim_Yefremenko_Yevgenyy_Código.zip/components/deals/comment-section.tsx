"use client"

import type React from "react"
import { useState, useRef, useEffect, useCallback, useMemo } from "react" // Added useMemo
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { addDocument } from "@/hooks/use-firestore" // deleteDocument is not used in this file directly
import { useUserData } from "@/hooks/use-user-data"
import type { Comment, CommentVote, Deal } from "@/types"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select" // Added Select
import { toast } from "@/components/ui/use-toast"
import {
  doc,
  updateDoc,
  serverTimestamp,
  increment,
  getDoc,
  query,
  where,
  getDocs,
  collection,
  writeBatch,
  type Timestamp, // Import Timestamp type
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Flag, ShieldAlert, ThumbsUp, ThumbsDown, Loader2 } from "lucide-react"

// Define SortOption type
type SortOption = "newest" | "oldest" | "mostVoted"

interface CommentSectionProps {
  dealId: string
  comments: Comment[]
  isDisabled?: boolean
}

function ReplyForm({
  commentId,
  dealId,
  onReplySubmitted,
  onCancel,
}: {
  commentId: string
  dealId: string
  onReplySubmitted: () => void
  onCancel: () => void
}) {
  const { user } = useAuth()
  const { userData } = useUserData(user?.uid)
  const [replyContent, setReplyContent] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus()
    }
  }, [])

  const handleReplyChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setReplyContent(e.target.value)
  }, [])

  const handleSubmitReply = async () => {
    if (!user || !replyContent.trim() || isSubmitting) return
    setIsSubmitting(true)
    try {
      let userName = userData?.displayName
      if (!userName) {
        const userDoc = await getDoc(doc(db, "users", user.uid))
        if (userDoc.exists()) {
          userName = userDoc.data().displayName
        }
      }
      userName = userName || user.email?.split("@")[0] || `Usuario_${user.uid.substring(0, 5)}`
      const newReplyInfo = await addDocument("comments", {
        dealId,
        userId: user.uid,
        userName: userName,
        userPhotoURL: user.photoURL,
        content: replyContent,
        parentId: commentId,
        status: "visible",
        likes: 0,
        dislikes: 0,
        // createdAt will be set by addDocument
      })
      const newReplyId = newReplyInfo.id
      const dealRef = doc(db, "deals", dealId)
      await updateDoc(dealRef, {
        commentCount: increment(1),
        updatedAt: serverTimestamp(),
      })

      // Alert generation block for new reply
      const dealDocRef = doc(db, "deals", dealId)
      const dealDocSnap = await getDoc(dealDocRef)

      if (dealDocSnap.exists()) {
        const dealData = dealDocSnap.data() as Deal
        const commenterName = userName

        // 1. Alert for Deal Publisher
        if (dealData.publisherId && dealData.publisherId !== user.uid) {
          await addDocument("alerts", {
            userId: dealData.publisherId,
            type: "deal_comment_own",
            content: `${commenterName} comentó en tu chollo: "${dealData.title}"`,
            relatedId: dealId,
            relatedSubId: newReplyId,
            read: false,
            triggeringUserId: user.uid,
            triggeringUserName: commenterName,
            dealTitle: dealData.title,
          })
        }

        // 2. Alert for Subscribers
        const favoritesQuery = query(collection(db, "favorites"), where("dealId", "==", dealId))
        const favoritesSnap = await getDocs(favoritesQuery)
        favoritesSnap.forEach(async (favDoc) => {
          const subscriberId = favDoc.data().userId
          if (subscriberId !== user.uid && subscriberId !== dealData.publisherId) {
            await addDocument("alerts", {
              userId: subscriberId,
              type: "subscribed_deal_comment",
              content: `${commenterName} comentó en un chollo que sigues: "${dealData.title}"`,
              relatedId: dealId,
              relatedSubId: newReplyId,
              read: false,
              triggeringUserId: user.uid,
              triggeringUserName: commenterName,
              dealTitle: dealData.title,
            })
          }
        })
      }

      onReplySubmitted()
      setReplyContent("")
    } catch (error) {
      console.error("Error al añadir respuesta:", error)
      toast({ title: "Error", description: "No se pudo enviar la respuesta.", variant: "destructive" })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="mt-4 border-dashed">
      <CardContent className="p-4">
        <Textarea
          ref={textareaRef}
          placeholder="Escribe una respuesta..."
          value={replyContent}
          onChange={handleReplyChange}
          className="min-h-[80px] resize-none"
        />
        <div className="mt-3 flex gap-2">
          <Button size="sm" onClick={handleSubmitReply} disabled={isSubmitting}>
            {isSubmitting ? "Enviando..." : "Enviar"}
          </Button>
          <Button variant="outline" size="sm" onClick={onCancel}>
            Cancelar
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

// Memoized sorting function
const sortComments = (comments: Comment[], order: SortOption): Comment[] => {
  const commentsToSort = [...comments] // Create a shallow copy
  return commentsToSort.sort((a, b) => {
    const aDate =
      a.createdAt && typeof (a.createdAt as Timestamp).toDate === "function"
        ? (a.createdAt as Timestamp).toDate()
        : new Date(0)
    const bDate =
      b.createdAt && typeof (b.createdAt as Timestamp).toDate === "function"
        ? (b.createdAt as Timestamp).toDate()
        : new Date(0)

    const aNetVotes = (a.likes || 0) - (a.dislikes || 0)
    const bNetVotes = (b.likes || 0) - (b.dislikes || 0)

    switch (order) {
      case "oldest":
        return aDate.getTime() - bDate.getTime()
      case "mostVoted":
        if (bNetVotes !== aNetVotes) {
          return bNetVotes - aNetVotes
        }
        return bDate.getTime() - aDate.getTime() // Secondary sort: newest
      case "newest":
      default:
        return bDate.getTime() - aDate.getTime()
    }
  })
}

function buildCommentTree(comments: Comment[]): Comment[] {
  const commentMap = new Map<string, Comment & { replies: Comment[] }>()
  comments.forEach((comment) => {
    commentMap.set(comment.id, { ...comment, replies: [] })
  })
  const rootComments: (Comment & { replies: Comment[] })[] = []
  comments.forEach((comment) => {
    const commentWithReplies = commentMap.get(comment.id)!
    if (comment.parentId) {
      const parentComment = commentMap.get(comment.parentId)
      if (parentComment) {
        parentComment.replies.push(commentWithReplies)
      } else {
        rootComments.push(commentWithReplies) // Orphan reply, treat as root
      }
    } else {
      rootComments.push(commentWithReplies)
    }
  })
  return rootComments
}

export function CommentSection({ dealId, comments: initialComments, isDisabled = false }: CommentSectionProps) {
  const { user } = useAuth()
  const { userData } = useUserData(user?.uid)
  const [newComment, setNewComment] = useState("")
  const [replyToId, setReplyToId] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)
  const [showReportConfirm, setShowReportConfirm] = useState(false)
  const [commentToReport, setCommentToReport] = useState<Comment | null>(null)
  const [reportedCommentIds, setReportedCommentIds] = useState<Set<string>>(new Set())

  const [sortOrder, setSortOrder] = useState<SortOption>("newest")
  const [commentsData, setCommentsData] = useState<Comment[]>(() => sortComments(initialComments, "newest"))

  const [userCommentVotes, setUserCommentVotes] = useState<Map<string, "like" | "dislike">>(new Map())
  const [loadingVotes, setLoadingVotes] = useState(false)
  const [votingStates, setVotingStates] = useState<Record<string, boolean>>({})

  useEffect(() => {
    setCommentsData((prevLocalComments) => {
      const localCommentsMap = new Map(prevLocalComments.map((c) => [c.id, c]))
      const mergedComments = initialComments.map((propComment) => {
        const existingLocalComment = localCommentsMap.get(propComment.id)
        if (existingLocalComment) {
          return {
            ...propComment,
            likes: existingLocalComment.likes,
            dislikes: existingLocalComment.dislikes,
          }
        }
        return propComment
      })
      return sortComments(mergedComments, sortOrder)
    })
  }, [initialComments, sortOrder])

  useEffect(() => {
    if (user && initialComments.length > 0) {
      setLoadingVotes(true)
      const commentIds = initialComments.map((c) => c.id)
      const q = query(
        collection(db, "commentVotes"),
        where("userId", "==", user.uid),
        where("commentId", "in", commentIds.length > 0 ? commentIds : ["dummy_id_to_avoid_error"]),
      )
      getDocs(q)
        .then((snapshot) => {
          const votes = new Map<string, "like" | "dislike">()
          snapshot.forEach((doc) => {
            const voteData = doc.data() as CommentVote
            votes.set(voteData.commentId, voteData.voteType)
          })
          setUserCommentVotes(votes)
        })
        .catch((error) => {
          console.error("Error fetching comment votes:", error)
          toast({ title: "Error", description: "No se pudieron cargar tus votos.", variant: "destructive" })
        })
        .finally(() => {
          setLoadingVotes(false)
        })
    } else {
      setUserCommentVotes(new Map())
    }
  }, [user, initialComments])

  useEffect(() => {
    if (user && initialComments.length > 0) {
      const commentIds = initialComments.map((c) => c.id)
      const q = query(
        collection(db, "commentReports"),
        where("reporterId", "==", user.uid),
        where("commentId", "in", commentIds.length > 0 ? commentIds : ["dummy_id_if_empty_to_avoid_error"]),
      )
      getDocs(q).then((snapshot) => {
        const reportedIds = new Set<string>()
        snapshot.forEach((doc) => reportedIds.add(doc.data().commentId))
        setReportedCommentIds(reportedIds)
      })
    }
  }, [user, initialComments])

  const commentTree = useMemo(() => buildCommentTree(commentsData), [commentsData])

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      setShowLoginModal(true)
      return
    }
    if (!newComment.trim() || isSubmitting) return
    setIsSubmitting(true)
    try {
      let userName = userData?.displayName
      if (!userName && user) {
        const userDoc = await getDoc(doc(db, "users", user.uid))
        if (userDoc.exists()) {
          userName = userDoc.data().displayName
        }
      }
      userName =
        userName || user?.email?.split("@")[0] || (user ? `Usuario_${user.uid.substring(0, 5)}` : "Usuario Anónimo")
      const newCommentInfo = await addDocument("comments", {
        dealId,
        userId: user!.uid,
        userName: userName,
        userPhotoURL: user!.photoURL,
        content: newComment,
        parentId: null,
        status: "visible",
        likes: 0,
        dislikes: 0,
        // createdAt will be set by addDocument
      })
      const newCommentId = newCommentInfo.id
      const dealRef = doc(db, "deals", dealId)
      await updateDoc(dealRef, {
        commentCount: increment(1),
        updatedAt: serverTimestamp(),
      })

      // Alert generation block for new comment
      const dealDocRef = doc(db, "deals", dealId)
      const dealDocSnap = await getDoc(dealDocRef)

      if (dealDocSnap.exists()) {
        const dealData = dealDocSnap.data() as Deal
        const commenterName = userName

        // 1. Alert for Deal Publisher
        if (dealData.publisherId && dealData.publisherId !== user.uid) {
          await addDocument("alerts", {
            userId: dealData.publisherId,
            type: "deal_comment_own",
            content: `${commenterName} comentó en tu chollo: "${dealData.title}"`,
            relatedId: dealId,
            relatedSubId: newCommentId,
            read: false,
            triggeringUserId: user.uid,
            triggeringUserName: commenterName,
            dealTitle: dealData.title,
          })
        }

        // 2. Alert for Subscribers
        const favoritesQuery = query(collection(db, "favorites"), where("dealId", "==", dealId))
        const favoritesSnap = await getDocs(favoritesQuery)
        favoritesSnap.forEach(async (favDoc) => {
          const subscriberId = favDoc.data().userId
          if (subscriberId !== user.uid && subscriberId !== dealData.publisherId) {
            await addDocument("alerts", {
              userId: subscriberId,
              type: "subscribed_deal_comment",
              content: `${commenterName} comentó en un chollo que sigues: "${dealData.title}"`,
              relatedId: dealId,
              relatedSubId: newCommentId,
              read: false,
              triggeringUserId: user.uid,
              triggeringUserName: commenterName,
              dealTitle: dealData.title,
            })
          }
        })
      }

      setNewComment("")
      // No need to manually add to commentsData, Firestore listener will update initialComments
    } catch (error) {
      console.error("Error al añadir comentario:", error)
      toast({ title: "Error", description: "No se pudo publicar el comentario.", variant: "destructive" })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleReportComment = (comment: Comment) => {
    if (!user) {
      setShowLoginModal(true)
      return
    }
    setCommentToReport(comment)
    setShowReportConfirm(true)
  }

  const confirmReportComment = async () => {
    if (!commentToReport || !user) return
    try {
      let reporterName = userData?.displayName || user.email?.split("@")[0] || `Usuario_${user.uid.substring(0, 5)}`
      if (!userData?.displayName && user.uid) {
        const userDocSnap = await getDoc(doc(db, "users", user.uid))
        if (userDocSnap.exists()) reporterName = userDocSnap.data().displayName || reporterName
      }
      await addDocument("commentReports", {
        commentId: commentToReport.id,
        commentContent: commentToReport.content,
        commentAuthorId: commentToReport.userId,
        commentAuthorName: commentToReport.userName,
        reporterId: user.uid,
        reporterName: reporterName,
        createdAt: serverTimestamp(),
        status: "pending",
      })
      toast({ title: "Comentario Reportado", description: "Gracias por ayudarnos a mantener la comunidad." })
      setReportedCommentIds((prev) => new Set(prev).add(commentToReport.id))
    } catch (error) {
      console.error("Error reporting comment:", error)
      toast({ title: "Error", description: "No se pudo reportar el comentario.", variant: "destructive" })
    } finally {
      setShowReportConfirm(false)
      setCommentToReport(null)
    }
  }

  const handleCommentVote = async (commentId: string, voteType: "like" | "dislike") => {
    if (!user) {
      setShowLoginModal(true)
      return
    }
    if (votingStates[commentId]) return

    setVotingStates((prev) => ({ ...prev, [commentId]: true }))

    const existingVoteType = userCommentVotes.get(commentId)
    const commentRef = doc(db, "comments", commentId)
    const voteQuery = query(
      collection(db, "commentVotes"),
      where("commentId", "==", commentId),
      where("userId", "==", user.uid),
    )

    try {
      const batch = writeBatch(db)
      const voteSnapshot = await getDocs(voteQuery)
      const existingVoteDoc = voteSnapshot.docs[0]

      let newLikesIncrement = 0
      let newDislikesIncrement = 0
      const updatedUserVotes = new Map(userCommentVotes)

      if (existingVoteDoc) {
        const voteData = existingVoteDoc.data() as CommentVote
        if (voteData.voteType === voteType) {
          batch.delete(existingVoteDoc.ref)
          if (voteType === "like") newLikesIncrement = -1
          else newDislikesIncrement = -1
          updatedUserVotes.delete(commentId)
        } else {
          batch.update(existingVoteDoc.ref, { voteType, createdAt: serverTimestamp() })
          if (voteType === "like") {
            newLikesIncrement = 1
            newDislikesIncrement = -1
          } else {
            newLikesIncrement = -1
            newDislikesIncrement = 1
          }
          updatedUserVotes.set(commentId, voteType)
        }
      } else {
        const newVoteRef = doc(collection(db, "commentVotes"))
        batch.set(newVoteRef, {
          commentId,
          userId: user.uid,
          voteType,
          createdAt: serverTimestamp(),
        })
        if (voteType === "like") newLikesIncrement = 1
        else newDislikesIncrement = 1
        updatedUserVotes.set(commentId, voteType)
      }

      const updates: { likes?: any; dislikes?: any } = {}
      if (newLikesIncrement !== 0) updates.likes = increment(newLikesIncrement)
      if (newDislikesIncrement !== 0) updates.dislikes = increment(newDislikesIncrement)
      if (Object.keys(updates).length > 0) {
        batch.update(commentRef, updates)
      }

      await batch.commit()

      setCommentsData((prevComments) => {
        const updatedComments = prevComments.map((c) =>
          c.id === commentId
            ? {
                ...c,
                likes: (c.likes || 0) + newLikesIncrement,
                dislikes: (c.dislikes || 0) + newDislikesIncrement,
              }
            : c,
        )
        return sortComments(updatedComments, sortOrder) // Re-sort after optimistic update
      })
      setUserCommentVotes(updatedUserVotes)
    } catch (error) {
      console.error("Error voting on comment:", error)
      toast({ title: "Error", description: "No se pudo registrar tu voto.", variant: "destructive" })
    } finally {
      setVotingStates((prev) => ({ ...prev, [commentId]: false }))
    }
  }

  const CommentItem = ({ comment, depth = 0 }: { comment: Comment; depth?: number }) => {
    const commentTimestamp = comment.createdAt as Timestamp
    const formattedDate = commentTimestamp?.toDate
      ? formatDistanceToNow(commentTimestamp.toDate(), { addSuffix: true, locale: es })
      : "recientemente"
    const displayName = comment.userName || "Usuario"
    const avatarText = displayName.charAt(0).toUpperCase()
    const isReplying = replyToId === comment.id
    const maxDepth = 5
    const effectiveDepth = Math.min(depth, maxDepth)
    const indentClass = effectiveDepth > 0 ? `ml-${Math.min(effectiveDepth * 4, 16)}` : "" // Tailwind JIT needs full class names
    const hasBeenReportedByUser = reportedCommentIds.has(comment.id)

    const currentUserVote = userCommentVotes.get(comment.id)
    const isVoting = votingStates[comment.id] || loadingVotes

    if (comment.status === "deleted_by_moderator") {
      return (
        <div className={`mt-4 ${indentClass} relative`}>
          {depth > 0 && <div className="absolute left-[-16px] top-0 bottom-0 w-0.5 bg-border/60" />}
          {depth > 0 && <div className="absolute left-[-16px] top-6 w-4 h-0.5 bg-border/60" />}
          <Card
            className={`${depth > 0 ? "bg-muted/20" : "bg-background"} shadow-sm border-2 border-dashed border-muted-foreground/30`}
          >
            <CardContent className="p-4">
              <div className="flex items-center">
                <ShieldAlert className="h-5 w-5 mr-3 text-muted-foreground flex-shrink-0" />
                <p className="text-sm text-muted-foreground italic">
                  Este comentario ha sido eliminado por un moderador.
                </p>
              </div>
            </CardContent>
          </Card>
          {(comment as Comment & { replies: Comment[] }).replies &&
            (comment as Comment & { replies: Comment[] }).replies.length > 0 && (
              <div className="mt-4 space-y-4">
                {(comment as Comment & { replies: Comment[] }).replies.map((reply) => (
                  <CommentItem key={reply.id} comment={reply} depth={depth + 1} />
                ))}
              </div>
            )}
        </div>
      )
    }

    // Explicit Tailwind classes for indentation up to a reasonable max depth
    const indentClasses = [
      "", // depth 0
      "ml-4", // depth 1
      "ml-8", // depth 2
      "ml-12", // depth 3
      "ml-16", // depth 4
      "ml-16", // depth 5+ (capped at ml-16)
    ]
    const currentIndentClass = indentClasses[Math.min(depth, indentClasses.length - 1)]

    return (
      <div className={`mt-4 ${currentIndentClass} relative`}>
        {depth > 0 && <div className="absolute left-[-16px] top-0 bottom-0 w-0.5 bg-border/60" />}
        {depth > 0 && <div className="absolute left-[-16px] top-6 w-4 h-0.5 bg-border/60" />}
        <Card className={`${depth > 0 ? "bg-muted/20" : "bg-background"} shadow-sm`}>
          <CardContent className="p-4">
            <div className="flex gap-3">
              <Link href={`/perfil/${comment.userId}`} className="flex-shrink-0">
                <Avatar className="h-9 w-9">
                  <AvatarImage src={comment.userPhotoURL || undefined} alt={displayName} />
                  <AvatarFallback>{avatarText}</AvatarFallback>
                </Avatar>
              </Link>
              <div className="flex-1 min-w-0">
                <div className="relative">
                  <div className="flex items-center gap-2 mb-1 pr-10">
                    <Link
                      href={`/perfil/${comment.userId}`}
                      className="font-medium text-sm hover:text-primary hover:underline"
                    >
                      {displayName}
                    </Link>
                    <span className="text-xs text-muted-foreground">{formattedDate}</span>
                  </div>
                  {!isDisabled && user && user.uid !== comment.userId && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleReportComment(comment)}
                      disabled={hasBeenReportedByUser}
                      className="absolute top-[-4px] right-[-4px] h-7 w-7 text-muted-foreground hover:text-destructive"
                      aria-label="Reportar comentario"
                    >
                      <Flag className="h-3.5 w-3.5" />
                      {hasBeenReportedByUser && <span className="sr-only">(Reportado)</span>}
                    </Button>
                  )}
                </div>
                <p className="text-sm leading-relaxed mb-2">{comment.content}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  {!isDisabled && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-auto p-1 ${currentUserVote === "like" ? "text-primary" : ""}`}
                        onClick={() => handleCommentVote(comment.id, "like")}
                        disabled={isVoting || !user}
                        aria-pressed={currentUserVote === "like"}
                      >
                        {isVoting && votingStates[comment.id] ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />
                        ) : (
                          <ThumbsUp className="h-3.5 w-3.5 mr-1" />
                        )}
                        {comment.likes || 0}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-auto p-1 ${currentUserVote === "dislike" ? "text-destructive" : ""}`}
                        onClick={() => handleCommentVote(comment.id, "dislike")}
                        disabled={isVoting || !user}
                        aria-pressed={currentUserVote === "dislike"}
                      >
                        {isVoting && votingStates[comment.id] ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin mr-1" />
                        ) : (
                          <ThumbsDown className="h-3.5 w-3.5 mr-1" />
                        )}
                        {comment.dislikes || 0}
                      </Button>
                    </>
                  )}
                  {!isReplying && !isDisabled && (
                    <Button
                      variant="link"
                      size="sm"
                      className="h-auto p-0 text-xs text-muted-foreground hover:text-foreground ml-2"
                      onClick={() => {
                        if (!user) {
                          setShowLoginModal(true)
                          return
                        }
                        setReplyToId(comment.id)
                      }}
                    >
                      Responder
                    </Button>
                  )}
                </div>
              </div>
            </div>
            {isReplying && (
              <ReplyForm
                commentId={comment.id}
                dealId={dealId}
                onReplySubmitted={() => {
                  setReplyToId(null)
                }}
                onCancel={() => setReplyToId(null)}
              />
            )}
          </CardContent>
        </Card>
        {(comment as Comment & { replies: Comment[] }).replies &&
          (comment as Comment & { replies: Comment[] }).replies.length > 0 && (
            <div className="mt-4 space-y-4">
              {(comment as Comment & { replies: Comment[] }).replies.map((reply) => (
                <CommentItem key={reply.id} comment={reply} depth={depth + 1} />
              ))}
            </div>
          )}
      </div>
    )
  }

  return (
    <div className="mt-12">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold">Comentarios ({initialComments.length})</h3>
        <Select value={sortOrder} onValueChange={(value) => setSortOrder(value as SortOption)}>
          <SelectTrigger className="w-auto sm:w-[180px]">
            <SelectValue placeholder="Ordenar por..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Más recientes</SelectItem>
            <SelectItem value="oldest">Más antiguos</SelectItem>
            <SelectItem value="mostVoted">Más votados</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Card className="mb-8">
        <CardContent className="p-6">
          <form onSubmit={handleSubmitComment}>
            <Textarea
              placeholder={user ? "Escribe un comentario..." : "Inicia sesión para comentar"}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="min-h-[100px] resize-none"
              disabled={!user || isDisabled}
            />
            <div className="mt-4 flex justify-end">
              {user ? (
                <Button type="submit" disabled={isSubmitting || isDisabled}>
                  {isSubmitting ? "Enviando..." : "Publicar Comentario"}
                </Button>
              ) : (
                <Button type="button" onClick={() => setShowLoginModal(true)}>
                  Iniciar Sesión para Comentar
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>
      <div className="space-y-4">
        {commentTree.length > 0
          ? commentTree.map((comment) => <CommentItem key={comment.id} comment={comment as Comment} />) // Cast here
          : !loadingVotes &&
            initialComments.length === 0 && ( // Use initialComments.length for "no comments" check
              <Card>
                <CardContent className="p-8">
                  <p className="text-center text-muted-foreground">
                    No hay comentarios todavía. ¡Sé el primero en comentar!
                  </p>
                </CardContent>
              </Card>
            )}
        {loadingVotes && initialComments.length > 0 && (
          <div className="flex justify-center items-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2 text-muted-foreground">Cargando votos...</p>
          </div>
        )}
      </div>
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSignupClick={() => {
          setShowLoginModal(false)
          setShowSignupModal(true)
        }}
      />
      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onLoginClick={() => {
          setShowSignupModal(false)
          setShowLoginModal(true)
        }}
      />
      {commentToReport && (
        <AlertDialog open={showReportConfirm} onOpenChange={setShowReportConfirm}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
              <AlertDialogDescription>
                Estás a punto de reportar este comentario. Esta acción no se puede deshacer.
              </AlertDialogDescription>
              <blockquote className="mt-4 border-l-2 pl-6 italic text-sm text-muted-foreground">
                "{commentToReport.content}"
              </blockquote>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setCommentToReport(null)}>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={confirmReportComment} className="bg-destructive hover:bg-destructive/90">
                Reportar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  )
}
