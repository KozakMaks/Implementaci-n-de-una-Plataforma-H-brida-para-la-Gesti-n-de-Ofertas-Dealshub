/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Your other Next.js configurations can go here
};

// Import next-pwa
import withPWAInit from "next-pwa";

// Initialize next-pwa with your desired options
const withPWA = withPWAInit({
  dest: "public", // Destination directory for PWA files
  register: true, // Automatically register the service worker
  skipWaiting: true, // Force the waiting service worker to become active
  disable: process.env.NODE_ENV === "development", // Disable PWA in development
  cacheOnFrontEndNav: true, // Cache pages navigated to on the client-side
  fallbacks: {
    // document: "/offline", // Fallback for document (HTML) when offline - uncomment if you create app/offline/page.tsx
    // image: "/placeholder.svg?width=300&height=300", // Fallback for images
    // font: "/fonts/fallback.woff2", // Fallback for fonts
    // audio: ...,
    // video: ...,
  },
  // You can add more advanced caching strategies here if needed
  // runtimeCaching: [ ... ]
});

export default withPWA(nextConfig);
