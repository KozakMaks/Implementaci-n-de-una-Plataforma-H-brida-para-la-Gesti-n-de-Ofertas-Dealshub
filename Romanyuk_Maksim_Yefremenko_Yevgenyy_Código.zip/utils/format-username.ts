/**
 * Formats a username with fallbacks to ensure a user-friendly display
 * @param user The user object from Firebase Auth or Firestore
 * @param defaultValue Optional default value if all else fails
 * @returns A formatted display name
 */
export function formatUsername(
  user: { displayName?: string | null; email?: string | null; uid?: string } | null | undefined,
  defaultValue = "Anonymous",
): string {
  if (!user) return defaultValue

  // Try displayName first
  if (user.displayName && user.displayName.trim()) {
    return user.displayName
  }

  // Fall back to email prefix
  if (user.email) {
    const emailPrefix = user.email.split("@")[0]
    return emailPrefix
  }

  // Last resort: use part of the UID
  if (user.uid) {
    return `User_${user.uid.substring(0, 5)}`
  }

  // If all else fails, return the default
  return defaultValue
}
