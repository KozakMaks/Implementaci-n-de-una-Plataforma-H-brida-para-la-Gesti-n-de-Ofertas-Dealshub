"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/hooks/use-auth"
import type { UserRole } from "@/hooks/use-roles" // Assuming UserRole is in use-roles or types
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { LogIn } from "lucide-react"

interface ProtectRouteProps {
  children: React.ReactNode
  requiredRoles: UserRole[]
  redirectTo?: string // Kept for potential future use or different behavior
  loginPromptTitle?: string
  loginPromptDescription?: string
}

export function ProtectRoute({
  children,
  requiredRoles,
  redirectTo = "/", // Default redirect if not showing inline prompt
  loginPromptTitle = "Inicia sesión para continuar",
  loginPromptDescription = "Necesitas iniciar sesión para acceder a esta página.",
}: ProtectRouteProps) {
  const { user, role, loading, setShowLoginModal, setShowSignupModal } = useAuth()
  const router = useRouter()

  const isAuthenticated = !!user
  const hasRequiredRole = isAuthenticated && requiredRoles.includes(role)

  useEffect(() => {
    // This effect is mainly for the redirect case, which we are now overriding
    // for unauthenticated users. If you want to keep redirection for some cases,
    // this logic might need adjustment.
    if (!loading && !isAuthenticated && redirectTo && !loginPromptTitle) {
      // Only redirect if no inline prompt is intended
      router.push(redirectTo)
    } else if (!loading && isAuthenticated && !hasRequiredRole) {
      // If authenticated but wrong role, redirect (standard behavior)
      router.push(redirectTo)
    }
  }, [isAuthenticated, hasRequiredRole, loading, router, requiredRoles, redirectTo, loginPromptTitle])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Cargando...</span>
      </div>
    )
  }

  if (!isAuthenticated) {
    // User is not logged in, show the login prompt card
    return (
      <div className="container mx-auto py-8 flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="text-center">
            <LogIn className="mx-auto h-12 w-12 mb-4 text-primary" />
            <CardTitle className="text-2xl">{loginPromptTitle}</CardTitle>
            <CardDescription className="mt-2">{loginPromptDescription}</CardDescription>
          </CardHeader>
          <CardFooter className="flex flex-col sm:flex-row gap-3">
            <Button onClick={() => setShowLoginModal(true)} className="w-full">
              Iniciar Sesión
            </Button>
            <Button variant="outline" onClick={() => setShowSignupModal(true)} className="w-full">
              Registrarse
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  if (!hasRequiredRole) {
    // User is authenticated but does not have the required role.
    // You might want to show a "Permission Denied" message here instead of just null or redirecting.
    // For now, it will redirect based on the useEffect, or show nothing if redirect doesn't happen.
    // To show a message:
    // return (
    //   <div className="flex items-center justify-center min-h-screen">
    //     <p>No tienes permiso para acceder a esta página.</p>
    //   </div>
    // );
    return null // Or redirect as per useEffect
  }

  // If user is authenticated and has the required role, show the protected content
  return <>{children}</>
}

// Helper component for loading, if you want to use it elsewhere
function Loader2({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M21 12a9 9 0 1 1-6.219-8.56" />
    </svg>
  )
}
