// This file should be the version from the previous turn,
// which exports formatPriceForDisplay, parsePriceFromDisplay, etc.
// For clarity, here are the key exports it should have:

export const formatPriceForDisplay = (price: number | null | undefined): string => {
  if (price === null || price === undefined || isNaN(price)) return "" // Return empty string for invalid/empty
  return new Intl.NumberFormat("es-ES", { style: "currency", currency: "EUR" }).format(price)
}

export const parsePriceFromDisplay = (priceString: string): number => {
  if (!priceString) return Number.NaN
  const cleanedString = priceString.replace(/€/g, "").replace(/\s/g, "").replace(/\./g, "").replace(/,/g, ".")
  const price = Number.parseFloat(cleanedString)
  return isNaN(price) ? Number.NaN : price
}

export const formatNumberForDisplay = (num: number | null | undefined, options?: Intl.NumberFormatOptions): string => {
  if (num === null || num === undefined || isNaN(num)) return ""
  const defaultOptions: Intl.NumberFormatOptions = {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
    ...options,
  }
  return new Intl.NumberFormat("es-ES", defaultOptions).format(num)
}

export const parseNumberFromDisplay = (numString: string): number => {
  if (!numString) return Number.NaN
  const cleanedString = numString
    .replace(/\.(?=\d{3}(?:,|$))/g, "") // Remove thousand separators (.) only if followed by 3 digits and comma or end of string
    .replace(/,/g, ".")
  const num = Number.parseFloat(cleanedString)
  return isNaN(num) ? Number.NaN : num
}
