import {
  collection,
  query,
  where,
  getDocs,
  limit,
  orderBy,
  type QueryConstraint, // Ensure this type is imported
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Deal } from "@/types"

// Helper to normalize text for searching
const normalizeText = (text = ""): string => {
  return text
    .toLowerCase()
    .normalize("NFD") // Decompose accented characters
    .replace(/[\u0300-\u036f]/g, "") // Remove diacritics
}

export async function findDealsFromFirebase(searchTerm: string, minPrice?: number, maxPrice?: number): Promise<Deal[]> {
  const dealsRef = collection(db, "deals")
  const q_constraints: QueryConstraint[] = []

  // Price filtering
  let hasPriceFilter = false
  if (minPrice !== undefined) {
    q_constraints.push(where("discountedPrice", ">=", minPrice))
    hasPriceFilter = true
  }
  if (maxPrice !== undefined) {
    q_constraints.push(where("discountedPrice", "<=", maxPrice))
    hasPriceFilter = true
  }

  // Order by discountedPrice if price filters are applied, otherwise by creation date or upvotes.
  // Firestore requires the first orderBy field to match the field used in inequality range filters.
  if (hasPriceFilter) {
    q_constraints.push(orderBy("discountedPrice"))
    q_constraints.push(orderBy("upvotes", "desc")) // Secondary sort
  } else {
    q_constraints.push(orderBy("upvotes", "desc")) // Default sort by popularity
    q_constraints.push(orderBy("createdAt", "desc")) // Secondary sort
  }

  q_constraints.push(limit(20)) // Fetch a batch for AI/server to filter/rank

  const finalQuery = query(dealsRef, ...q_constraints)

  try {
    const snapshot = await getDocs(finalQuery)
    const deals: Deal[] = []
    snapshot.forEach((doc) => {
      deals.push({ id: doc.id, ...doc.data() } as Deal)
    })

    const normalizedSearchTerm = normalizeText(searchTerm)
    if (!normalizedSearchTerm) {
      return deals
    }

    // Split into keywords. Keep words of length 2 or more, or if the entire term is 1 char.
    // This ensures "rx", "rtx" are kept. "o", "a" are dropped if part of "rx o rtx".
    const tempKeywords = normalizedSearchTerm.split(" ")
    let searchKeywords = tempKeywords.filter((k) => k.length >= 2 || normalizedSearchTerm.length === 1)

    // If filtering removed all keywords (e.g. "a de o"), but the original term had some substance,
    // try using the original split words if there was only one or two.
    if (searchKeywords.length === 0 && tempKeywords.length > 0 && tempKeywords.length <= 2) {
      searchKeywords = tempKeywords.filter((k) => k.length > 0) // take all non-empty parts
    }

    // If still no keywords, and the normalized term is not empty, use the full normalized term as a single keyword.
    // This handles cases like a single short word "ram" or a specific code "x5".
    if (searchKeywords.length === 0 && normalizedSearchTerm.length > 0) {
      searchKeywords = [normalizedSearchTerm]
    }

    // If searchKeywords is still genuinely empty (e.g. input was " "), return all.
    if (searchKeywords.length === 0) return deals

    return deals.filter((deal) => {
      const dealText = normalizeText(
        `${deal.title} ${deal.description || ""} ${deal.category || ""} ${deal.tags?.join(" ") || ""}`,
      )

      // If searchKeywords ended up empty (e.g. original term was "o" and got filtered out),
      // but normalizedSearchTerm itself is valid, use it directly.
      if (searchKeywords.length === 0 && normalizedSearchTerm.length > 0) {
        return dealText.includes(normalizedSearchTerm)
      }
      // If there are no valid search keywords to filter by (e.g. term was empty or only very short words),
      // return true to include the deal (it's already been price-filtered by Firestore query).
      if (searchKeywords.length === 0) return true

      // Check if ANY of the derived search keywords are present in the deal text.
      // This makes the function broader in its matching for a given searchTerm.
      return searchKeywords.some((keyword) => dealText.includes(keyword))
    })
  } catch (error) {
    console.error("Error fetching deals from Firebase:", error)
    return [] // Return empty array on error
  }
}
