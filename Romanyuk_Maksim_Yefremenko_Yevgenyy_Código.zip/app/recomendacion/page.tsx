"use client"

import type React from "react"
import { useState, useEffect, useRef, type FormEvent } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Loader2, Bot, User, Search, Brain, MessageSquare, AlertTriangle } from "lucide-react"
import ReactMarkdown from "react-markdown"
import { cn } from "@/lib/utils"
import { DealCard } from "@/components/deals/deal-card"
import type { Deal, UserRole } from "@/types" // Ensure UserRole is imported if not already
import { fetchDealsByIds } from "@/app/actions/fetch-deals-by-ids"
import { ProtectRoute } from "@/utils/protect-route" // Corrected import name

interface AiRecommendedDealInfo {
  // From AnalysisModule
  id: string
  name: string // AI might slightly change the name, or use original
  score: number
  reason: string
  discountedPrice: number // AI's view of price, could be from analysis
  originalPrice: number
}

interface Message {
  id: string
  role: "user" | "assistant"
  content: string // AI's conversational text
  aiRecommendedInfo?: AiRecommendedDealInfo[] // Info from AI's analysis
  fullDealDetails?: Deal[] // Full deal objects fetched from Firestore
}

type LoadingPhase = "idle" | "searching" | "analyzing" | "fetchingDetails" | "generating" | "error" | "success"

const phaseMessages: Record<LoadingPhase, string> = {
  idle: "",
  searching: "Buscando ofertas relevantes...",
  analyzing: "Analizando las mejores opciones...",
  fetchingDetails: "Cargando detalles de las ofertas...",
  generating: "Generando tu recomendación personalizada...",
  error: "Ha ocurrido un error.",
  success: "¡Aquí tienes tus recomendaciones!",
}

// This is the actual page component
function AiRecommendationPageContent() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loadingPhase, setLoadingPhase] = useState<LoadingPhase>("idle")
  const [currentError, setCurrentError] = useState<string | null>(null)

  const messagesEndRef = useRef<null | HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(scrollToBottom, [messages, loadingPhase])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!input.trim() || (loadingPhase !== "idle" && loadingPhase !== "success" && loadingPhase !== "error")) return

    const newUserMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    }
    setMessages((prevMessages) => [...prevMessages, newUserMessage])
    setInput("")
    setCurrentError(null)
    setLoadingPhase("searching")

    const phaseTimer1 = setTimeout(() => {
      if (loadingPhase === "searching") setLoadingPhase("analyzing")
    }, 1500)
    const phaseTimer2 = setTimeout(() => {
      if (loadingPhase === "analyzing") setLoadingPhase("generating")
    }, 3000)

    try {
      const aiApiResponse = await fetch("/api/ai-recommendations-v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: newUserMessage.content }),
      })

      clearTimeout(phaseTimer1)
      clearTimeout(phaseTimer2)

      if (!aiApiResponse.ok) {
        const errorData = await aiApiResponse
          .json()
          .catch(() => ({ error: "Error desconocido al procesar la respuesta." }))
        throw new Error(errorData.error || `Error del servidor: ${aiApiResponse.status}`)
      }

      const aiData: { finalText: string; selectedDeals?: AiRecommendedDealInfo[] } = await aiApiResponse.json()

      let fetchedFullDeals: Deal[] = []
      if (aiData.selectedDeals && aiData.selectedDeals.length > 0) {
        setLoadingPhase("fetchingDetails")
        const dealIdsToFetch = aiData.selectedDeals.map((d) => d.id)
        const fetchResponse = await fetchDealsByIds(dealIdsToFetch)

        if (fetchResponse.success && fetchResponse.deals) {
          fetchedFullDeals = fetchResponse.deals
        } else {
          console.warn("Failed to fetch full deal details:", fetchResponse.error)
        }
      }

      setLoadingPhase("generating")

      if (aiData.finalText) {
        const newAssistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: aiData.finalText,
          aiRecommendedInfo: aiData.selectedDeals || [],
          fullDealDetails: fetchedFullDeals.length > 0 ? fetchedFullDeals : undefined,
        }
        setMessages((prevMessages) => [...prevMessages, newAssistantMessage])
        setLoadingPhase("success")
      } else {
        throw new Error("Respuesta inesperada del servidor AI.")
      }
    } catch (err: any) {
      clearTimeout(phaseTimer1)
      clearTimeout(phaseTimer2)
      console.error("Error in handleSubmit:", err)
      setCurrentError(err.message || "Fallo al obtener respuesta.")
      setLoadingPhase("error")
      const newErrorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `Lo siento, ocurrió un error: ${err.message || "No pude procesar tu solicitud."}`,
      }
      setMessages((prevMessages) => [...prevMessages, newErrorMessage])
    }
  }

  const isLoading = loadingPhase !== "idle" && loadingPhase !== "success" && loadingPhase !== "error"

  return (
    <div className="container mx-auto py-4 sm:py-8 flex flex-col h-[calc(100vh-10rem)] items-center">
      <Card className="flex-1 flex flex-col w-full max-w-5xl shadow-xl rounded-lg">
        <CardHeader className="border-b bg-slate-50 dark:bg-slate-800 rounded-t-lg">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10 border-2 border-primary">
              <AvatarFallback>
                <Bot />
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-lg font-semibold text-slate-800 dark:text-slate-100">
                Asistente de Chollos IA
              </CardTitle>
              <CardDescription className="text-xs text-slate-600 dark:text-slate-400">
                Dime qué buscas y te ayudaré a encontrar las mejores ofertas.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto space-y-6 p-6 bg-white dark:bg-slate-900">
          {messages.length === 0 && !isLoading && loadingPhase === "idle" && (
            <div className="text-center text-slate-500 dark:text-slate-400 pt-10">
              <Bot className="mx-auto h-12 w-12 mb-4 text-slate-400 dark:text-slate-500" />
              <p className="text-sm">¿En qué tipo de chollo estás interesado hoy?</p>
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} className="w-full">
              <div className={cn("flex gap-3 text-sm", m.role === "user" ? "justify-end" : "justify-start")}>
                {m.role === "assistant" && (
                  <Avatar className="h-8 w-8 border flex-shrink-0 bg-primary text-primary-foreground">
                    <Bot className="h-5 w-5 m-auto" />
                  </Avatar>
                )}
                <div
                  className={cn(
                    "rounded-lg p-3 shadow-sm max-w-[90%] sm:max-w-[85%]",
                    m.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100",
                  )}
                >
                  <ReactMarkdown
                    components={{
                      p: ({ node, ...props }) => <p className="mb-2 last:mb-0" {...props} />,
                      h3: ({ node, ...props }) => <h3 className="text-md font-semibold mt-3 mb-1" {...props} />,
                      ul: ({ node, ...props }) => <ul className="list-disc pl-5 mb-2 space-y-1" {...props} />,
                      li: ({ node, ...props }) => <li {...props} />,
                      strong: ({ node, ...props }) => <strong className="font-semibold" {...props} />,
                      a: ({ node, href, ...props }) => {
                        if (href?.startsWith("dealId:")) {
                          const dealId = href.substring(7)
                          return (
                            <Link
                              href={`/chollo/${dealId}`}
                              className="text-primary hover:underline font-semibold"
                              {...props}
                              target="_blank"
                              rel="noopener noreferrer"
                            />
                          )
                        }
                        return (
                          <a
                            href={href}
                            className="text-primary hover:underline"
                            target="_blank"
                            rel="noopener noreferrer"
                            {...props}
                          />
                        )
                      },
                      hr: ({ node, ...props }) => (
                        <hr className="my-3 border-slate-200 dark:border-slate-700" {...props} />
                      ),
                    }}
                  >
                    {m.content}
                  </ReactMarkdown>
                </div>
                {m.role === "user" && (
                  <Avatar className="h-8 w-8 border flex-shrink-0 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                    <User className="h-5 w-5 m-auto" />
                  </Avatar>
                )}
              </div>
              {m.role === "assistant" && m.aiRecommendedInfo && m.aiRecommendedInfo.length > 0 && (
                <div className="mt-4 space-y-6">
                  <div className="overflow-x-auto w-full">
                    <h4 className="text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">
                      Tabla de Recomendaciones:
                    </h4>
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 border border-slate-200 dark:border-slate-700 rounded-md shadow-sm">
                      <thead className="bg-slate-50 dark:bg-slate-800">
                        <tr>
                          <th
                            scope="col"
                            className="px-4 py-2.5 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider max-w-xs"
                          >
                            Producto
                          </th>
                          <th
                            scope="col"
                            className="px-4 py-2.5 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider"
                          >
                            Puntuación
                          </th>
                          <th
                            scope="col"
                            className="px-4 py-2.5 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider"
                          >
                            Razón (IA)
                          </th>
                          <th
                            scope="col"
                            className="px-4 py-2.5 text-left text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider"
                          >
                            Precio (IA)
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                        {m.aiRecommendedInfo.map((aiDeal) => (
                          <tr key={aiDeal.id} className="align-top">
                            <td className="px-4 py-3 text-sm font-medium text-slate-900 dark:text-slate-100 max-w-xs">
                              <Link
                                href={`/chollo/${aiDeal.id}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="hover:underline text-primary block truncate"
                                title={aiDeal.name}
                              >
                                {aiDeal.name}
                              </Link>
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300 text-center">
                              {aiDeal.score}
                              {"/3"}
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-600 dark:text-slate-300 min-w-[200px]">
                              {aiDeal.reason}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">
                              <div className="flex flex-col">
                                <span className="font-semibold text-slate-800 dark:text-slate-100">
                                  €{aiDeal.discountedPrice.toFixed(2)}
                                </span>
                                {aiDeal.originalPrice > aiDeal.discountedPrice && (
                                  <span className="text-xs line-through text-slate-500 dark:text-slate-400">
                                    €{aiDeal.originalPrice.toFixed(2)}
                                  </span>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {m.fullDealDetails && m.fullDealDetails.length > 0 && (
                    <>
                      <h4 className="text-sm font-semibold mb-2 text-slate-700 dark:text-slate-300">
                        Tarjetas de Oferta:
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {m.fullDealDetails.map((fullDeal) => (
                          <DealCard key={fullDeal.id} deal={fullDeal} />
                        ))}
                      </div>
                    </>
                  )}
                  {m.aiRecommendedInfo && (!m.fullDealDetails || m.fullDealDetails.length === 0) && (
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      No se pudieron cargar todos los detalles para las tarjetas de oferta.
                    </p>
                  )}
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 text-sm justify-start items-center p-3">
              <Avatar className="h-8 w-8 border flex-shrink-0 bg-primary text-primary-foreground">
                {loadingPhase === "searching" && <Search className="h-5 w-5 m-auto animate-pulse" />}
                {loadingPhase === "analyzing" && <Brain className="h-5 w-5 m-auto animate-spin" />}
                {loadingPhase === "fetchingDetails" && <Loader2 className="h-5 w-5 m-auto animate-spin" />}
                {loadingPhase === "generating" && <MessageSquare className="h-5 w-5 m-auto animate-bounce" />}
              </Avatar>
              <div className="rounded-lg p-3 shadow-sm bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 flex items-center">
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                {phaseMessages[loadingPhase]}
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </CardContent>
        {currentError && loadingPhase === "error" && (
          <CardFooter className="border-t p-3 bg-red-50 dark:bg-red-900/30">
            <p className="text-xs text-destructive dark:text-red-400 flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2" /> Error: {currentError}
            </p>
          </CardFooter>
        )}
        <CardFooter className="border-t p-4 bg-slate-50 dark:bg-slate-800 rounded-b-lg">
          <form onSubmit={handleSubmit} className="flex w-full items-center space-x-2">
            <Input
              value={input}
              onChange={handleInputChange}
              placeholder="Describe el chollo que buscas..."
              disabled={isLoading}
              className="flex-1 bg-white dark:bg-slate-700 dark:text-slate-100 border-slate-300 dark:border-slate-600 focus:ring-primary"
            />
            <Button type="submit" disabled={isLoading} className="min-w-[90px]">
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Enviar"}
            </Button>
          </form>
        </CardFooter>
      </Card>
    </div>
  )
}

// This is the main exported component for the page
export default function AiRecommendationPage() {
  const requiredRoles: UserRole[] = ["user", "moderator", "admin"]

  return (
    <ProtectRoute
      requiredRoles={requiredRoles}
      loginPromptTitle="Inicia sesión para las Recomendaciones IA"
      loginPromptDescription="Necesitas iniciar sesión para usar nuestro asistente de IA y obtener recomendaciones personalizadas."
    >
      <AiRecommendationPageContent />
    </ProtectRoute>
  )
}

// UserRole should be imported from your types definition, e.g., types/index.ts
// type UserRole = "user" | "moderator" | "admin" | "guest";

// Dummy Loader2 component if not imported from lucide-react or similar
// const Loader2 = ({ className }: { className?: string }) => <div className={className}>Loading...</div>;
// Ensure Bot, User, Search, Brain, MessageSquare, AlertTriangle are imported from lucide-react
// Ensure cn, Card, Button, Input, Avatar, etc. are imported from their respective locations
