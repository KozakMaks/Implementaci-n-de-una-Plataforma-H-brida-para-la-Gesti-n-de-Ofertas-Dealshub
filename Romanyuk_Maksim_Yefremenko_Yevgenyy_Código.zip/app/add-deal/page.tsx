"use client"

import type React from "react"
import { useState, useRef } from "react" // Removed useEffect
import { useRouter } from "next/navigation"
import Image from "next/image"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"
import { addDoc, collection, serverTimestamp, doc, getDoc } from "firebase/firestore"
import { db, storage } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import { useUserData } from "@/hooks/use-user-data"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { AlertCircle, Upload, X, TicketPercent } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import { formatPriceForDisplay, parsePriceFromDisplay } from "@/lib/formatters"
// Removed unused: import { toast } from "@/components/ui/use-toast"

const CATEGORIES = [
  "Electrónica",
  "Moda",
  "Hogar y Jardín",
  "Belleza",
  "Deportes",
  "Juguetes",
  "Alimentación y Bebidas",
  "Viajes",
  "Servicios",
  "Otros",
]

export default function AddDealPage() {
  const { user } = useAuth()
  const { userData } = useUserData(user?.uid)
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [fullDescription, setFullDescription] = useState("")
  const [originalPriceInput, setOriginalPriceInput] = useState("") // For text input
  const [discountedPriceInput, setDiscountedPriceInput] = useState("") // For text input
  const [category, setCategory] = useState("")
  const [dealUrl, setDealUrl] = useState("")
  const [couponCode, setCouponCode] = useState("")
  const [image, setImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)

  const discountPercentage =
    originalPriceInput &&
    discountedPriceInput &&
    !isNaN(parsePriceFromDisplay(originalPriceInput)) &&
    !isNaN(parsePriceFromDisplay(discountedPriceInput)) &&
    parsePriceFromDisplay(originalPriceInput) > 0
      ? Math.round(
          ((parsePriceFromDisplay(originalPriceInput) - parsePriceFromDisplay(discountedPriceInput)) /
            parsePriceFromDisplay(originalPriceInput)) *
            100,
        )
      : 0

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 5 * 1024 * 1024) {
      setError("El tamaño de la imagen debe ser menor de 5MB")
      return
    }
    if (!file.type.startsWith("image/")) {
      setError("Por favor, sube un archivo de imagen")
      return
    }
    setImage(file)
    setError(null)
    const reader = new FileReader()
    reader.onload = () => setImagePreview(reader.result as string)
    reader.readAsDataURL(file)
  }

  const removeImage = () => {
    setImage(null)
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handlePriceChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: React.Dispatch<React.SetStateAction<string>>,
  ) => {
    setter(e.target.value)
  }

  const handlePriceBlur = (value: string, inputSetter: React.Dispatch<React.SetStateAction<string>>) => {
    const numericValue = parsePriceFromDisplay(value)
    if (!isNaN(numericValue)) {
      inputSetter(formatPriceForDisplay(numericValue))
    } else if (value.trim() !== "") {
      inputSetter("") // Clear if invalid and not empty, to prevent "NaN €"
    } else {
      inputSetter("") // Clear if empty
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      setShowLoginModal(true)
      return
    }

    if (!title || !description || !originalPriceInput || !discountedPriceInput || !category || !dealUrl) {
      setError("Por favor, completa todos los campos obligatorios")
      return
    }
    if (!image) {
      setError("Por favor, sube una imagen para el chollo")
      return
    }

    const origPrice = parsePriceFromDisplay(originalPriceInput)
    const discPrice = parsePriceFromDisplay(discountedPriceInput)

    if (isNaN(origPrice) || isNaN(discPrice)) {
      setError("Por favor, introduce precios válidos. Usa ',' para decimales.")
      setIsSubmitting(false)
      return
    }
    if (discPrice >= origPrice) {
      setError("El precio con descuento debe ser menor que el precio original")
      setIsSubmitting(false)
      return
    }

    setIsSubmitting(true)
    setError(null)

    try {
      const storageRefHandle = ref(storage, `deals/${Date.now()}_${image.name}`)
      const uploadResult = await uploadBytes(storageRefHandle, image)
      const imageUrl = await getDownloadURL(uploadResult.ref)

      let publisherName = userData?.displayName
      if (!publisherName && user?.uid) {
        const userDoc = await getDoc(doc(db, "users", user.uid))
        if (userDoc.exists()) {
          publisherName = userDoc.data().displayName
        }
      }
      publisherName = publisherName || user?.email?.split("@")[0] || `Usuario_${user?.uid.substring(0, 5) || "Anon"}`

      const trimmedCouponCode = couponCode.trim()

      // Explicitly type the object to be sent to Firestore for clarity
      // This type should match the structure expected by your 'deals' collection,
      // excluding fields like 'id' that Firestore generates.
      const dealDataForFirestore: { [key: string]: any } = {
        title,
        description,
        fullDescription,
        originalPrice: origPrice,
        discountedPrice: discPrice,
        discountPercentage,
        category,
        dealUrl,
        imageUrl,
        publisherId: user.uid,
        publisherName: publisherName,
        // couponCode will be added conditionally
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        upvotes: 0,
        downvotes: 0,
        commentCount: 0,
        isExpired: false,
      }

      if (trimmedCouponCode) {
        dealDataForFirestore.couponCode = trimmedCouponCode
      }
      // If trimmedCouponCode is empty, the couponCode field will not be added to dealDataForFirestore,
      // which is the correct way to handle optional fields that are not set.

      const docRef = await addDoc(collection(db, "deals"), dealDataForFirestore)
      router.push(`/chollo/${docRef.id}`)
    } catch (err) {
      console.error("Error adding deal:", err)
      setError("Error al añadir el chollo. Por favor, inténtalo de nuevo.")
      setIsSubmitting(false)
    }
  }

  if (!user) {
    return (
      <div className="container flex items-center justify-center py-16">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle>Inicia sesión para añadir un chollo</CardTitle>
            <CardDescription>Necesitas iniciar sesión para añadir nuevos chollos</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <p className="text-center text-muted-foreground">
              Únete a nuestra comunidad para compartir chollos increíbles con otros.
            </p>
            <div className="flex gap-4">
              <Button onClick={() => setShowLoginModal(true)}>Iniciar Sesión</Button>
              <Button variant="outline" onClick={() => setShowSignupModal(true)}>
                Registrarse
              </Button>
            </div>
          </CardContent>
        </Card>
        <LoginModal
          isOpen={showLoginModal}
          onClose={() => setShowLoginModal(false)}
          onSignupClick={() => {
            setShowLoginModal(false)
            setShowSignupModal(true)
          }}
        />
        <SignupModal
          isOpen={showSignupModal}
          onClose={() => setShowSignupModal(false)}
          onLoginClick={() => {
            setShowSignupModal(false)
            setShowLoginModal(true)
          }}
        />
      </div>
    )
  }

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Añadir un Nuevo Chollo</h1>
      <Card>
        <CardHeader>
          <CardTitle>Detalles del Chollo</CardTitle>
          <CardDescription>Comparte un chollo increíble con la comunidad</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="ej., Auriculares Inalámbricos Sony WH-1000XM4 con 30% de Descuento"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descripción Corta *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Breve descripción del chollo (máx. 200 caracteres)"
                maxLength={200}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fullDescription">Descripción Completa</Label>
              <Textarea
                id="fullDescription"
                value={fullDescription}
                onChange={(e) => setFullDescription(e.target.value)}
                placeholder="Descripción detallada del chollo, características, términos, etc."
                className="min-h-[150px]"
              />
            </div>

            <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="originalPrice">Precio Original *</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">€</span>
                  <Input
                    id="originalPrice"
                    type="text"
                    value={originalPriceInput}
                    onChange={(e) => handlePriceChange(e, setOriginalPriceInput)}
                    onBlur={(e) => handlePriceBlur(e.target.value, setOriginalPriceInput)}
                    className="pl-7 text-right"
                    placeholder="99,99"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="discountedPrice">Precio con Descuento *</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">€</span>
                  <Input
                    id="discountedPrice"
                    type="text"
                    value={discountedPriceInput}
                    onChange={(e) => handlePriceChange(e, setDiscountedPriceInput)}
                    onBlur={(e) => handlePriceBlur(e.target.value, setDiscountedPriceInput)}
                    className="pl-7 text-right"
                    placeholder="69,99"
                    required
                  />
                </div>
              </div>
            </div>

            {discountPercentage > 0 && (
              <div className="rounded-md bg-primary/10 p-3 text-center">
                <p className="text-sm font-medium">
                  Descuento: <span className="text-primary">{discountPercentage}% DESCUENTO</span>
                </p>
              </div>
            )}

            <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="category">Categoría *</Label>
                <Select value={category} onValueChange={setCategory} required>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Selecciona una categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="couponCode">Código de Cupón (Opcional)</Label>
                <div className="relative">
                  <TicketPercent className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="couponCode"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="ej., VERANO20"
                    className="pl-9"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dealUrl">URL del Chollo *</Label>
              <Input
                id="dealUrl"
                type="url"
                value={dealUrl}
                onChange={(e) => setDealUrl(e.target.value)}
                placeholder="https://ejemplo.com/producto"
                required
              />
            </div>

            <Separator />

            <div className="space-y-2">
              <Label htmlFor="image">Imagen del Chollo *</Label>
              {imagePreview ? (
                <div className="relative aspect-video w-full max-w-full overflow-hidden rounded-md border">
                  <Image
                    src={imagePreview || "/placeholder.svg?width=640&height=360&query=deal+product+image"}
                    alt="Vista previa del chollo"
                    fill
                    className="object-cover"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute right-2 top-2 h-8 w-8"
                    onClick={removeImage}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div
                  className="flex cursor-pointer flex-col items-center justify-center rounded-md border border-dashed p-8 text-center"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
                  <p className="mb-1 text-sm font-medium">Haz clic para subir una imagen</p>
                  <p className="text-xs text-muted-foreground">PNG, JPG o WEBP (máx. 5MB)</p>
                </div>
              )}
              <input
                ref={fileInputRef}
                id="image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Enviando..." : "Añadir Chollo"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
