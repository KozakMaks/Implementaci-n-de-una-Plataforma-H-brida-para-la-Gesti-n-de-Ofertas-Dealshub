"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { collection, query, orderBy, limit, getDocs, startAfter } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { DealCard } from "@/components/deals/deal-card"
import { Button } from "@/components/ui/button"
import { Loader2, Search } from "lucide-react"
import { NoData } from "@/components/ui/no-data"
import type { Deal } from "@/types"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const searchQuery = searchParams.get("q") || ""

  const [deals, setDeals] = useState<Deal[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(false)
  const [lastVisible, setLastVisible] = useState<any>(null)

  // Function to search deals
  const searchDeals = async (isLoadMore = false) => {
    if (!searchQuery.trim()) {
      setDeals([])
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Create a query to search deals
      // We'll search in title and description fields
      const searchTerms = searchQuery
        .toLowerCase()
        .split(" ")
        .filter((term) => term.length > 0)

      if (searchTerms.length === 0) {
        setDeals([])
        setLoading(false)
        return
      }

      // Create base query
      let q = query(collection(db, "deals"), orderBy("title"), limit(12))

      // If loading more, start after the last visible document
      if (isLoadMore && lastVisible) {
        q = query(
          collection(db, "deals"),
          orderBy("title"),
          // @ts-ignore - startAfter does exist but TypeScript doesn't recognize it
          startAfter(lastVisible),
          limit(12),
        )
      }

      const querySnapshot = await getDocs(q)

      // Filter results client-side based on search terms
      const results: Deal[] = []
      querySnapshot.forEach((doc) => {
        const deal = { id: doc.id, ...doc.data() } as Deal

        // Check if any search term is in the title or description
        const matchesSearch = searchTerms.some(
          (term) =>
            deal.title.toLowerCase().includes(term) ||
            (deal.description && deal.description.toLowerCase().includes(term)),
        )

        if (matchesSearch) {
          results.push(deal)
        }
      })

      // Update last visible document for pagination
      const lastDoc = querySnapshot.docs[querySnapshot.docs.length - 1]
      setLastVisible(lastDoc)
      setHasMore(querySnapshot.docs.length === 12)

      // Update deals state
      if (isLoadMore) {
        setDeals((prevDeals) => [...prevDeals, ...results])
      } else {
        setDeals(results)
      }
    } catch (err) {
      console.error("Error searching deals:", err)
      setError("Error al buscar chollos. Por favor, inténtalo de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  // Load deals when search query changes
  useEffect(() => {
    searchDeals()
  }, [searchQuery])

  const loadMoreDeals = () => {
    searchDeals(true)
  }

  return (
    <div className="container py-8">
      <div className="flex items-center gap-2 mb-6">
        <Search className="h-6 w-6" />
        <h1 className="text-3xl font-bold">
          {searchQuery ? (
            <>
              Resultados para <span className="text-primary">"{searchQuery}"</span>
            </>
          ) : (
            "Búsqueda"
          )}
        </h1>
      </div>

      {loading && deals.length === 0 && (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Buscando chollos...</span>
        </div>
      )}

      {error && (
        <div className="mt-8 text-center">
          <p className="text-red-500">{error}</p>
        </div>
      )}

      {!loading && !error && deals.length === 0 && (
        <NoData
          title="No se encontraron resultados"
          description={
            searchQuery
              ? `No hay chollos que coincidan con "${searchQuery}"`
              : "Introduce un término de búsqueda para encontrar chollos"
          }
          icon={<Search className="h-12 w-12" />}
        />
      )}

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {deals.map((deal) => (
          <DealCard key={deal.id} deal={deal} />
        ))}
      </div>

      {deals.length > 0 && hasMore && (
        <div className="mt-8 flex justify-center">
          <Button onClick={loadMoreDeals} variant="outline" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Cargando...
              </>
            ) : (
              "Cargar Más"
            )}
          </Button>
        </div>
      )}
    </div>
  )
}
