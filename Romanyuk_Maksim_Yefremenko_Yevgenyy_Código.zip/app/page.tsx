"use client"

import { useState, useEffect, useMemo } from "react"
import { orderBy, limit, where, type QueryConstraint } from "firebase/firestore"
import { useCollection } from "@/hooks/use-firestore"
import type { Deal } from "@/types"
import { DealCard } from "@/components/deals/deal-card"
import { DealFilter, type FiltersState } from "@/components/deals/deal-filter" // Assuming FiltersState is exported from DealFilter
import { Button } from "@/components/ui/button"

const MAX_PRICE = 1000
const PAGE_SIZE = 12 // Number of deals to load each time

export default function Home() {
  const [filters, setFilters] = useState<FiltersState>({
    sortBy: "newest",
    priceRange: [0, MAX_PRICE],
    selectedCategories: [] as string[],
    discountMin: 0,
  })

  // State for query constraints sent to Firestore
  const [queryConstraints, setQueryConstraints] = useState<QueryConstraint[]>([
    orderBy("createdAt", "desc"),
    limit(50), // Fetch a larger batch for client-side filtering/pagination
  ])

  // State for the number of deals currently displayed
  const [currentDisplayCount, setCurrentDisplayCount] = useState(PAGE_SIZE)

  // Effect to update Firestore query constraints when server-side filters change
  useEffect(() => {
    const constraints: QueryConstraint[] = []
    if (filters.selectedCategories.length > 0) {
      constraints.push(where("category", "in", filters.selectedCategories))
    }

    switch (filters.sortBy) {
      case "newest":
        constraints.push(orderBy("createdAt", "desc"))
        break
      case "popular":
        // Ensure 'upvotes' field exists and is indexed in Firestore
        constraints.push(orderBy("upvotes", "desc"))
        break
      case "discount":
        constraints.push(orderBy("discountPercentage", "desc"))
        break
      case "price-low":
        constraints.push(orderBy("discountedPrice", "asc"))
        break
      case "price-high":
        constraints.push(orderBy("discountedPrice", "desc"))
        break
      default:
        constraints.push(orderBy("createdAt", "desc"))
    }
    constraints.push(limit(50)) // Fetch up to 50 for client-side operations
    setQueryConstraints(constraints)
    setCurrentDisplayCount(PAGE_SIZE) // Reset display count when server-side filters change
  }, [filters.sortBy, filters.selectedCategories])

  // Fetch deals from Firestore based on queryConstraints
  const {
    documents: fetchedDealsFromFirestore,
    loading, // This loading is for the Firestore query
    error,
  } = useCollection("deals", queryConstraints, [JSON.stringify(queryConstraints)])

  // Memoized calculation of all deals that match client-side filters
  const allClientFilteredDeals = useMemo(() => {
    if (!fetchedDealsFromFirestore) return [] // Guard against undefined

    let filtered = [...fetchedDealsFromFirestore]

    // Apply price range filter
    filtered = filtered.filter((deal) => {
      const aboveMinPrice = deal.discountedPrice >= filters.priceRange[0]
      const belowMaxPrice = filters.priceRange[1] === MAX_PRICE || deal.discountedPrice <= filters.priceRange[1]
      return aboveMinPrice && belowMaxPrice
    })

    // Apply discount filter
    if (filters.discountMin > 0) {
      filtered = filtered.filter((deal) => deal.discountPercentage >= filters.discountMin)
    }
    return filtered
  }, [fetchedDealsFromFirestore, filters.priceRange, filters.discountMin])

  // State for deals actually rendered in the UI (sliced version)
  const [dealsToDisplay, setDealsToDisplay] = useState<Deal[]>([])

  // Effect to update dealsToDisplay based on allClientFilteredDeals and currentDisplayCount
  useEffect(() => {
    setDealsToDisplay(allClientFilteredDeals.slice(0, currentDisplayCount))
  }, [allClientFilteredDeals, currentDisplayCount])

  // Handler for when filters change from the DealFilter component
  const handleFilterChange = (newFilters: FiltersState) => {
    setFilters(newFilters)
    setCurrentDisplayCount(PAGE_SIZE) // Reset display count to show the first page of new filtered results
  }

  // Handler for the "Load More" button
  const loadMoreDeals = () => {
    setCurrentDisplayCount((prevCount) => prevCount + PAGE_SIZE)
  }

  // Determine if the "Load More" button should be visible
  const canLoadMore = dealsToDisplay.length < allClientFilteredDeals.length

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Últimos Chollos</h1>

      <DealFilter onFilterChange={handleFilterChange} initialFilters={filters} />

      {/* Show loading indicator only for the initial page load or when filters cause a full refresh */}
      {loading && dealsToDisplay.length === 0 && (
        <div className="mt-8 text-center">
          <p>Cargando chollos...</p>
        </div>
      )}

      {error && (
        <div className="mt-8 text-center">
          <p className="text-red-500">Error al cargar los chollos. Por favor, inténtalo de nuevo.</p>
        </div>
      )}

      {/* Show "no deals found" message if not loading and no deals to display */}
      {!loading && dealsToDisplay.length === 0 && allClientFilteredDeals.length === 0 && (
        <div className="mt-8 text-center">
          <p>No se encontraron chollos que coincidan con tus filtros.</p>
        </div>
      )}

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {dealsToDisplay.map((deal: Deal) => (
          <DealCard key={deal.id} deal={deal} />
        ))}
      </div>

      {canLoadMore && (
        <div className="mt-8 flex justify-center">
          {/* The button is not disabled by the main 'loading' state, as loading more is client-side */}
          <Button onClick={loadMoreDeals} variant="outline">
            Cargar Más
          </Button>
        </div>
      )}
    </div>
  )
}
