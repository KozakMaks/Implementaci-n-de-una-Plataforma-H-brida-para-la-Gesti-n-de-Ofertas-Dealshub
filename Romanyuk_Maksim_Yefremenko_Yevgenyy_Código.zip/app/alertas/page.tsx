"use client"

import { useState } from "react"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { where, orderBy, updateDoc, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import { useCollection } from "@/hooks/use-firestore"
import type { Alert, Subscription } from "@/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bell, MessageSquare, ThumbsUp, Tag, X } from "lucide-react"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import { useRouter } from "next/navigation"

// Import the useAlerts hook
import { useAlerts } from "@/hooks/use-alerts"

export default function AlertsPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)

  // Fetch subscriptions
  const { documents: subscriptions, loading: subscriptionsLoading } = useCollection(
    "subscriptions",
    user ? [where("userId", "==", user.uid), orderBy("createdAt", "desc")] : [],
    [user?.uid],
  )

  // Fetch alerts
  const { alerts, loading: alertsLoading, markAlertAsRead, markAllAsRead } = useAlerts(50)

  const markAsRead = async (alertId: string) => {
    if (!user) return

    try {
      const alertRef = doc(db, "alerts", alertId)
      await updateDoc(alertRef, {
        read: true,
      })
    } catch (error) {
      console.error("Error marking alert as read:", error)
    }
  }

  const removeSubscription = async (subscriptionId: string) => {
    if (!user) return

    try {
      // Delete subscription from Firestore
      // This would typically be done with a server-side function
      console.log("Removing subscription:", subscriptionId)
    } catch (error) {
      console.error("Error removing subscription:", error)
    }
  }

  // Add a function to handle alert clicks
  const handleAlertClick = async (alert: Alert) => {
    await markAlertAsRead(alert.id)

    // Navigate based on alert type
    if (alert.type === "message" || alert.type === "chat_request") {
      router.push("/private")
    } else if (alert.type === "comment" && alert.relatedId) {
      router.push(`/chollo/${alert.relatedId}`)
    }
  }

  // Update the getAlertIcon function to include message types
  const getAlertIcon = (type: string) => {
    switch (type) {
      case "comment":
        return <MessageSquare className="h-5 w-5" />
      case "vote":
        return <ThumbsUp className="h-5 w-5" />
      case "deal":
        return <Tag className="h-5 w-5" />
      case "message":
        return <MessageSquare className="h-5 w-5 text-blue-500" />
      case "chat_request":
        return <MessageSquare className="h-5 w-5 text-green-500" />
      default:
        return <Bell className="h-5 w-5" />
    }
  }

  if (!user) {
    return (
      <div className="container flex items-center justify-center py-16">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle>Inicia sesión para acceder a las alertas</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <p className="text-center text-muted-foreground">
              Necesitas iniciar sesión para ver tus alertas y suscripciones.
            </p>
            <div className="flex gap-4">
              <Button onClick={() => setShowLoginModal(true)}>Iniciar Sesión</Button>
              <Button variant="outline" onClick={() => setShowSignupModal(true)}>
                Registrarse
              </Button>
            </div>
          </CardContent>
        </Card>

        <LoginModal
          isOpen={showLoginModal}
          onClose={() => setShowLoginModal(false)}
          onSignupClick={() => {
            setShowLoginModal(false)
            setShowSignupModal(true)
          }}
        />

        <SignupModal
          isOpen={showSignupModal}
          onClose={() => setShowSignupModal(false)}
          onLoginClick={() => {
            setShowSignupModal(false)
            setShowLoginModal(true)
          }}
        />
      </div>
    )
  }

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Alertas y Suscripciones</h1>

      <Tabs defaultValue="alerts">
        <TabsList className="mb-6">
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
          <TabsTrigger value="subscriptions">Suscripciones</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Alertas Recientes</h3>
                {alerts.some((alert) => !alert.read) && (
                  <Button variant="outline" size="sm" onClick={markAllAsRead}>
                    Marcar todas como leídas
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {alertsLoading ? (
                <div className="text-center">
                  <p>Cargando alertas...</p>
                </div>
              ) : alerts.length > 0 ? (
                <div className="space-y-4">
                  {alerts.map((alert: Alert) => (
                    <div
                      key={alert.id}
                      className={`flex items-start gap-3 rounded-lg border p-3 transition-colors ${
                        alert.read ? "bg-background" : "bg-accent"
                      } cursor-pointer hover:bg-accent/80`}
                      onClick={() => handleAlertClick(alert)}
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                        {getAlertIcon(alert.type)}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm">{alert.content}</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(alert.createdAt.toDate()), {
                            addSuffix: true,
                            locale: es,
                          })}
                        </p>
                      </div>
                      {!alert.read && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={(e) => {
                            e.stopPropagation()
                            markAlertAsRead(alert.id)
                          }}
                        >
                          <X className="h-4 w-4" />
                          <span className="sr-only">Marcar como leída</span>
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-muted-foreground">No hay alertas todavía</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subscriptions">
          <Card>
            <CardHeader>
              <CardTitle>Tus Suscripciones</CardTitle>
            </CardHeader>
            <CardContent>
              {subscriptionsLoading ? (
                <div className="text-center">
                  <p>Cargando suscripciones...</p>
                </div>
              ) : subscriptions.length > 0 ? (
                <div className="space-y-4">
                  {subscriptions.map((subscription: Subscription) => (
                    <div key={subscription.id} className="flex items-center justify-between rounded-lg border p-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                          <Tag className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="font-medium">{subscription.dealTitle}</p>
                          <p className="text-xs text-muted-foreground">
                            Suscrito{" "}
                            {formatDistanceToNow(new Date(subscription.createdAt.toDate()), {
                              addSuffix: true,
                              locale: es,
                            })}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => removeSubscription(subscription.id)}
                      >
                        <X className="h-4 w-4" />
                        <span className="sr-only">Cancelar suscripción</span>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-muted-foreground">No hay suscripciones todavía</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
