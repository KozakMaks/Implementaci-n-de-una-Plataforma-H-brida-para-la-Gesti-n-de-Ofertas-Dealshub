"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { collection, query, where, orderBy, getDocs, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import { useDocument, useCollection } from "@/hooks/use-firestore"
import type { Deal, Comment, Vote } from "@/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { DealCard } from "@/components/deals/deal-card"
import { Button } from "@/components/ui/button"
import {
  PlusCircle,
  Package,
  Heart,
  BarChartIcon,
  Loader2,
  Award,
  MessageSquareText,
  ThumbsUp,
  CheckSquare,
  ListChecks,
  Star,
} from "lucide-react"
// Import the NoData component
import { NoData } from "@/components/ui/no-data"
// Import the NewChat component
import { NewChat } from "@/components/chat/new-chat"
import { useRouter } from "next/navigation"
// Import the RoleBadge component
import { RoleBadge } from "@/components/user/role-badge"

export default function UserProfile({ params }: { params: { id: string } }) {
  const { id } = params
  const { user } = useAuth()
  const router = useRouter()
  const isCurrentUser = user?.uid === id
  const [activityData, setActivityData] = useState<any[]>([])

  // Add new state for calculated reputation
  const [calculatedReputation, setCalculatedReputation] = useState<number>(0)
  const [loadingReputation, setLoadingReputation] = useState<boolean>(true)

  const [userComments, setUserComments] = useState<Comment[]>([])
  const [loadingUserComments, setLoadingUserComments] = useState(true)
  const [userVotesCasted, setUserVotesCasted] = useState<Vote[]>([])
  const [loadingUserVotesCasted, setLoadingUserVotesCasted] = useState(true)
  const [votedDealsForCategories, setVotedDealsForCategories] = useState<Deal[]>([])
  const [loadingVotedDealsForCategories, setLoadingVotedDealsForCategories] = useState(true)

  interface CalculatedStats {
    dealsPublishedCount: number
    averageDealRating: number
    mostValuedDeal: Deal | null
    mostValuedDealScore: number
    commentsMadeCount: number
    totalCommentReactions: number
    votesCastedCount: number
    uniqueVotedCategoriesCount: number
  }
  const [calculatedStats, setCalculatedStats] = useState<CalculatedStats | null>(null)
  const [loadingStats, setLoadingStats] = useState(true)

  // Fetch user data
  const { document: userData, loading: userLoading, error: userError } = useDocument("users", id, [id])

  // Fetch user's deals
  const { documents: userDeals, loading: dealsLoading } = useCollection(
    "deals",
    [where("publisherId", "==", id), orderBy("createdAt", "desc")],
    [id],
  )

  // Fetch user's favorite deals
  const { documents: favorites, loading: favoritesLoading } = useCollection(
    "favorites",
    [where("userId", "==", id), orderBy("createdAt", "desc")],
    [id],
  )

  // Fetch favorite deals details
  const [favoriteDeals, setFavoriteDeals] = useState<Deal[]>([])
  const [loadingFavoriteDeals, setLoadingFavoriteDeals] = useState(true)

  useEffect(() => {
    const fetchFavoriteDeals = async () => {
      if (!favorites.length) {
        setFavoriteDeals([])
        setLoadingFavoriteDeals(false)
        return
      }

      try {
        const dealIds = favorites.map((fav: any) => fav.dealId)
        const dealsData: Deal[] = []

        const batchSize = 30
        for (let i = 0; i < dealIds.length; i += batchSize) {
          const batch = dealIds.slice(i, i + batchSize)
          if (batch.length === 0) continue

          const q = query(collection(db, "deals"), where("__name__", "in", batch))
          const snapshot = await getDocs(q)
          snapshot.forEach((doc) => {
            dealsData.push({ id: doc.id, ...doc.data() } as Deal)
          })
        }

        setFavoriteDeals(dealsData)
      } catch (error) {
        console.error("Error fetching favorite deals:", error)
      } finally {
        setLoadingFavoriteDeals(false)
      }
    }

    if (!favoritesLoading) {
      fetchFavoriteDeals()
    }
  }, [favorites, favoritesLoading])

  // Fetch user's comments
  useEffect(() => {
    if (!id) {
      setLoadingUserComments(false)
      setUserComments([])
      return
    }
    setLoadingUserComments(true)
    const q = query(collection(db, "comments"), where("userId", "==", id), orderBy("createdAt", "desc"))
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const commentsData: Comment[] = []
        snapshot.forEach((doc) => commentsData.push({ id: doc.id, ...doc.data() } as Comment))
        setUserComments(commentsData)
        setLoadingUserComments(false)
      },
      (error) => {
        console.error("Error fetching user comments:", error)
        setUserComments([])
        setLoadingUserComments(false)
      },
    )
    return () => unsubscribe()
  }, [id])

  // Fetch user's votes cast
  useEffect(() => {
    if (!id) {
      setLoadingUserVotesCasted(false)
      setUserVotesCasted([])
      return
    }
    setLoadingUserVotesCasted(true)
    const q = query(collection(db, "votes"), where("userId", "==", id), orderBy("createdAt", "desc"))
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const votesData: Vote[] = []
        snapshot.forEach((doc) => votesData.push(doc.data() as Vote))
        setUserVotesCasted(votesData)
        setLoadingUserVotesCasted(false)
      },
      (error) => {
        console.error("Error fetching user votes cast:", error)
        setUserVotesCasted([])
        setLoadingUserVotesCasted(false)
      },
    )
    return () => unsubscribe()
  }, [id])

  // Fetch deals related to user's votes for categories
  useEffect(() => {
    const fetchDealsForVotedCategories = async () => {
      if (loadingUserVotesCasted || userVotesCasted.length === 0) {
        setVotedDealsForCategories([])
        setLoadingVotedDealsForCategories(false)
        return
      }

      setLoadingVotedDealsForCategories(true)
      try {
        const dealIds = Array.from(new Set(userVotesCasted.map((vote) => vote.dealId)))
        if (dealIds.length === 0) {
          setVotedDealsForCategories([])
          setLoadingVotedDealsForCategories(false)
          return
        }

        const dealsData: Deal[] = []
        const batchSize = 30
        for (let i = 0; i < dealIds.length; i += batchSize) {
          const batch = dealIds.slice(i, i + batchSize)
          if (batch.length === 0) continue

          const qDeals = query(collection(db, "deals"), where("__name__", "in", batch))
          const snapshot = await getDocs(qDeals)
          snapshot.forEach((doc) => {
            dealsData.push({ id: doc.id, ...doc.data() } as Deal)
          })
        }
        setVotedDealsForCategories(dealsData)
      } catch (error) {
        console.error("Error fetching deals for voted categories:", error)
        setVotedDealsForCategories([])
      } finally {
        setLoadingVotedDealsForCategories(false)
      }
    }

    fetchDealsForVotedCategories()
  }, [userVotesCasted, loadingUserVotesCasted])

  // Generate activity data for chart (for "Categorías de Chollos")
  useEffect(() => {
    if (!dealsLoading && userDeals.length > 0) {
      const categoryCounts: Record<string, number> = {}
      userDeals.forEach((deal: Deal) => {
        if (deal.category) {
          categoryCounts[deal.category] = (categoryCounts[deal.category] || 0) + 1
        }
      })
      const chartData = Object.entries(categoryCounts).map(([category, count]) => ({
        category,
        count,
      }))
      chartData.sort((a, b) => b.count - a.count)
      setActivityData(chartData.slice(0, 5))
    } else {
      setActivityData([])
    }
  }, [userDeals, dealsLoading])

  // Calculate all statistics
  useEffect(() => {
    if (
      userLoading ||
      dealsLoading ||
      loadingUserComments ||
      loadingUserVotesCasted ||
      loadingVotedDealsForCategories
    ) {
      setLoadingStats(true)
      return
    }

    setLoadingStats(true)

    // Deals stats
    const dealsPublishedCount = userDeals.length
    let averageDealRating = 0
    let mostValuedDeal: Deal | null = null
    let mostValuedDealScore = Number.NEGATIVE_INFINITY

    if (dealsPublishedCount > 0) {
      const dealScores = userDeals.map((deal) => (deal.upvotes || 0) - (deal.downvotes || 0))
      averageDealRating = dealScores.reduce((a, b) => a + b, 0) / dealsPublishedCount

      mostValuedDeal = userDeals.reduce((maxDeal, currentDeal) => {
        const currentScore = (currentDeal.upvotes || 0) - (currentDeal.downvotes || 0)
        const maxKnownScore = (maxDeal?.upvotes || 0) - (maxDeal?.downvotes || 0)
        return currentScore > maxKnownScore ? currentDeal : maxDeal
      }, userDeals[0] || null)

      if (mostValuedDeal) {
        mostValuedDealScore = (mostValuedDeal.upvotes || 0) - (mostValuedDeal.downvotes || 0)
      } else {
        mostValuedDealScore = 0
      }
    }

    // Comments stats
    const commentsMadeCount = userComments.length
    const totalCommentReactions = userComments.reduce((sum, comment) => {
      return sum + ((comment.likes || 0) - (comment.dislikes || 0))
    }, 0)

    // Votes stats
    const votesCastedCount = userVotesCasted.length
    let uniqueVotedCategoriesCount = 0
    if (votedDealsForCategories.length > 0) {
      const uniqueCategories = new Set(votedDealsForCategories.map((deal) => deal.category).filter(Boolean))
      uniqueVotedCategoriesCount = uniqueCategories.size
    }

    setCalculatedStats({
      dealsPublishedCount,
      averageDealRating: isNaN(averageDealRating) ? 0 : averageDealRating,
      mostValuedDeal,
      mostValuedDealScore,
      commentsMadeCount,
      totalCommentReactions,
      votesCastedCount,
      uniqueVotedCategoriesCount,
    })
    setLoadingStats(false)
  }, [
    userDeals,
    dealsLoading,
    userComments,
    loadingUserComments,
    userVotesCasted,
    loadingUserVotesCasted,
    votedDealsForCategories,
    loadingVotedDealsForCategories,
    userLoading,
  ])

  // Add useEffect for calculating reputation
  useEffect(() => {
    if (dealsLoading || !userDeals || !id) {
      if (!dealsLoading && userDeals && userDeals.length === 0) {
        setCalculatedReputation(0)
        setLoadingReputation(false)
      }
      return
    }

    setLoadingReputation(true)

    const calculateReputationForDeals = async () => {
      let totalReputationPoints = 0

      const reputationPromises = userDeals.map(async (deal: Deal) => {
        const dealUpvotes = deal.upvotes || 0
        if (dealUpvotes === 0) {
          return 0
        }
        const voteQuery = query(
          collection(db, "votes"),
          where("dealId", "==", deal.id),
          where("userId", "==", id),
          where("voteType", "==", "up"),
        )

        try {
          const userVoteSnapshot = await getDocs(voteQuery)
          if (!userVoteSnapshot.empty) {
            return dealUpvotes > 0 ? dealUpvotes - 1 : 0
          }
          return dealUpvotes
        } catch (error) {
          console.error(`Error checking self-vote for deal ${deal.id}:`, error)
          return dealUpvotes
        }
      })

      try {
        const contributions = await Promise.all(reputationPromises)
        totalReputationPoints = contributions.reduce((acc, curr) => acc + curr, 0)
        setCalculatedReputation(totalReputationPoints)
      } catch (error) {
        console.error("Error calculating reputation contributions:", error)
        setCalculatedReputation(0)
      } finally {
        setLoadingReputation(false)
      }
    }

    calculateReputationForDeals()
  }, [userDeals, dealsLoading, id])

  // Handle chat creation
  const handleChatCreated = (conversationId: string) => {
    router.push("/private")
  }

  if (userLoading) {
    return (
      <div className="container py-8 text-center">
        <p>Cargando perfil...</p>
      </div>
    )
  }

  if (userError) {
    console.error("User document error:", userError)
    return (
      <div className="container py-8 text-center">
        <p className="text-red-500">Error al cargar el perfil. Por favor, inténtalo de nuevo.</p>
      </div>
    )
  }

  if (!userData) {
    return (
      <div className="container py-8 text-center">
        <p className="text-amber-500">Este perfil de usuario no existe o ha sido eliminado.</p>
      </div>
    )
  }

  const maxCount = activityData.length > 0 ? Math.max(...activityData.map((item) => item.count)) : 0
  const chartColors = ["bg-primary", "bg-secondary", "bg-blue-500", "bg-green-500", "bg-purple-500"]

  return (
    <div className="container py-8">
      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-1">
          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={userData.photoURL || undefined} alt={userData.displayName} />
                  <AvatarFallback className="text-3xl">
                    {userData.displayName ? userData.displayName.charAt(0).toUpperCase() : "U"}
                  </AvatarFallback>
                </Avatar>
              </div>
              <CardTitle className="mt-2">{userData.displayName}</CardTitle>
              <div className="flex justify-center mt-1">
                <RoleBadge role={userData.role || "user"} />
              </div>
              <CardDescription>
                Miembro desde{" "}
                {formatDistanceToNow(new Date(userData.createdAt.toDate()), { addSuffix: true, locale: es })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <p className="text-3xl sm:text-4xl font-bold">
                    {loadingReputation ? (
                      <Loader2 className="mr-2 h-8 w-8 animate-spin inline-block" />
                    ) : (
                      calculatedReputation
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">Reputación</p>
                </div>

                <div>
                  <p className="mb-2 text-sm font-medium">Insignias</p>
                  <div className="flex flex-wrap gap-2">
                    {userData.badges && userData.badges.length > 0 ? (
                      userData.badges.map((badge: string) => (
                        <Badge key={badge} variant="outline">
                          {badge}
                        </Badge>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No hay insignias todavía</p>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  {isCurrentUser ? (
                    <Button asChild>
                      <Link href="/add-deal">
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Añadir Nuevo Chollo
                      </Link>
                    </Button>
                  ) : (
                    <NewChat onChatCreated={handleChatCreated} userId={id} userName={userData.displayName} />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* RE-ADDED CATEGORÍAS DE CHOLLOS CARD */}
          {activityData.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <BarChartIcon className="mr-2 h-5 w-5" />
                  Categorías de Chollos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {activityData.map((item, index) => (
                    <div key={item.category} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span>{item.category}</span>
                        <span className="font-medium">{item.count}</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div
                          className={`h-2 rounded-full ${chartColors[index % chartColors.length]}`}
                          style={{ width: `${(item.count / maxCount) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="md:col-span-2">
          <Tabs defaultValue="stats" className="w-full">
            <TabsList className="mb-6 grid w-full grid-cols-3">
              <TabsTrigger value="stats">Estadísticas</TabsTrigger>
              <TabsTrigger value="deals">Chollos</TabsTrigger>
              <TabsTrigger value="favorites">Favoritos</TabsTrigger>
            </TabsList>
            <TabsContent value="stats" className="space-y-6">
              <h2 className="text-2xl font-bold sr-only">Estadísticas del Usuario</h2>
              {loadingStats || !calculatedStats ? (
                <div className="flex justify-center items-center py-10">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <p className="ml-2">Cargando estadísticas...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Deals Stats Card */}
                  <Card className="flex flex-col">
                    <CardHeader>
                      <CardTitle className="flex items-center text-lg">
                        <Package className="mr-2 h-5 w-5 text-primary" />
                        {isCurrentUser ? "Tus Ofertas" : "Ofertas Publicadas"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 flex-grow flex flex-col justify-around">
                      <div className="text-center">
                        <p className="text-3xl sm:text-4xl font-bold">{calculatedStats.dealsPublishedCount}</p>
                        <p className="text-sm text-muted-foreground">Número de ofertas</p>
                      </div>
                      {calculatedStats.dealsPublishedCount > 0 && (
                        <>
                          <div className="text-center">
                            <p className="text-2xl sm:text-3xl font-semibold">
                              {calculatedStats.averageDealRating.toFixed(1)}
                            </p>
                            <p className="text-sm text-muted-foreground flex items-center justify-center">
                              <Star className="mr-1 h-4 w-4 text-yellow-400" />
                              Media de valoración
                            </p>
                          </div>
                          {calculatedStats.mostValuedDeal && (
                            <div className="text-center pt-2">
                              <p className="text-lg sm:text-xl font-semibold text-muted-foreground">
                                Puntuación: {calculatedStats.mostValuedDealScore}
                              </p>
                              <Link
                                href={`/chollo/${calculatedStats.mostValuedDeal.id}`}
                                className="text-primary hover:underline block truncate font-semibold text-lg"
                              >
                                {calculatedStats.mostValuedDeal.title}
                              </Link>
                              <p className="text-sm font-medium flex items-center justify-center">
                                <Award className="mr-1 h-4 w-4 text-amber-500" />
                                {isCurrentUser ? "Tu chollo más valorado" : "Chollo más valorado"}
                              </p>
                            </div>
                          )}
                        </>
                      )}
                    </CardContent>
                  </Card>
                  {/* Comments Stats Card */}
                  <Card className="flex flex-col">
                    <CardHeader>
                      <CardTitle className="flex items-center text-lg">
                        <MessageSquareText className="mr-2 h-5 w-5 text-primary" />
                        {isCurrentUser ? "Tus Comentarios" : "Comentarios Realizados"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6 flex-grow flex flex-col justify-around">
                      <div className="text-center">
                        <p className="text-3xl sm:text-4xl font-bold">{calculatedStats.commentsMadeCount}</p>
                        <p className="text-sm text-muted-foreground">Número de comentarios</p>
                      </div>
                      {calculatedStats.commentsMadeCount > 0 && (
                        <div className="text-center">
                          <p className="text-2xl sm:text-3xl font-semibold">{calculatedStats.totalCommentReactions}</p>
                          <p className="text-sm text-muted-foreground flex items-center justify-center">
                            <ThumbsUp className="mr-1 h-4 w-4 text-blue-500" />
                            {isCurrentUser ? "Reacciones a tus comentarios" : "Reacciones a comentarios"}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  {/* Votes Stats Card */}
                  <Card className="md:col-span-2 flex flex-col">
                    {" "}
                    {/* Changed lg:col-span-2 to md:col-span-2 */}
                    <CardHeader>
                      <CardTitle className="flex items-center text-lg">
                        <CheckSquare className="mr-2 h-5 w-5 text-primary" />
                        {isCurrentUser ? "Tus Votos" : "Votos Realizados"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6 flex-grow flex flex-col justify-around">
                      <div className="text-center">
                        <p className="text-3xl sm:text-4xl font-bold">{calculatedStats.votesCastedCount}</p>
                        <p className="text-sm text-muted-foreground">Cantidad de votos</p>
                      </div>
                      {calculatedStats.votesCastedCount > 0 && (
                        <div className="text-center">
                          <p className="text-2xl sm:text-3xl font-semibold">
                            {calculatedStats.uniqueVotedCategoriesCount}
                            <span className="text-xl sm:text-2xl text-muted-foreground">/10</span>
                          </p>
                          <p className="text-sm text-muted-foreground flex items-center justify-center">
                            <ListChecks className="mr-1 h-4 w-4 text-purple-500" />
                            Categorías únicas votadas
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>
            <TabsContent value="deals">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Chollos Publicados</h2>
                {isCurrentUser && (
                  <Button asChild variant="outline" size="sm">
                    <Link href="/add-deal">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Añadir Chollo
                    </Link>
                  </Button>
                )}
              </div>

              {dealsLoading ? (
                <div className="mt-4 text-center">
                  <p>Cargando chollos...</p>
                </div>
              ) : userDeals.length > 0 ? (
                <div className="mt-6 grid gap-6 sm:grid-cols-1 md:grid-cols-2">
                  {userDeals.map((deal: Deal) => (
                    <DealCard key={deal.id} deal={deal} />
                  ))}
                </div>
              ) : (
                <div className="mt-4">
                  <NoData
                    title="No hay chollos publicados todavía"
                    description={
                      isCurrentUser
                        ? "No has publicado ningún chollo todavía."
                        : "Este usuario no ha publicado ningún chollo todavía."
                    }
                    actionText={isCurrentUser ? "Añade Tu Primer Chollo" : undefined}
                    actionLink={isCurrentUser ? "/add-deal" : undefined}
                    icon={<Package className="h-12 w-12" />}
                  />
                </div>
              )}
            </TabsContent>
            <TabsContent value="favorites">
              <h2 className="text-2xl font-bold">Chollos Favoritos</h2>

              {favoritesLoading || loadingFavoriteDeals ? (
                <div className="mt-4 text-center">
                  <p>Cargando favoritos...</p>
                </div>
              ) : favoriteDeals.length > 0 ? (
                <div className="mt-6 grid gap-6 sm:grid-cols-1 md:grid-cols-2">
                  {favoriteDeals.map((deal: Deal) => (
                    <DealCard key={deal.id} deal={deal} />
                  ))}
                </div>
              ) : (
                <div className="mt-4">
                  <NoData
                    title="No hay chollos favoritos todavía"
                    description={
                      isCurrentUser
                        ? "No has marcado ningún chollo como favorito todavía."
                        : "Este usuario no ha marcado ningún chollo como favorito todavía."
                    }
                    actionText="Explorar Chollos"
                    actionLink="/"
                    icon={<Heart className="h-12 w-12" />}
                  />
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
