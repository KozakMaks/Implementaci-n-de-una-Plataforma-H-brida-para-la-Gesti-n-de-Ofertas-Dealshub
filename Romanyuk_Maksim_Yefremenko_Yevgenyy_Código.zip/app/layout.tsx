import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/hooks/use-auth"
import { ThemeProvider } from "@/components/theme-provider"
import { Navbar } from "@/components/layout/navbar"
import { Toaster } from "@/components/ui/toaster"
import { CookieBanner } from "@/components/layout/cookie-banner"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DealHub - Find the Best Deals",
  description: "Discover and share the best deals, discounts, and offers.",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "DealHub",
  },
    generator: 'v0.dev'
}

export const viewport: Viewport = {
  themeColor: "#FF6900",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        {/* No need to manually add <link rel="manifest" href="/manifest.json" />
            or <meta name="theme-color" ... /> if using Next.js metadata API as above.
            Next.js handles these based on the metadata and viewport objects.
        */}
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <AuthProvider>
            <div className="flex min-h-screen flex-col">
              <Navbar />
              <main className="flex-1">{children}</main>
            </div>
            <Toaster />
            <CookieBanner />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
