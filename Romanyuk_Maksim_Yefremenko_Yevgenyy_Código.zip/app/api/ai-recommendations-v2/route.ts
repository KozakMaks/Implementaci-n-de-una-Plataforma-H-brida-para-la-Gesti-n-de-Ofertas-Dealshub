import { z } from "zod"
import { findDealsFromFirebase } from "@/lib/ai/deal-search"
import type { Deal } from "@/types"
import type { ChatCompletionMessageParam } from "openai/resources/chat/completions"

console.log(`[${new Date().toISOString()}] API ROUTE FILE LOADED (Manual Fetch): /api/ai-recommendations-v2/route.ts`)

const apiKeyFromEnv = process.env.OPENAI_API_KEY

if (!apiKeyFromEnv) {
  console.error(
    `[${new Date().toISOString()}] CRITICAL ERROR: OPENAI_API_KEY is not defined in the environment. Manual fetch will fail.`,
  )
} else {
  console.log(`[${new Date().toISOString()}] OPENAI_API_KEY found. Ready for manual fetch.`)
}

export const maxDuration = 60

// --- Zod Schemas ---
const SearchParametersSchema = z.object({
  mainProductTerm: z.string().min(1, "Main product term cannot be empty."),
  inferredMaxPrice: z.number().optional(),
  inferredMinPrice: z.number().optional(),
  alternativeTerms: z.array(z.string().min(1)).optional(),
  searchKeywords: z.array(z.string().min(1)).optional(),
  expandedSemanticTerms: z
    .array(z.string().min(1))
    .optional()
    .describe("Broader terms or synonyms related to the main product term for wider search."),
})

const AnalyzedDealSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  score: z.number().min(1).max(3),
  reason: z.string().min(1),
  discountedPrice: z.number(),
  originalPrice: z.number(),
})

// Updated schema to allow up to 10 deals to be returned from analysis
const AnalysisModuleOutputSchema = z.object({
  selected: z.array(AnalyzedDealSchema).max(10),
})

const normalizeText = (text = ""): string => {
  return text
    .toLowerCase()
    .normalize("NFD") // Decompose accented characters
    .replace(/[\u0300-\u036f]/g, "") // Remove diacritics
}

async function getStructuredResponseWithManualFetch<T extends z.ZodTypeAny>(
  moduleName: string,
  systemPrompt: string,
  userContent: string,
  schema: T,
  model = "gpt-4o",
): Promise<z.infer<T>> {
  if (!apiKeyFromEnv) {
    console.error(`[${new Date().toISOString()}] ${moduleName}: OPENAI_API_KEY is missing. Cannot make manual fetch.`)
    throw new Error("OpenAI API key is not configured on the server.")
  }
  if (!userContent || typeof userContent !== "string" || userContent.trim() === "") {
    console.error(`[${new Date().toISOString()}] ${moduleName}: User content is empty or invalid.`)
    throw new Error(`Invalid input for ${moduleName}: User content cannot be empty.`)
  }

  const effectiveModel = typeof model === "string" && model.trim() !== "" ? model.trim() : "gpt-4o"
  console.log(
    `[${new Date().toISOString()}] ${moduleName} - Manual Fetch to OpenAI. Model: ${effectiveModel}. User Content: ${userContent.substring(0, 250)}...`,
  )

  const messages: ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userContent },
  ]

  const openAIBody = {
    model: effectiveModel,
    messages: messages,
    response_format: { type: "json_object" },
  }

  let openAIResponseData: any
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKeyFromEnv}`,
      },
      body: JSON.stringify(openAIBody),
    })

    if (!response.ok) {
      const errorBody = await response.text()
      console.error(
        `[${new Date().toISOString()}] ${moduleName}: OpenAI API request failed. Status: ${response.status}. Body: ${errorBody}`,
      )
      throw new Error(
        `OpenAI API request for ${moduleName} failed with status ${response.status}: ${errorBody || response.statusText}`,
      )
    }
    openAIResponseData = await response.json()
  } catch (fetchError: any) {
    console.error(
      `[${new Date().toISOString()}] ${moduleName}: Fetch to OpenAI API failed. Error: ${fetchError.message}`,
    )
    throw new Error(`Network error or issue fetching from OpenAI for ${moduleName}: ${fetchError.message}`)
  }

  const content = openAIResponseData.choices?.[0]?.message?.content
  if (!content) {
    console.error(
      `[${new Date().toISOString()}] ${moduleName}: OpenAI returned no content in choices. Response: ${JSON.stringify(openAIResponseData)}`,
    )
    throw new Error(`OpenAI returned no content for ${moduleName}.`)
  }

  console.log(`[${new Date().toISOString()}] ${moduleName} - AI Raw JSON Response (Manual Fetch): ${content}`)
  try {
    const parsedJson = JSON.parse(content)
    const validationResult = schema.safeParse(parsedJson)
    if (!validationResult.success) {
      console.error(
        `[${new Date().toISOString()}] ${moduleName}: Zod validation failed.`,
        validationResult.error.issues,
      )
      console.error(
        `[${new Date().toISOString()}] ${moduleName}: Data that failed validation:`,
        JSON.stringify(parsedJson, null, 2),
      )
      throw new Error(
        `AI response for ${moduleName} failed schema validation: ${validationResult.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join(", ")}`,
      )
    }
    return validationResult.data
  } catch (e: any) {
    console.error(`[${new Date().toISOString()}] ${moduleName}: JSON Parse Error.`, e.message, "Raw content:", content)
    throw new Error(`Failed to parse AI's JSON response for ${moduleName}: ${e.message}`)
  }
}

export async function POST(req: Request) {
  const requestTimestamp = new Date().toISOString()
  console.log(`[${requestTimestamp}] API Route POST /api/ai-recommendations-v2 called (Manual Fetch)`)
  let userQuery = ""

  if (!apiKeyFromEnv) {
    console.error(`[${requestTimestamp}] POST Handler: OPENAI_API_KEY is missing. Cannot proceed.`)
    return new Response(
      JSON.stringify({
        error: "Configuración del servidor incompleta (Clave API OpenAI).",
        details: "La clave API de OpenAI no está configurada en el servidor.",
      }),
      { status: 500, headers: { "Content-Type": "application/json" } },
    )
  }

  try {
    const body = await req.json()
    userQuery = typeof body.query === "string" ? body.query.trim() : ""

    if (!userQuery) {
      console.warn(`[${requestTimestamp}] Invalid or empty user query received.`)
      return new Response(JSON.stringify({ error: "Consulta inválida o vacía." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }
    console.log(`[${requestTimestamp}] User query: "${userQuery}"`)

    // --- Stage 1: SearchModule ---
    const searchSystemPrompt = `You are the SearchModule. Your task is to parse the user's input (in Spanish) and extract key information for a product search.
Return a JSON object with the following fields:
- "mainProductTerm": (string, required) The primary product or category the user is looking for (e.g., "gpu", "portátil", "cafetera").
- "expandedSemanticTerms": (array of strings, optional) Provide 3-5 related terms, synonyms, or common brands/series associated with the mainProductTerm to broaden the search. For example, if mainProductTerm is "gpu", expandedSemanticTerms could be ["tarjeta gráfica", "NVIDIA", "AMD", "RTX", "RX"]. If mainProductTerm is "portátil", it could be ["laptop", "notebook", "ultrabook"].
- "searchKeywords": (array of strings, optional) Adjectives, qualifiers (e.g., 'potente', 'usado', 'nuevo', 'blanco', '16GB'), or subjective price terms ('barato', 'oferta') from the user's query. Do NOT put product names or nouns already covered in mainProductTerm or expandedSemanticTerms here.
- "inferredMinPrice": (number, optional) Inferred minimum price in EUR if suggested by terms like 'barato'.
- "inferredMaxPrice": (number, optional) Inferred maximum price in EUR if suggested by terms like 'caro'.
Ensure mainProductTerm is never empty. If no specific expanded terms come to mind, omit the "expandedSemanticTerms" field or provide an empty array.`

    const searchUserContent = `User's input: "${userQuery}"`

    const searchParams = await getStructuredResponseWithManualFetch(
      "SearchModule",
      searchSystemPrompt,
      searchUserContent,
      SearchParametersSchema,
    )
    console.log(`[${requestTimestamp}] SearchModule Params:`, searchParams)

    if (!searchParams.mainProductTerm) {
      console.error(`[${requestTimestamp}] SearchModule failed to extract a mainProductTerm.`)
      throw new Error("SearchModule could not determine the main product to search for.")
    }

    // +++ DEAL FETCHING AND FILTERING LOGIC +++
    const allFetchedDeals: Deal[] = []
    const termsToSearchFirebase = [
      searchParams.mainProductTerm,
      ...(searchParams.alternativeTerms || []),
      ...(searchParams.expandedSemanticTerms || []),
    ]
      .filter((term): term is string => typeof term === "string" && term.trim() !== "")
      .map((term) => term.trim())
      .filter((term, index, self) => self.indexOf(term) === index && term.length > 0)
      .slice(0, 8)

    let termUsedForSuccessfulSearch = searchParams.mainProductTerm

    console.log(
      `[${requestTimestamp}] Terms for Firebase search (main + alternatives + expanded): ${JSON.stringify(termsToSearchFirebase)}`,
    )

    if (termsToSearchFirebase.length === 0) {
      termsToSearchFirebase.push(searchParams.mainProductTerm)
    }

    for (const term of termsToSearchFirebase) {
      console.log(
        `[${requestTimestamp}] Searching Firebase with term: "${term}", MinPrice=${searchParams.inferredMinPrice ?? "N/A"}, MaxPrice=${searchParams.inferredMaxPrice ?? "N/A"}`,
      )
      const currentDeals = await findDealsFromFirebase(
        term,
        searchParams.inferredMinPrice,
        searchParams.inferredMaxPrice,
      )
      allFetchedDeals.push(...currentDeals)
      if (currentDeals.length > 0) {
        if (
          termUsedForSuccessfulSearch === searchParams.mainProductTerm &&
          allFetchedDeals.length === currentDeals.length &&
          term !== searchParams.mainProductTerm
        ) {
        } else if (
          term === searchParams.mainProductTerm ||
          !allFetchedDeals.some((d) => d.title.toLowerCase().includes(termUsedForSuccessfulSearch.toLowerCase()))
        ) {
          termUsedForSuccessfulSearch = term
        }
      }
    }

    const uniqueDealsMap = new Map<string, Deal>()
    allFetchedDeals.forEach((deal) => {
      if (deal && deal.id) {
        uniqueDealsMap.set(deal.id, deal)
      }
    })
    const uniqueFetchedDeals = Array.from(uniqueDealsMap.values())
    console.log(
      `[${requestTimestamp}] Found ${uniqueFetchedDeals.length} unique deals after Firebase search for all terms. Term most associated with results: "${termUsedForSuccessfulSearch}"`,
    )

    const allKeywords = (searchParams.searchKeywords || [])
      .filter((kw): kw is string => typeof kw === "string" && kw.trim() !== "")
      .map((kw) => normalizeText(kw.trim()))
      .filter((kw) => kw.length > 0)

    const subjectivePriceTerms = ["buen precio", "barato", "economico", "oferta", "descuento"]
    const subjectiveQualityTerms = ["buena", "bueno", "potente", "mejor", "calidad", "top"]
    const subjectiveSignals = [...subjectivePriceTerms, ...subjectiveQualityTerms]

    const strictModifierKeywords = allKeywords.filter((kw) => !subjectiveSignals.includes(kw))
    const foundSubjectiveSignals = allKeywords.filter((kw) => subjectiveSignals.includes(kw))

    const userWantsGoodPrice = allKeywords.some((kw) => subjectivePriceTerms.includes(kw))
    const userWantsHighQuality = allKeywords.some((kw) => subjectiveQualityTerms.includes(kw))

    console.log(
      `[${requestTimestamp}] Strict Modifier Keywords for text search: ${JSON.stringify(strictModifierKeywords)}`,
    )
    console.log(`[${requestTimestamp}] Found Subjective Signals: ${JSON.stringify(foundSubjectiveSignals)}`)
    console.log(`[${requestTimestamp}] User wants good price: ${userWantsGoodPrice}`)
    console.log(`[${requestTimestamp}] User wants high quality: ${userWantsHighQuality}`)

    let finalFilteredDeals: Deal[] = uniqueFetchedDeals
    if (strictModifierKeywords.length > 0) {
      console.log(
        `[${requestTimestamp}] Applying STRICT non-price modifier keywords: ${JSON.stringify(strictModifierKeywords)}`,
      )
      finalFilteredDeals = uniqueFetchedDeals.filter((deal) => {
        const dealText = normalizeText(
          `${deal.title} ${deal.description || ""} ${deal.category || ""} ${deal.tags?.join(" ") || ""}`,
        )
        return strictModifierKeywords.every((modKw) => dealText.includes(modKw))
      })
      console.log(
        `[${requestTimestamp}] Found ${finalFilteredDeals.length} deals after applying STRICT modifier keywords.`,
      )
    } else {
      console.log(
        `[${requestTimestamp}] No strict modifier keywords to apply. Proceeding with all ${finalFilteredDeals.length} deals.`,
      )
    }

    const foundRawDeals = finalFilteredDeals.slice(0, 10)
    // +++ END OF DEAL FETCHING AND FILTERING LOGIC +++

    // --- Stage 2: AnalysisModule ---
    let analysisModuleOutput: z.infer<typeof AnalysisModuleOutputSchema>
    if (foundRawDeals.length === 0) {
      console.log(`[${requestTimestamp}] Stage 2: No deals to analyze.`)
      analysisModuleOutput = { selected: [] }
    } else {
      const dealsForAnalysis = foundRawDeals.map((d) => ({
        id: d.id || "unknown-id",
        name: d.title || "Untitled Deal",
        description: d.description,
        discountedPrice: d.discountedPrice,
        originalPrice: d.originalPrice,
      }))

      // --- UPDATED ANALYSIS PROMPT ---
      let analysisSystemPrompt = `You are the AnalysisModule. Your task is to evaluate ALL of the provided search results and return an analysis for EACH ONE. Do not filter any out.
For EACH deal provided, you must return an object with:
- "id": The deal's unique identifier (string).
- "name": The product name (string).
- "score": A rating from 1 to 3 (3 being the best), based on overall value, relevance to the user's query, price, and product features.
- "reason": A concise, positive, and ENTHUSIASTIC explanation (in Spanish, approximately 30-50 words). This "reason" is critical. It should not only state why the deal is good (e.g., "buen precio") but also INCORPORATE YOUR KNOWLEDGE ABOUT THE PRODUCT to highlight 1-2 key selling points or typical benefits. For instance:
    - For a GPU like "RTX 4070": "¡Excelente elección! Esta RTX 4070 de Nvidia es perfecta para gaming en 1440p, con tecnologías como DLSS 3 y Frame Generation para un rendimiento top."
    - For a smartphone: "¡Un móvil muy completo! Destaca por su cámara de alta resolución y batería de larga duración, ideal para el día a día."
- "discountedPrice": The deal's discounted price (number).
- "originalPrice": The deal's original price (number).

Your final output MUST be a JSON object with a "selected" field, which is an array containing an analysis object for EVERY deal you were given. If you receive 2 deals, you must return 2 analysis objects in the array.`

      if (userWantsGoodPrice) {
        analysisSystemPrompt += `
The user has expressed interest in a "good price" or "offer". Please heavily factor this into your scoring, prioritizing deals that represent excellent value.`
      }
      if (userWantsHighQuality) {
        analysisSystemPrompt += `
The user has expressed interest in a "good" or "high-quality" product. Please prioritize deals that are well-regarded, powerful for their category, or have strong features in your scoring.`
      }
      if (searchParams.inferredMinPrice !== undefined || searchParams.inferredMaxPrice !== undefined) {
        analysisSystemPrompt += `
Consider the user's inferred price range for the product: Min €${searchParams.inferredMinPrice ?? "any"}, Max €${searchParams.inferredMaxPrice ?? "any"}.`
      }

      const analysisUserContent = `User's original query: "${userQuery}".
Search results for terms related to "${termUsedForSuccessfulSearch}" (these are the deals you need to analyze and return): ${JSON.stringify(dealsForAnalysis)}`

      analysisModuleOutput = await getStructuredResponseWithManualFetch(
        "AnalysisModule",
        analysisSystemPrompt,
        analysisUserContent,
        AnalysisModuleOutputSchema,
      )
      console.log(`[${requestTimestamp}] AnalysisModule Output:`, analysisModuleOutput)
    }

    // --- Stage 3: ResponseModule (Manual Fetch for text generation) ---
    console.log(`[${requestTimestamp}] Stage 3: ResponseModule - Generating final message (Manual Fetch)...`)
    const responseSystemPrompt = `You are ResponseModule. Generate a fluent, helpful response in Spanish.
User searched for terms related to: "${termUsedForSuccessfulSearch}" (Price: Min ${searchParams.inferredMinPrice ?? "any"}, Max ${searchParams.inferredMaxPrice ?? "any"}).
User expressed interest in good price: ${userWantsGoodPrice}. User expressed interest in high quality: ${userWantsHighQuality}.
Initial results found (after all filtering): ${foundRawDeals.length}.
${
  analysisModuleOutput.selected.length > 0
    ? `Present these ${analysisModuleOutput.selected.length} recommendations. For each, state its name, score, and your brief reasoning. Mention the discounted price and original price. Do NOT attempt to create clickable links. The user will see these as items in a list. Example for one item: 'Destacado: [Product Name] (Puntuación: [score]/3) - [Reason]. Precio: €[discountedPrice] (antes €[originalPrice]).'`
    : `Inform the user that no relevant products were found for their search for '${termUsedForSuccessfulSearch}' and suggest trying another term. Standard message: "Lo siento, he buscado varias opciones y no he encontrado productos relevantes que se ajusten a tu búsqueda de '${termUsedForSuccessfulSearch}'. Quizá quieras intentarlo con otro término."`
}
Use Markdown. Prefix prices with '€'. Conclude friendly: "¿Hay algo más en lo que te pueda ayudar?"`

    const responseUserContent =
      analysisModuleOutput.selected.length > 0
        ? `Analyzed products for user query "${userQuery}": ${JSON.stringify(analysisModuleOutput.selected)}. Remember to list each product's name, score, reason, discountedPrice, and originalPrice. Do not create URLs.`
        : `No products were selected for recommendation for user query "${userQuery}". Provide the standard "no results" message for search term "${termUsedForSuccessfulSearch}".`

    const responseModel = "gpt-4o"
    const responseMessages: ChatCompletionMessageParam[] = [
      { role: "system", content: responseSystemPrompt },
      { role: "user", content: responseUserContent },
    ]
    const responseOpenAIBody = { model: responseModel, messages: responseMessages, temperature: 0.7 }

    let responseOpenAIResponseData: any
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKeyFromEnv}` },
        body: JSON.stringify(responseOpenAIBody),
      })
      if (!response.ok) {
        const errorBody = await response.text()
        console.error(
          `[${requestTimestamp}] ResponseModule: OpenAI API request failed. Status: ${response.status}. Body: ${errorBody}`,
        )
        throw new Error(
          `OpenAI API request for ResponseModule failed with status ${response.status}: ${errorBody || response.statusText}`,
        )
      }
      responseOpenAIResponseData = await response.json()
    } catch (fetchError: any) {
      console.error(`[${requestTimestamp}] ResponseModule: Fetch to OpenAI API failed. Error: ${fetchError.message}`)
      throw new Error(`Network error or issue fetching from OpenAI for ResponseModule: ${fetchError.message}`)
    }

    const finalText =
      responseOpenAIResponseData.choices?.[0]?.message?.content?.trim() ?? "No se pudo generar una respuesta."
    console.log(`[${requestTimestamp}] ResponseModule finalText (Manual Fetch): ${finalText.substring(0, 150)}...`)

    const selectedDealsForClient = analysisModuleOutput.selected.map((deal) => ({
      id: deal.id,
      name: deal.name,
      score: deal.score,
      reason: deal.reason,
      discountedPrice: deal.discountedPrice,
      originalPrice: deal.originalPrice,
    }))

    console.log(`[${requestTimestamp}] API returning selectedDeals:`, JSON.stringify(selectedDealsForClient, null, 2))

    return new Response(
      JSON.stringify({
        finalText,
        selectedDeals: selectedDealsForClient,
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      },
    )
  } catch (error: any) {
    console.error(`[${requestTimestamp}] Unhandled API error in POST:`, error.message, error.stack)
    if (error instanceof z.ZodError) {
      console.error(`[${requestTimestamp}] Zod Validation Error Details:`, JSON.stringify(error.issues, null, 2))
    }
    return new Response(JSON.stringify({ error: "Ocurrió un error en el servidor.", details: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
