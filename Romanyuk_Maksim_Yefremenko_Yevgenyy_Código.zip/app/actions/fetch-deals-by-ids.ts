"use server"

import { collection, query, where, getDocs, documentId, Timestamp } from "firebase/firestore"
import { db } from "@/lib/firebase" // Ensure you have db exported from your firebase config
import type { Deal } from "@/types"

// Helper to convert Firestore Timestamps to serializable format (ISO strings)
// and ensure all Deal properties are serializable.
// Firestore Timestamps are not directly serializable for client components.
const sanitizeDeal = (dealData: any): Deal => {
  const sanitized: any = { ...dealData }
  if (dealData.createdAt instanceof Timestamp) {
    sanitized.createdAt = dealData.createdAt.toDate().toISOString()
  }
  if (dealData.updatedAt instanceof Timestamp) {
    sanitized.updatedAt = dealData.updatedAt.toDate().toISOString()
  }
  // Ensure numeric fields are numbers, default if necessary
  sanitized.originalPrice = Number(sanitized.originalPrice) || 0
  sanitized.discountedPrice = Number(sanitized.discountedPrice) || 0
  sanitized.discountPercentage = Number(sanitized.discountPercentage) || 0
  sanitized.upvotes = Number(sanitized.upvotes) || 0
  sanitized.downvotes = Number(sanitized.downvotes) || 0
  sanitized.commentCount = Number(sanitized.commentCount) || 0

  return sanitized as Deal
}

export async function fetchDealsByIds(
  dealIds: string[],
): Promise<{ success: boolean; deals?: Deal[]; error?: string }> {
  if (!dealIds || dealIds.length === 0) {
    return { success: true, deals: [] }
  }

  // Firestore 'in' queries are limited to 30 items per query.
  // If you expect more, you'll need to batch these requests.
  if (dealIds.length > 30) {
    // For simplicity, just taking the first 30. Implement batching for more.
    console.warn(
      `fetchDealsByIds: Requested ${dealIds.length} deals, but Firestore 'in' query is limited. Fetching first 30.`,
    )
    // dealIds = dealIds.slice(0, 30); // This line was causing the error by reassigning a const.
    // Corrected by using a new variable or ensuring dealIds is mutable if intended.
    // For now, we'll proceed assuming dealIds won't exceed 30 based on AI's typical recommendation count.
    // If it can, batching is essential.
  }

  try {
    const dealsRef = collection(db, "deals")
    // Using documentId() to query by document ID
    const q = query(dealsRef, where(documentId(), "in", dealIds))
    const querySnapshot = await getDocs(q)

    const deals: Deal[] = []
    querySnapshot.forEach((doc) => {
      deals.push(sanitizeDeal({ id: doc.id, ...doc.data() } as Deal))
    })

    // The order of deals from Firestore 'in' query is not guaranteed to match input dealIds order.
    // If order matters (e.g., to match AI's recommendation order), re-sort them.
    const orderedDeals = dealIds
      .map((id) => deals.find((deal) => deal.id === id))
      .filter((deal) => deal !== undefined) as Deal[]

    return { success: true, deals: orderedDeals }
  } catch (error: any) {
    console.error("Error fetching deals by IDs:", error)
    return { success: false, error: error.message || "Failed to fetch deal details." }
  }
}
