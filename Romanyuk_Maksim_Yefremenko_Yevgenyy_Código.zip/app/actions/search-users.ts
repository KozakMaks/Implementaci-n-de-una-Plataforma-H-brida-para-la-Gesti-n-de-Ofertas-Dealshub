"use server"

import { db } from "@/lib/firebase"
import { collection, query, where, getDocs, limit, orderBy } from "firebase/firestore"
import type { User } from "@/types"

export async function searchUsers(
  searchTerm: string,
  currentUserId: string,
): Promise<{ success: boolean; users?: User[]; error?: string }> {
  console.log(`Server Action: Searching for users with term: "${searchTerm}"`)

  if (!searchTerm || searchTerm.trim().length < 1) {
    return { success: true, users: [] }
  }

  const searchTermLower = searchTerm.toLowerCase()
  const searchTermUpper = searchTerm.toUpperCase() // Not strictly needed for prefix, but good for exact matches if desired
  const searchTermCapitalized = searchTerm.charAt(0).toUpperCase() + searchTerm.slice(1).toLowerCase()

  try {
    const usersRef = collection(db, "users")
    // This query attempts to find matches starting with the term, regardless of its initial case.
    // Firestore's `orderBy` with inequality filters requires the orderBy field to be the first one.
    // To do a "case-insensitive" prefix search, you typically store a lowercase version of the field.
    // This is a simplified attempt:
    const q = query(
      usersRef,
      orderBy("displayName"),
      // We are looking for displayName >= searchTerm and displayName <= searchTerm + high_unicode_char
      // This will naturally catch different casings if the stored data has varied casing.
      // For a more robust case-insensitive search, you'd query a dedicated lowercase field.
      where("displayName", ">=", searchTermCapitalized), // Try with capitalized first letter
      where("displayName", "<=", searchTermCapitalized + "\uf8ff"),
      limit(10),
    )

    // A more complex approach for broader case-insensitivity without a dedicated lowercase field
    // would involve multiple queries or fetching more data and filtering client-side,
    // which is less efficient. The above is a common compromise for basic prefix search.

    const querySnapshot = await getDocs(q)
    const users: User[] = []
    querySnapshot.forEach((doc) => {
      if (doc.id !== currentUserId) {
        // Client-side filter for closer match if needed, though prefix should handle it
        if (doc.data().displayName.toLowerCase().startsWith(searchTermLower)) {
          users.push({ uid: doc.id, ...doc.data() } as User)
        }
      }
    })

    // If the first query didn't yield results, try with the exact search term casing
    if (users.length === 0 && searchTerm !== searchTermCapitalized) {
      const qExact = query(
        usersRef,
        orderBy("displayName"),
        where("displayName", ">=", searchTerm),
        where("displayName", "<=", searchTerm + "\uf8ff"),
        limit(10),
      )
      const exactSnapshot = await getDocs(qExact)
      exactSnapshot.forEach((doc) => {
        if (doc.id !== currentUserId && doc.data().displayName.toLowerCase().startsWith(searchTermLower)) {
          // Avoid duplicates if somehow matched by both
          if (!users.find((u) => u.uid === doc.id)) {
            users.push({ uid: doc.id, ...doc.data() } as User)
          }
        }
      })
    }

    console.log(`Server Action: Found ${users.length} users.`)
    return { success: true, users }
  } catch (error) {
    console.error("Server Action: Error searching for users:", error)
    return { success: false, error: "Failed to search for users." }
  }
}
