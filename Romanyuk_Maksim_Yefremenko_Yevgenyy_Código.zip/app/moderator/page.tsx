"use client"

import { useState, useEffect } from "react"
import {
  collection,
  query,
  getDocs,
  doc,
  where,
  orderBy,
  writeBatch,
  serverTimestamp,
  getDoc,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import { ProtectRoute } from "@/utils/protect-route"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, X, Flag, ExternalLink, MessageSquare } from "lucide-react"
import { NoData } from "@/components/ui/no-data"
import { toast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import type { CommentReport, Report as DealReport } from "@/types" // Added CommentReport

interface AggregatedCommentReport extends CommentReport {
  reportIds: string[]
  reportCount: number
}

export default function ModeratorPage() {
  const { user } = useAuth()
  const [reportedDeals, setReportedDeals] = useState<any[]>([])
  const [reportedComments, setReportedComments] = useState<AggregatedCommentReport[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchContent = async () => {
      setLoading(true)
      try {
        // Fetch reported deals
        const dealReportsQuery = query(
          collection(db, "reports"),
          where("status", "==", "pending"),
          orderBy("createdAt", "desc"),
        )
        const dealReportsSnapshot = await getDocs(dealReportsQuery)
        const dealReportsData = dealReportsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }) as DealReport)

        const aggregatedDeals: any[] = []
        const dealReportsByDealId = dealReportsData.reduce(
          (acc, report) => {
            acc[report.dealId] = acc[report.dealId] || []
            acc[report.dealId].push(report)
            return acc
          },
          {} as Record<string, DealReport[]>,
        )

        for (const dealId in dealReportsByDealId) {
          const dealDoc = await getDoc(doc(db, "deals", dealId))
          if (dealDoc.exists()) {
            aggregatedDeals.push({
              id: dealId,
              ...dealDoc.data(),
              reports: dealReportsByDealId[dealId],
              reportCount: dealReportsByDealId[dealId].length,
            })
          }
        }
        setReportedDeals(aggregatedDeals)

        // Fetch reported comments
        const commentReportsQuery = query(
          collection(db, "commentReports"),
          where("status", "==", "pending"),
          orderBy("createdAt", "desc"),
        )
        const commentReportsSnapshot = await getDocs(commentReportsQuery)
        const commentReportsData = commentReportsSnapshot.docs.map(
          (doc) => ({ id: doc.id, ...doc.data() }) as CommentReport,
        )

        const aggregatedCommentReports: Record<string, AggregatedCommentReport> = {}
        commentReportsData.forEach((report) => {
          if (!aggregatedCommentReports[report.commentId]) {
            aggregatedCommentReports[report.commentId] = {
              ...report,
              reportIds: [],
              reportCount: 0,
            }
          }
          aggregatedCommentReports[report.commentId].reportIds.push(report.id)
          aggregatedCommentReports[report.commentId].reportCount++
        })
        setReportedComments(Object.values(aggregatedCommentReports))
      } catch (error) {
        console.error("Error fetching moderation content:", error)
        toast({ title: "Error", description: "Failed to fetch content for moderation.", variant: "destructive" })
      } finally {
        setLoading(false)
      }
    }
    fetchContent()
  }, [])

  const handleReportedDealModeration = async (deal: any, action: "approve" | "remove") => {
    const batch = writeBatch(db)
    try {
      if (action === "remove") {
        batch.delete(doc(db, "deals", deal.id))
        deal.reports.forEach((report: DealReport) => {
          batch.update(doc(db, "reports", report.id), {
            status: "resolved",
            resolution: "removed",
            resolvedBy: user?.uid,
            resolvedAt: serverTimestamp(),
          })
        })
        toast({ title: "Chollo Eliminado", description: "El chollo reportado ha sido eliminado." })
      } else {
        // approve
        deal.reports.forEach((report: DealReport) => {
          batch.update(doc(db, "reports", report.id), {
            status: "resolved",
            resolution: "approved",
            resolvedBy: user?.uid,
            resolvedAt: serverTimestamp(),
          })
        })
        toast({ title: "Chollo Aprobado", description: "El chollo reportado ha sido revisado y aprobado." })
      }
      await batch.commit()
      setReportedDeals(reportedDeals.filter((d) => d.id !== deal.id))
    } catch (error) {
      console.error("Error handling reported deal:", error)
      toast({ title: "Error", description: "Error al procesar el chollo reportado.", variant: "destructive" })
    }
  }

  const handleCommentModeration = async (reportedComment: AggregatedCommentReport, action: "approve" | "remove") => {
    const batch = writeBatch(db)
    try {
      if (action === "remove") {
        batch.delete(doc(db, "comments", reportedComment.commentId))
        reportedComment.reportIds.forEach((reportId) => {
          batch.update(doc(db, "commentReports", reportId), {
            status: "resolved",
            resolution: "removed",
            resolvedBy: user?.uid,
            resolvedAt: serverTimestamp(),
          })
        })
        toast({ title: "Comentario Eliminado", description: "El comentario reportado ha sido eliminado." })
      } else {
        // approve
        reportedComment.reportIds.forEach((reportId) => {
          batch.update(doc(db, "commentReports", reportId), {
            status: "resolved",
            resolution: "approved",
            resolvedBy: user?.uid,
            resolvedAt: serverTimestamp(),
          })
        })
        toast({ title: "Comentario Aprobado", description: "El comentario reportado ha sido revisado y aprobado." })
      }
      await batch.commit()
      setReportedComments((prev) => prev.filter((rc) => rc.commentId !== reportedComment.commentId))
    } catch (error) {
      console.error("Error moderating comment:", error)
      toast({ title: "Error", description: "Error al procesar el comentario reportado.", variant: "destructive" })
    }
  }

  return (
    <ProtectRoute requiredRoles={["moderator", "admin"]} redirectTo="/">
      <div className="container py-8">
        <h1 className="text-2xl font-bold mb-6">Panel de Moderador</h1>
        <Tabs defaultValue="reported-deals">
          <TabsList className="mb-6">
            <TabsTrigger value="reported-deals">
              <Flag className="mr-2 h-4 w-4" />
              Chollos Reportados
            </TabsTrigger>
            <TabsTrigger value="reported-comments">
              <MessageSquare className="mr-2 h-4 w-4" />
              Comentarios Reportados
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reported-deals">
            <Card>
              <CardHeader>
                <CardTitle>Chollos Reportados</CardTitle>
                <CardDescription>Revisar y moderar chollos reportados</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-4">Cargando chollos reportados...</div>
                ) : reportedDeals.length > 0 ? (
                  <div className="space-y-4">
                    {reportedDeals.map((deal) => (
                      <Card key={deal.id}>
                        <CardContent className="p-4">
                          <div className="flex flex-col gap-4">
                            <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-4">
                              <div>
                                <div className="flex items-center gap-2 flex-nowrap">
                                  <h3 className="font-semibold truncate">{deal.title}</h3>
                                  <Badge variant="destructive" className="rounded-full px-2.5 py-0.5 shrink-0">
                                    {deal.reportCount} {deal.reportCount === 1 ? "reporte" : "reportes"}
                                  </Badge>
                                </div>
                                <p className="text-sm text-muted-foreground">{deal.description}</p>
                                <div className="mt-2 text-xs text-muted-foreground">
                                  Publicado por: {deal.publisherName} | Fecha:{" "}
                                  {new Date(deal.createdAt?.toDate()).toLocaleDateString()}
                                </div>
                              </div>
                              <div className="grid grid-cols-3 gap-2 sm:flex sm:flex-wrap lg:justify-end">
                                <Button size="sm" variant="outline" asChild className="w-full sm:w-auto">
                                  <Link href={`/chollo/${deal.id}`} target="_blank">
                                    <ExternalLink className="mr-1 h-4 w-4" />
                                    Ver Chollo
                                  </Link>
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleReportedDealModeration(deal, "approve")}
                                  className="w-full sm:w-auto"
                                >
                                  <Check className="mr-1 h-4 w-4" />
                                  Mantener
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleReportedDealModeration(deal, "remove")}
                                  className="w-full sm:w-auto"
                                >
                                  <X className="mr-1 h-4 w-4" />
                                  Eliminar
                                </Button>
                              </div>
                            </div>
                            <div className="bg-muted p-3 rounded-md">
                              <h4 className="text-sm font-medium mb-2">Motivos del Reporte:</h4>
                              <ul className="space-y-2">
                                {deal.reports.map((report: DealReport) => (
                                  <li key={report.id} className="text-sm">
                                    <span className="font-medium">
                                      {report.reason === "unavailable"
                                        ? "El chollo ya no está disponible"
                                        : report.reason === "misleading"
                                          ? "Información falsa o engañosa"
                                          : report.reason === "offensive"
                                            ? "Contenido ofensivo"
                                            : "Otro"}
                                    </span>
                                    {report.comment && <p className="text-muted-foreground mt-1">{report.comment}</p>}
                                    <div className="text-xs text-muted-foreground mt-1">
                                      Reportado por: {report.userName} |{" "}
                                      {new Date(report.createdAt?.toDate()).toLocaleString()}
                                    </div>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <NoData
                    title="No hay chollos reportados"
                    description="No hay chollos reportados para revisar."
                    icon={<Flag className="h-12 w-12" />}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reported-comments">
            <Card>
              <CardHeader>
                <CardTitle>Comentarios Reportados</CardTitle>
                <CardDescription>Revisar y moderar comentarios reportados</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-4">Cargando comentarios reportados...</div>
                ) : reportedComments.length > 0 ? (
                  <div className="space-y-4">
                    {reportedComments.map((rc) => (
                      <Card key={rc.commentId}>
                        <CardContent className="p-4">
                          <div className="flex flex-col gap-4">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <p className="text-sm italic">"{rc.commentContent}"</p>
                                <Badge variant="destructive" className="rounded-full px-2.5 py-0.5 shrink-0">
                                  {rc.reportCount} {rc.reportCount === 1 ? "reporte" : "reportes"}
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                Autor:{" "}
                                <Link href={`/perfil/${rc.commentAuthorId}`} className="hover:underline">
                                  {rc.commentAuthorName || "Desconocido"}
                                </Link>{" "}
                                | Fecha del comentario:{" "}
                                {rc.createdAt?.toDate ? new Date(rc.createdAt.toDate()).toLocaleDateString() : "N/A"}
                              </div>
                              <div className="text-xs text-muted-foreground mt-1">
                                Primer reporte por: {rc.reporterName || "Desconocido"} | Fecha del primer reporte:{" "}
                                {rc.createdAt?.toDate ? new Date(rc.createdAt.toDate()).toLocaleString() : "N/A"}
                              </div>
                            </div>
                            <div className="flex gap-2 justify-end">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleCommentModeration(rc, "approve")}
                              >
                                <Check className="mr-1 h-4 w-4" />
                                Aprobar
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleCommentModeration(rc, "remove")}
                              >
                                <X className="mr-1 h-4 w-4" />
                                Eliminar
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <NoData
                    title="No hay comentarios reportados"
                    description="No hay comentarios reportados para revisar."
                    icon={<MessageSquare className="h-12 w-12" />}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ProtectRoute>
  )
}
