"use client"

import { useState, useEffect, useMemo } from "react" // Added useMemo
import Image from "next/image"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import {
  ChevronUp,
  ChevronDown,
  Star,
  Share2,
  ExternalLink,
  Copy,
  Check,
  Twitter,
  Facebook,
  Linkedin,
  MessageSquare,
  Mail,
  User,
  Flag,
  Clock,
  Trash2,
  ShieldAlert,
  RefreshCw,
  TicketPercent,
} from "lucide-react"
import {
  collection,
  query,
  where,
  getDocs,
  addDoc,
  deleteDoc,
  serverTimestamp,
  orderBy,
  limit,
  doc,
  updateDoc,
  getDoc,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/hooks/use-auth"
import { useDocument, useCollection } from "@/hooks/use-firestore"
import type { Deal as DealType, Comment as CommentType } from "@/types"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { CommentSection } from "@/components/deals/comment-section"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import { ReportModal } from "@/components/deals/report-modal"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Label } from "@/components/ui/label"
import { useVotes } from "@/hooks/use-votes"
import { formatPriceForDisplay } from "@/lib/formatters"

export default function DealDetail({ params }: { params: { id: string } }) {
  const { id } = params
  const { user, role } = useAuth()
  const isModerationAllowed = role === "admin" || role === "moderator"

  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)
  const [showReportModal, setShowReportModal] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)
  const [isFavoriting, setIsFavoriting] = useState(false)
  const [favoriteId, setFavoriteId] = useState<string | null>(null)
  const [linkCopied, setLinkCopied] = useState(false)
  const [couponCopied, setCouponCopied] = useState(false)
  const [publisherData, setPublisherData] = useState<any>(null)
  const [loadingPublisher, setLoadingPublisher] = useState(false)
  const [isModeratingDeal, setIsModeratingDeal] = useState(false)

  const {
    document: deal,
    loading: dealLoading,
    error: dealError,
  } = useDocument("deals", id, [id]) as { document: DealType | null; loading: boolean; error: Error | null }

  const { documents: comments, loading: commentsLoading } = useCollection(
    "comments",
    [where("dealId", "==", id), orderBy("createdAt", "desc")],
    [id],
  )

  // Fetch up to 6 related deals to allow filtering out the current one and still have 5
  const { documents: rawRelatedDealsData, loading: relatedLoading } = useCollection(
    "deals",
    deal
      ? [
          where("category", "==", deal.category),
          where("isExpired", "==", false), // Ensure only active deals
          orderBy("createdAt", "desc"), // Order by newest, or choose another metric like voteScore
          limit(6), // Fetch a bit more to filter out the current deal
        ]
      : [],
    [deal?.category], // Removed 'id' from deps here as it's handled by client-side filter
  )

  const relatedDeals = useMemo(() => {
    if (!rawRelatedDealsData || !deal) return []
    return (rawRelatedDealsData as DealType[])
      .filter((relatedDeal) => relatedDeal.id !== deal.id) // Filter out the current deal
      .slice(0, 5) // Take the top 5
  }, [rawRelatedDealsData, deal])

  const { currentVote, voteCount, isVoting, handleVote } = useVotes(id)

  useEffect(() => {
    const fetchPublisherData = async () => {
      if (!deal || !deal.publisherId) return
      setLoadingPublisher(true)
      try {
        const userDocSnap = await getDoc(doc(db, "users", deal.publisherId))
        if (userDocSnap.exists()) {
          setPublisherData(userDocSnap.data())
        }
      } catch (error) {
        console.error("Error fetching publisher data:", error)
      } finally {
        setLoadingPublisher(false)
      }
    }
    if (deal) fetchPublisherData()
  }, [deal])

  useEffect(() => {
    const checkFavoriteStatus = async () => {
      if (!user || !deal) {
        setIsFavorite(false)
        return
      }
      try {
        const q = query(collection(db, "favorites"), where("userId", "==", user.uid), where("dealId", "==", deal.id))
        const snapshot = await getDocs(q)
        if (!snapshot.empty) {
          setIsFavorite(true)
          setFavoriteId(snapshot.docs[0].id)
        } else {
          setIsFavorite(false)
          setFavoriteId(null)
        }
      } catch (error) {
        console.error("Error checking favorite status:", error)
      }
    }
    if (user && deal) checkFavoriteStatus()
  }, [user, deal])

  const formattedDate = deal?.createdAt
    ? formatDistanceToNow(deal.createdAt.toDate(), { addSuffix: true, locale: es })
    : "recientemente"

  const voteScore = voteCount.upvotes - voteCount.downvotes

  const onVote = async (voteType: "up" | "down") => {
    if (deal?.isExpired && !isModerationAllowed) return
    if (!user) {
      setShowLoginModal(true)
      return
    }
    await handleVote(voteType === currentVote ? null : voteType)
  }

  const handleFavorite = async () => {
    if (!user) {
      setShowLoginModal(true)
      return
    }
    if (isFavoriting || !deal) return
    setIsFavoriting(true)
    try {
      if (isFavorite && favoriteId) {
        await deleteDoc(doc(db, "favorites", favoriteId))
        setIsFavorite(false)
        setFavoriteId(null)
      } else if (deal) {
        const docRef = await addDoc(collection(db, "favorites"), {
          userId: user.uid,
          dealId: deal.id,
          dealTitle: deal.title,
          createdAt: serverTimestamp(),
        })
        setIsFavorite(true)
        setFavoriteId(docRef.id)
      }
    } catch (error) {
      console.error("Error favoriting:", error)
      setIsFavorite(!isFavorite)
    } finally {
      setIsFavoriting(false)
    }
  }

  const copyToClipboard = (textToCopy: string, type: "link" | "coupon") => {
    navigator.clipboard
      .writeText(textToCopy)
      .then(() => {
        if (type === "link") {
          setLinkCopied(true)
          toast({ title: "Enlace copiado", description: "Enlace del chollo copiado al portapapeles." })
          setTimeout(() => setLinkCopied(false), 2000)
        } else if (type === "coupon") {
          setCouponCopied(true)
          toast({ title: "Cupón Copiado", description: `El cupón "${textToCopy}" ha sido copiado.` })
          setTimeout(() => setCouponCopied(false), 2000)
        }
      })
      .catch((err) => {
        console.error(`Error copying ${type}:`, err)
        toast({ title: "Error al Copiar", description: `No se pudo copiar el ${type}.`, variant: "destructive" })
      })
  }

  const shareViaWebShare = () => {
    if (navigator.share && deal) {
      navigator
        .share({ title: deal.title, text: deal.description, url: window.location.href })
        .catch((error) => console.error("Error sharing:", error))
    }
  }

  const getShareUrls = () => {
    if (!deal) return {}
    const currentUrl = encodeURIComponent(window.location.href)
    const title = encodeURIComponent(deal.title)
    const description = encodeURIComponent(deal.description || "")
    return {
      twitter: `https://twitter.com/intent/tweet?text=${title}&url=${currentUrl}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${currentUrl}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${currentUrl}`,
      whatsapp: `https://wa.me/?text=${title}%20${currentUrl}`,
      email: `mailto:?subject=${title}&body=${description}%0A%0A${currentUrl}`,
    }
  }
  const shareUrls = getShareUrls()

  const handleMarkAsExpired = async () => {
    if (!deal || !user || !isModerationAllowed) return
    setIsModeratingDeal(true)
    try {
      await updateDoc(doc(db, "deals", id), { isExpired: true, moderatedBy: user.uid, moderatedAt: serverTimestamp() })
      await addDoc(collection(db, "moderationLogs"), {
        dealId: id,
        dealTitle: deal.title,
        action: "marked-expired",
        moderatorId: user.uid,
        moderatorName: user.displayName || "Unknown",
        reason: "Deal marked as expired by moderator",
        createdAt: serverTimestamp(),
      })
      toast({ title: "Chollo marcado como caducado" })
    } catch (error) {
      console.error("Error marking deal as expired:", error)
      toast({ title: "Error", description: "No se pudo marcar el chollo como caducado", variant: "destructive" })
    } finally {
      setIsModeratingDeal(false)
    }
  }

  const handleUnmarkAsExpired = async () => {
    if (!deal || !user || !isModerationAllowed) return
    setIsModeratingDeal(true)
    try {
      await updateDoc(doc(db, "deals", id), { isExpired: false, moderatedBy: user.uid, moderatedAt: serverTimestamp() })
      await addDoc(collection(db, "moderationLogs"), {
        dealId: id,
        dealTitle: deal.title,
        action: "unmarked-expired",
        moderatorId: user.uid,
        moderatorName: user.displayName || "Unknown",
        reason: "Deal unmarked as expired by moderator",
        createdAt: serverTimestamp(),
      })
      toast({ title: "Chollo reactivado" })
    } catch (error) {
      console.error("Error unmarking deal as expired:", error)
      toast({ title: "Error", description: "No se pudo reactivar el chollo", variant: "destructive" })
    } finally {
      setIsModeratingDeal(false)
    }
  }

  const handleDeleteDeal = async () => {
    if (!deal || !user || !isModerationAllowed) return
    setIsModeratingDeal(true)
    try {
      await addDoc(collection(db, "moderationLogs"), {
        dealId: id,
        dealTitle: deal.title,
        action: "deleted",
        moderatorId: user.uid,
        moderatorName: user.displayName || "Unknown",
        reason: "Deal deleted by moderator",
        createdAt: serverTimestamp(),
      })
      await deleteDoc(doc(db, "deals", id))
      toast({ title: "Chollo eliminado" })
      window.location.href = "/" // Consider using Next.js router for navigation
    } catch (error) {
      console.error("Error deleting deal:", error)
      toast({ title: "Error", description: "No se pudo eliminar el chollo", variant: "destructive" })
    } finally {
      setIsModeratingDeal(false)
      setShowDeleteDialog(false)
    }
  }

  if (dealLoading)
    return (
      <div className="container py-8 text-center">
        <p>Cargando chollo...</p>
      </div>
    )
  if (dealError || !deal)
    return (
      <div className="container py-8 text-center">
        <p className="text-red-500">Error al cargar el chollo.</p>
      </div>
    )

  return (
    <>
      <div className={`container py-8 ${deal.isExpired && !isModerationAllowed ? "opacity-70 grayscale" : ""}`}>
        {deal.isExpired && (
          <div className="mb-6 rounded-lg border border-orange-500 bg-orange-50 p-4 text-orange-800 dark:bg-orange-950 dark:text-orange-300">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              <h2 className="text-lg font-semibold">Este chollo ha caducado</h2>
            </div>
            <p className="mt-1">Este chollo ya no está disponible o ha expirado.</p>
          </div>
        )}

        <div className="grid gap-8 md:grid-cols-3">
          <div className="md:col-span-2">
            {/* This div will now always be a row, keeping votes to the side of content */}
            <div className="flex items-start gap-4">
              <div className="flex flex-col items-center gap-1 flex-shrink-0">
                <Button
                  variant={currentVote === "up" ? "default" : "ghost"}
                  size="icon"
                  className={`h-10 w-10 rounded-full ${currentVote === "up" ? "bg-green-500 hover:bg-green-600 text-white" : ""} ${deal.isExpired && !isModerationAllowed ? "opacity-50 cursor-not-allowed" : ""}`}
                  onClick={() => onVote("up")}
                  disabled={isVoting || (deal.isExpired && !isModerationAllowed)}
                >
                  <ChevronUp className="h-6 w-6" />
                  <span className="sr-only">Votar positivo</span>
                </Button>
                <span className="text-lg font-medium">{voteScore}</span>
                <Button
                  variant={currentVote === "down" ? "default" : "ghost"}
                  size="icon"
                  className={`h-10 w-10 rounded-full ${currentVote === "down" ? "bg-red-500 hover:bg-red-600 text-white" : ""} ${deal.isExpired && !isModerationAllowed ? "opacity-50 cursor-not-allowed" : ""}`}
                  onClick={() => onVote("down")}
                  disabled={isVoting || (deal.isExpired && !isModerationAllowed)}
                >
                  <ChevronDown className="h-6 w-6" />
                  <span className="sr-only">Votar negativo</span>
                </Button>
              </div>
              <div className="flex-1 min-w-0">
                {" "}
                {/* Added min-w-0 here */}
                <h1 className="text-2xl font-bold md:text-3xl break-words">{deal.title}</h1>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <Badge variant="secondary" className="bg-primary text-primary-foreground">
                    {deal.discountPercentage}% DESCUENTO
                  </Badge>
                  <Link href={`/categoria/${encodeURIComponent(deal.category)}`} passHref>
                    <Badge
                      variant="outline"
                      className="hover:bg-accent hover:text-accent-foreground cursor-pointer transition-colors"
                    >
                      {deal.category}
                    </Badge>
                  </Link>
                  {deal.isExpired && (
                    <Badge variant="outline" className="border-orange-500 text-orange-500">
                      <Clock className="mr-1 h-3 w-3" /> Caducado
                    </Badge>
                  )}
                  <div className="flex flex-wrap items-center text-sm text-muted-foreground">
                    {" "}
                    {/* Added flex-wrap */}
                    <span>Publicado por </span>
                    <Link
                      href={`/perfil/${deal.publisherId}`}
                      className="mx-1 inline-flex items-center hover:text-primary hover:underline"
                    >
                      {publisherData?.photoURL ? (
                        <Avatar className="mr-1 h-5 w-5">
                          <AvatarImage
                            src={publisherData.photoURL || "/placeholder.svg"}
                            alt={deal.publisherName || ""}
                          />
                          <AvatarFallback>{(deal.publisherName || "U").charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                      ) : (
                        <User className="mr-1 h-4 w-4" />
                      )}
                      {deal.publisherName || "Usuario Anónimo"}
                    </Link>
                    <span>{formattedDate}</span>
                  </div>
                </div>
                <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-2 flex-wrap">
                    {" "}
                    {/* Added flex-wrap */}
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1"
                      onClick={handleFavorite}
                      disabled={isFavoriting}
                    >
                      <Star className={`h-4 w-4 ${isFavorite ? "fill-yellow-400 text-yellow-400" : ""}`} />
                      <span>{isFavorite ? "Favorito" : "Añadir a favoritos"}</span>
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-1">
                          <Share2 className="h-4 w-4" />
                          <span>Compartir</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        {navigator.share && (
                          <>
                            <DropdownMenuItem onClick={shareViaWebShare}>
                              <Share2 className="mr-2 h-4 w-4" />
                              <span>Compartir con dispositivo</span>
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                          </>
                        )}
                        <DropdownMenuItem onClick={() => window.open(shareUrls.twitter, "_blank")}>
                          <Twitter className="mr-2 h-4 w-4" />
                          <span>Twitter</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => window.open(shareUrls.facebook, "_blank")}>
                          <Facebook className="mr-2 h-4 w-4" />
                          <span>Facebook</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => window.open(shareUrls.linkedin, "_blank")}>
                          <Linkedin className="mr-2 h-4 w-4" />
                          <span>LinkedIn</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => window.open(shareUrls.whatsapp, "_blank")}>
                          <MessageSquare className="mr-2 h-4 w-4" />
                          <span>WhatsApp</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => window.open(shareUrls.email, "_blank")}>
                          <Mail className="mr-2 h-4 w-4" />
                          <span>Email</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => copyToClipboard(window.location.href, "link")}>
                          {linkCopied ? (
                            <Check className="mr-2 h-4 w-4 text-green-500" />
                          ) : (
                            <Copy className="mr-2 h-4 w-4" />
                          )}
                          <span>{linkCopied ? "¡Enlace Copiado!" : "Copiar enlace"}</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  {isModerationAllowed ? (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1 text-muted-foreground hover:text-amber-600"
                          disabled={isModeratingDeal}
                        >
                          <ShieldAlert className="h-4 w-4" />
                          <span>Moderación</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        {deal.isExpired ? (
                          <DropdownMenuItem
                            onClick={handleUnmarkAsExpired}
                            disabled={isModeratingDeal}
                            className="text-green-600 focus:text-green-600"
                          >
                            <RefreshCw className="mr-2 h-4 w-4" />
                            <span>Reactivar Chollo</span>
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem onClick={handleMarkAsExpired} disabled={isModeratingDeal}>
                            <Clock className="mr-2 h-4 w-4" />
                            <span>Marcar Caducado</span>
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => setShowDeleteDialog(true)}
                          className="text-destructive focus:text-destructive"
                          disabled={isModeratingDeal}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Eliminar Chollo</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : (
                    !deal.isExpired && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1 text-muted-foreground hover:text-destructive"
                        onClick={() => setShowReportModal(true)}
                      >
                        <Flag className="h-4 w-4" />
                        <span>Reportar</span>
                      </Button>
                    )
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6">
              <div className="relative aspect-video overflow-hidden rounded-lg">
                <Image
                  src={deal.imageUrl || "/placeholder.svg?height=400&width=800&query=deal+image"}
                  alt={deal.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 66vw"
                  priority
                />
                {deal.isExpired && !isModerationAllowed && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                    <Badge
                      variant="outline"
                      className="border-2 border-orange-500 bg-black/70 px-3 py-1.5 text-lg font-semibold text-orange-500"
                    >
                      <Clock className="mr-1 h-4 w-4" /> CADUCADO
                    </Badge>
                  </div>
                )}
              </div>

              <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-baseline sm:justify-between">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-primary">{formatPriceForDisplay(deal.discountedPrice)}</span>
                  {deal.originalPrice > deal.discountedPrice && (
                    <span className="text-lg text-muted-foreground line-through">
                      {formatPriceForDisplay(deal.originalPrice)}
                    </span>
                  )}
                </div>
                <a
                  href={deal.dealUrl || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center justify-center gap-1 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 w-full sm:w-auto ${deal.isExpired && !isModerationAllowed ? "pointer-events-none opacity-50" : ""}`}
                >
                  <span>Conseguir Chollo</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
              </div>

              {deal.couponCode && (
                <div className="mt-4 rounded-md border border-dashed border-primary bg-primary/5 p-4">
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="text-center sm:text-left min-w-0">
                      {" "}
                      {/* Added min-w-0 */}
                      <Label htmlFor="couponDisplay" className="text-sm font-medium text-primary flex items-center">
                        <TicketPercent className="h-4 w-4 mr-1 inline-block" />
                        Código de Cupón:
                      </Label>
                      <p id="couponDisplay" className="text-xl font-bold text-primary tracking-wider break-all">
                        {deal.couponCode}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(deal.couponCode!, "coupon")}
                      className="gap-1 shrink-0 w-full sm:w-auto"
                    >
                      {couponCopied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                      <span>{couponCopied ? "¡Copiado!" : "Copiar Cupón"}</span>
                    </Button>
                  </div>
                </div>
              )}

              <Separator className="my-6" />
              <div className="prose max-w-none dark:prose-invert">
                <h2 className="text-xl font-semibold">Descripción</h2>
                <p className="mt-2 break-words">{deal.description}</p> {/* Added break-words */}
                {deal.fullDescription && (
                  <div className="mt-4 prose-sm sm:prose-base max-w-none dark:prose-invert break-words">
                    <div dangerouslySetInnerHTML={{ __html: deal.fullDescription }} />
                  </div>
                )}
              </div>
              <CommentSection
                dealId={id}
                comments={comments as CommentType[]}
                isDisabled={!!(deal.isExpired && !isModerationAllowed)}
              />
            </div>
          </div>

          <div className="w-full">
            {" "}
            {/* Ensure sidebar takes full width of its column */}
            <Card className="w-full">
              <CardContent className="p-4">
                <h3 className="font-semibold">Chollos Relacionados</h3>
                {relatedLoading ? (
                  <p className="mt-4 text-center text-sm">Cargando...</p>
                ) : relatedDeals.length > 0 ? (
                  <div className="mt-4 space-y-4">
                    {relatedDeals.map((related: DealType) => (
                      <div key={related.id} className="border-b pb-4 last:border-0 last:pb-0">
                        <Link href={`/chollo/${related.id}`} className="block group">
                          <div className="relative aspect-video overflow-hidden rounded-md">
                            <Image
                              src={related.imageUrl || "/placeholder.svg?height=200&width=400&query=related+deal"}
                              alt={related.title}
                              fill
                              className="object-cover group-hover:scale-105 transition-transform"
                              sizes="(max-width: 768px) 100vw, 33vw"
                            />
                            {related.isExpired && ( // Check if related deal is expired
                              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                                <Badge
                                  variant="outline"
                                  className="border border-orange-500 bg-black/70 px-2 py-0.5 text-xs font-semibold text-orange-500"
                                >
                                  CADUCADO
                                </Badge>
                              </div>
                            )}
                          </div>
                          <h4 className="mt-2 font-medium line-clamp-2 hover:underline break-words">{related.title}</h4>{" "}
                          {/* Added break-words */}
                        </Link>
                        <div className="mt-1 flex items-baseline gap-2">
                          <span className="font-bold text-primary">
                            {formatPriceForDisplay(related.discountedPrice)}
                          </span>
                          {related.originalPrice > related.discountedPrice && (
                            <span className="text-sm text-muted-foreground line-through">
                              {formatPriceForDisplay(related.originalPrice)}
                            </span>
                          )}
                        </div>
                        <div className="mt-1 flex items-center text-xs text-muted-foreground flex-wrap">
                          {" "}
                          {/* Added flex-wrap */}
                          <span>Publicado por </span>
                          <Link
                            href={`/perfil/${related.publisherId}`}
                            className="ml-1 hover:text-primary hover:underline"
                          >
                            {related.publisherName || "Usuario Anónimo"}
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="mt-4 text-center text-sm">No hay chollos relacionados en esta categoría.</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onSignupClick={() => {
          setShowLoginModal(false)
          setShowSignupModal(true)
        }}
      />
      <SignupModal
        isOpen={showSignupModal}
        onClose={() => setShowSignupModal(false)}
        onLoginClick={() => {
          setShowSignupModal(false)
          setShowLoginModal(true)
        }}
      />
      {deal && (
        <ReportModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          dealId={id}
          dealTitle={deal.title}
        />
      )}
      {deal && (
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción eliminará permanentemente el chollo "{deal.title}" y no se puede deshacer.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isModeratingDeal}>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteDeal}
                disabled={isModeratingDeal}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {isModeratingDeal ? "Eliminando..." : "Eliminar Chollo"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </>
  )
}
