export default function Loading() {
  return (
    <div className="container py-8 mx-auto px-4 text-center">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Cargando Chollos...</h1>
      <p className="text-muted-foreground">Buscando las mejores ofertas en la categoría seleccionada.</p>
      {/* Optional: Add skeleton loaders for deal cards for a better UX */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 md:gap-6 lg:grid-cols-3 xl:grid-cols-4">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="rounded-lg border bg-card text-card-foreground shadow-sm animate-pulse">
            <div className="aspect-[16/10] bg-muted rounded-t-lg"></div>
            <div className="p-4 space-y-3">
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-3 bg-muted rounded w-1/2"></div>
              <div className="h-6 bg-muted rounded w-1/3"></div>
            </div>
            <div className="border-t p-3">
              <div className="h-3 bg-muted rounded w-full"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
