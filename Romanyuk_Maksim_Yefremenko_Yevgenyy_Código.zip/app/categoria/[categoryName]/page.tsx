"use client"

import { useMemo } from "react"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import { useParams } from "next/navigation"
import { type QueryConstraint, where, orderBy, limit as firestoreLimit } from "firebase/firestore"
import { useCollection } from "@/hooks/use-firestore"
import type { Deal } from "@/types"
import { DealCard } from "@/components/deals/deal-card"
import { Button } from "@/components/ui/button"
import { CategorySorter, type CategorySortOption } from "@/components/deals/category-sorter"
import { NoData } from "@/components/ui/no-data"
import { Skeleton } from "@/components/ui/skeleton"

const Card = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={`border rounded-lg shadow-sm ${className}`}>{children}</div>
)
const CardContent = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={`${className}`}>{children}</div>
)

export default function CategoryPage() {
  const params = useParams()
  const categoryNameParam = params.categoryName as string | string[] | undefined

  const [categoryName, setCategoryName] = useState<string | null>(null)
  const [sortOption, setSortOption] = useState<CategorySortOption>("newest")
  const [currentLimit, setCurrentLimit] = useState(12) // For Firestore fetching limit
  const [allFetchedDeals, setAllFetchedDeals] = useState<Deal[]>([]) // Store all deals fetched so far for client-side sort
  const [displayedDeals, setDisplayedDeals] = useState<Deal[]>([]) // Deals to actually render

  useEffect(() => {
    let activeCategory: string | null = null
    if (typeof categoryNameParam === "string") {
      activeCategory = decodeURIComponent(categoryNameParam)
    } else if (Array.isArray(categoryNameParam) && categoryNameParam.length > 0) {
      activeCategory = decodeURIComponent(categoryNameParam[0])
    }
    setCategoryName(activeCategory)
    setSortOption("newest")
    setCurrentLimit(12)
    setAllFetchedDeals([])
    setDisplayedDeals([])
  }, [categoryNameParam])

  // Firestore query constraints - primarily for fetching, not for all sorting types
  const firestoreQueryConstraints = useMemo(() => {
    if (!categoryName) return []
    const constraints: QueryConstraint[] = [where("category", "==", categoryName), where("isExpired", "==", false)]
    // For "newest", let Firestore do the initial sort. For others, we sort client-side.
    if (sortOption === "newest") {
      constraints.push(orderBy("createdAt", "desc"))
    }
    // We always apply a limit for fetching from Firestore
    constraints.push(firestoreLimit(currentLimit))
    return constraints
  }, [categoryName, sortOption, currentLimit]) // Removed sortOption dependency for client-sorts

  const {
    documents: newBatchFromFirestore,
    loading,
    error,
  } = useCollection("deals", firestoreQueryConstraints, [
    categoryName,
    sortOption === "newest" ? "newest" : "other",
    currentLimit,
  ]) // Change dependency to re-trigger fetch correctly

  // Accumulate all fetched deals
  useEffect(() => {
    if (newBatchFromFirestore) {
      if (currentLimit === 12) {
        // First fetch for this category/limit reset
        setAllFetchedDeals(newBatchFromFirestore as Deal[])
      } else {
        // Subsequent fetches ("Load More")
        setAllFetchedDeals((prevAllDeals) => {
          const existingDealIds = new Set(prevAllDeals.map((d) => d.id))
          const uniqueNewDeals = (newBatchFromFirestore as Deal[]).filter((d) => !existingDealIds.has(d.id))
          return [...prevAllDeals, ...uniqueNewDeals]
        })
      }
    }
  }, [newBatchFromFirestore, currentLimit])

  // Client-side sorting and creating the display list
  useEffect(() => {
    const sortedDeals = [...allFetchedDeals] // Create a mutable copy

    // Handle missing fields by defaulting to 0 for sorting purposes
    const getNumericField = (deal: Deal, field: keyof Deal) => {
      const value = deal[field]
      return typeof value === "number" ? value : 0
    }

    switch (sortOption) {
      case "popular":
        sortedDeals.sort((a, b) => getNumericField(b, "clickCount") - getNumericField(a, "clickCount"))
        break
      case "mostVoted":
        sortedDeals.sort((a, b) => getNumericField(b, "voteScore") - getNumericField(a, "voteScore"))
        break
      case "mostCommented":
        sortedDeals.sort((a, b) => getNumericField(b, "commentCount") - getNumericField(a, "commentCount"))
        break
      case "newest":
        // If sortOption is "newest", Firestore already sorted.
        // If allFetchedDeals was populated by a non-"newest" Firestore query, we might need to re-sort by createdAt here.
        // However, our firestoreQueryConstraints already handles orderBy("createdAt") for "newest".
        // If switching from another sort to "newest", allFetchedDeals might not be sorted by createdAt.
        // To be safe, if sortOption is "newest" and allFetchedDeals might not be sorted by createdAt:
        if (
          !firestoreQueryConstraints.some(
            (c) => c.type === "orderBy" && (c as any)._field.segments.join("/") === "createdAt",
          )
        ) {
          sortedDeals.sort((a, b) => {
            const timeA = a.createdAt?.toMillis() || 0
            const timeB = b.createdAt?.toMillis() || 0
            return timeB - timeA
          })
        }
        break
    }
    setDisplayedDeals(sortedDeals)
  }, [allFetchedDeals, sortOption, firestoreQueryConstraints])

  const handleSortChange = useCallback((newSortOption: CategorySortOption) => {
    setSortOption(newSortOption)
    // When sort changes, we display from the currently fetched `allFetchedDeals`.
    // We don't reset currentLimit or allFetchedDeals unless we want to re-fetch from Firestore
    // For pure client-side sort of existing data, only sortOption changes.
    // If "newest" is selected, we might want to re-fetch with Firestore's orderBy.
    if (newSortOption === "newest") {
      setCurrentLimit(12) // Reset limit to re-fetch sorted by "newest" from Firestore
      setAllFetchedDeals([]) // Clear to force re-fetch
    }
  }, [])

  const loadMoreDeals = () => {
    // This will trigger useCollection to fetch the next batch based on currentLimit
    setCurrentLimit((prev) => prev + 12)
  }

  const canLoadMore = !loading && newBatchFromFirestore && newBatchFromFirestore.length === 12
  const isLoadingDisplay = loading && displayedDeals.length === 0

  if (!categoryName && !loading && !error) {
    return <div className="container py-8 text-center">Cargando categoría...</div>
  }
  if (!categoryName && error) {
    return <div className="container py-8 text-center">Error al cargar la categoría.</div>
  }

  return (
    <div className="container py-8 mx-auto px-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h1 className="text-2xl md:text-3xl font-bold">
          Chollos en: <span className="text-primary">{categoryName || ""}</span>
        </h1>
        {categoryName && <CategorySorter onSortChange={handleSortChange} currentSort={sortOption} />}
      </div>

      {isLoadingDisplay && (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 md:gap-6 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <Card key={index} className="overflow-hidden">
              {" "}
              <Skeleton className="h-48 w-full" />{" "}
              <CardContent className="p-4">
                {" "}
                <Skeleton className="h-4 w-3/4 mb-2" /> <Skeleton className="h-4 w-1/2 mb-4" />{" "}
                <Skeleton className="h-8 w-1/3" />{" "}
              </CardContent>{" "}
            </Card>
          ))}
        </div>
      )}
      {error && (
        <div className="mt-8 text-center">
          {" "}
          <p className="text-red-500">Error al cargar los chollos: {error.message || "Error desconocido"}.</p>{" "}
        </div>
      )}
      {!isLoadingDisplay && !error && displayedDeals.length === 0 && categoryName && (
        <NoData message={`No se encontraron chollos activos en la categoría "${categoryName}".`} />
      )}
      {displayedDeals.length > 0 && (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 md:gap-6 lg:grid-cols-3 xl:grid-cols-4">
          {" "}
          {displayedDeals.map((deal: Deal) => (
            <DealCard key={deal.id} deal={deal} />
          ))}{" "}
        </div>
      )}
      {canLoadMore && (
        <div className="mt-8 flex justify-center">
          {" "}
          <Button onClick={loadMoreDeals} variant="outline" disabled={loading}>
            {" "}
            {loading ? "Cargando..." : "Cargar Más"}{" "}
          </Button>{" "}
        </div>
      )}
    </div>
  )
}
