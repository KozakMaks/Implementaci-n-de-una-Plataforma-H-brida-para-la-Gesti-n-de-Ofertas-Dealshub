// Optional: Create this file if you want a custom offline fallback page
// Remember to uncomment the 'document: "/offline"' line in next.config.mjs
import { WifiOff } from "lucide-react"

export default function OfflinePage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] text-center p-4">
      <WifiOff size={64} className="text-destructive mb-4" />
      <h1 className="text-3xl font-bold mb-2">Estás desconectado</h1>
      <p className="text-lg text-muted-foreground mb-4">
        Parece que no tienes conexión a internet. Por favor, revisa tu conexión e inténtalo de nuevo.
      </p>
      <p className="text-sm text-muted-foreground">
        Es posible que algunas páginas que hayas visitado anteriormente estén disponibles sin conexión.
      </p>
    </div>
  )
}
