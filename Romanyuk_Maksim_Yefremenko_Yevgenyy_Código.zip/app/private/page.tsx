"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { useChat } from "@/hooks/use-chat"
import { useMobile } from "@/hooks/use-mobile"
import { Card, CardContent } from "@/components/ui/card"
import { LoginModal } from "@/components/auth/login-modal"
import { SignupModal } from "@/components/auth/signup-modal"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { ChatRequests } from "@/components/chat/chat-requests"
import { ConversationList } from "@/components/chat/conversation-list"
import { ChatInterface } from "@/components/chat/chat-interface"
import { NewChat } from "@/components/chat/new-chat"

export default function PrivateMessages() {
  const { user } = useAuth()
  const { conversations, chatRequests, loading } = useChat()
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showSignupModal, setShowSignupModal] = useState(false)
  const isMobile = useMobile()

  useEffect(() => {
    if (!isMobile && conversations.length > 0 && !selectedConversationId) {
      setSelectedConversationId(conversations[0].id)
    }
  }, [conversations, selectedConversationId, isMobile])

  const selectedConversation = conversations.find((conv) => conv.id === selectedConversationId)

  if (!user) {
    return (
      <div className="container flex min-h-[calc(100vh-80px)] items-center justify-center py-16">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center gap-4 p-6">
            <h2 className="text-xl font-semibold">Inicia sesión para acceder a los mensajes</h2>
            <p className="text-center text-muted-foreground">
              Necesitas iniciar sesión para ver y enviar mensajes privados.
            </p>
            <div className="flex gap-4">
              <Button onClick={() => setShowLoginModal(true)}>Iniciar Sesión</Button>
              <Button variant="outline" onClick={() => setShowSignupModal(true)}>
                Registrarse
              </Button>
            </div>
          </CardContent>
        </Card>
        <LoginModal
          isOpen={showLoginModal}
          onClose={() => setShowLoginModal(false)}
          onSignupClick={() => {
            setShowLoginModal(false)
            setShowSignupModal(true)
          }}
        />
        <SignupModal
          isOpen={showSignupModal}
          onClose={() => setShowSignupModal(false)}
          onLoginClick={() => {
            setShowSignupModal(false)
            setShowLoginModal(true)
          }}
        />
      </div>
    )
  }

  if (isMobile) {
    if (selectedConversationId && selectedConversation) {
      return (
        // Changed h-screen to h-full
        // The parent <main> in layout.tsx has pt-16, so h-full here will respect that.
        <div className="h-full flex flex-col bg-background">
          <ChatInterface conversation={selectedConversation} onBack={() => setSelectedConversationId(null)} />
        </div>
      )
    } else {
      // Mobile: Show ConversationList, NewChat, ChatRequests
      // This container also needs to respect the main layout's padding.
      // Using h-full here ensures it tries to fill the parent <main> tag's height.
      return (
        <div className="container py-6 flex flex-col h-full">
          <div className="mb-6 flex items-center justify-between">
            <h1 className="text-2xl font-bold">Mensajes</h1>
            <NewChat onChatCreated={(conversationId) => setSelectedConversationId(conversationId)} />
          </div>
          {chatRequests.length > 0 && (
            <div className="mb-4">
              <ChatRequests onAccept={(conversationId) => setSelectedConversationId(conversationId)} />
            </div>
          )}
          <div className="flex-grow overflow-y-auto">
            {loading ? (
              <div className="flex h-full items-center justify-center p-4">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : conversations.length > 0 ? (
              <Card>
                <CardContent className="p-0">
                  <ConversationList
                    conversations={conversations}
                    selectedId={selectedConversationId}
                    onSelect={(id) => setSelectedConversationId(id)}
                  />
                </CardContent>
              </Card>
            ) : (
              <div className="flex h-full flex-col items-center justify-center p-4 text-center">
                <p className="text-xl font-bold">No hay conversaciones todavía</p>
                <p className="mt-2 text-sm text-muted-foreground">
                  Inicia un nuevo chat o espera a que alguien te envíe un mensaje.
                </p>
              </div>
            )}
          </div>
        </div>
      )
    }
  }

  // Desktop View (md and larger)
  return (
    <div className="container py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Mensajes</h1>
        <NewChat onChatCreated={(conversationId) => setSelectedConversationId(conversationId)} />
      </div>

      {chatRequests.length > 0 && (
        <div className="mb-4">
          <ChatRequests onAccept={(conversationId) => setSelectedConversationId(conversationId)} />
        </div>
      )}

      <div className="grid h-[calc(100vh-15rem)] gap-6 md:grid-cols-3 lg:grid-cols-[1fr_2fr]">
        <Card className="flex flex-col overflow-hidden">
          <CardContent className="flex-grow p-0 overflow-y-auto">
            {loading ? (
              <div className="flex h-full items-center justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : conversations.length > 0 ? (
              <ConversationList
                conversations={conversations}
                selectedId={selectedConversationId}
                onSelect={setSelectedConversationId}
              />
            ) : (
              <div className="flex h-full flex-col items-center justify-center p-4 text-center">
                <p className="text-xl font-bold">No hay conversaciones todavía</p>
                <p className="mt-2 text-sm text-muted-foreground">
                  Inicia un nuevo chat o espera a que alguien te envíe un mensaje.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        <Card className="flex flex-col overflow-hidden">
          {selectedConversation ? (
            <ChatInterface conversation={selectedConversation} />
          ) : (
            <div className="flex h-full flex-col items-center justify-center p-4 text-center">
              <p className="text-muted-foreground">Selecciona una conversación para empezar a chatear</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
