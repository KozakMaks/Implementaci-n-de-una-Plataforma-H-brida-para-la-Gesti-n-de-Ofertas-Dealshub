// Ensure you have firebase imported or use the correct Timestamp type
// import firebase from 'firebase/compat/app'; // Or the v9 equivalent
// For example, if using Firestore v9 modular SDK:
import type { Timestamp } from "firebase/firestore"

export interface User {
  uid: string
  email?: string | null
  displayName?: string | null
  photoURL?: string | null
  role?: "user" | "moderator" | "admin"
  createdAt?: Timestamp
  bio?: string
  // ... any other user fields
}

export interface Deal {
  id: string
  title: string
  description: string
  fullDescription?: string // Keep this if you use it
  imageUrl?: string // Assuming it's optional
  originalPrice: number
  discountedPrice: number
  discountPercentage: number // Added this, assuming it's calculated
  category: string
  dealUrl: string // Renamed from 'url' for clarity
  store?: string
  tags?: string[]
  publisherId: string // Renamed from userId for clarity
  publisherName?: string // Renamed from userName
  // userPhotoURL?: string | null; // publisherPhotoURL would be more consistent if needed
  createdAt: Timestamp | string // Can be string after sanitization
  updatedAt?: Timestamp | string // Can be string after sanitization
  upvotes: number // Assuming you have these
  downvotes: number // Assuming you have these
  commentCount: number
  isHot?: boolean
  isExpired?: boolean
  couponCode?: string // New field for coupon code
  moderatedAt?: Timestamp | string // Can be string after sanitization
  moderatedBy?: string
  // Fields for sorting
  voteScore?: number // upvotes - downvotes
  clickCount?: number // tracks views/clicks
}

export interface Comment {
  id: string
  dealId: string
  userId: string
  userName?: string
  userPhotoURL?: string | null
  content: string
  parentId: string | null
  createdAt: Timestamp // Assuming it's always a Timestamp from Firestore
  replies?: Comment[]
  status?: "visible" | "deleted_by_moderator" | "pending_review" // New status field
  likes: number // New field for likes
  dislikes: number // New field for dislikes
}

export interface Vote {
  dealId: string
  userId: string
  voteType: "up" | "down" // Simplified from "upvote" | "downvote"
  createdAt: Timestamp
}

// New interface for comment votes
export interface CommentVote {
  id?: string // Firestore document ID
  commentId: string
  userId: string
  voteType: "like" | "dislike"
  createdAt: Timestamp
}

export interface Favorite {
  id: string // Firestore document ID
  userId: string
  dealId: string
  dealTitle: string // Denormalized for easier display
  createdAt: Timestamp
}

export interface Report {
  id: string // Firestore document ID
  reportedItemId: string // ID of the deal or comment
  itemType: "deal" | "comment"
  reason: string // e.g., "spam", "offensive", "expired_deal"
  comment?: string // Reporter's additional comments
  reporterId: string
  reporterName?: string // Denormalized
  status: "pending" | "resolved" | "dismissed"
  createdAt: Timestamp
  resolvedAt?: Timestamp
  resolvedBy?: string // UID of moderator/admin
  resolution?: "approved" | "removed" | "user_warned" | "no_action_needed" // Example resolutions
  moderatorNotes?: string
}

export interface CommentReport {
  id: string
  commentId: string
  commentContent?: string
  commentAuthorId?: string
  commentAuthorName?: string
  reporterId: string
  reporterName?: string
  createdAt: Timestamp
  status: "pending" | "resolved"
  resolution?: "approved" | "removed"
  resolvedBy?: string
  resolvedAt?: Timestamp
}

// For AI Recommendations page
export interface AiRecommendedDealInfo {
  id: string
  name: string
  score: number
  reason: string
  discountedPrice: number
  originalPrice: number
}

// Chat related types
export interface Conversation {
  id: string
  participants: string[]
  participantsInfo: {
    [key: string]: {
      displayName: string
      photoURL: string | null
    }
  }
  lastMessage?: string
  lastMessageTime?: Timestamp
  unreadCount?: { [key: string]: number }
  createdAt: Timestamp
  updatedAt: Timestamp
}

export interface Message {
  id: string
  conversationId: string
  senderId: string
  receiverId: string
  content: string
  imageUrl?: string // New field for image URL
  createdAt: Timestamp
  read: boolean
}

export interface ChatRequest {
  id: string
  senderId: string
  senderName: string
  senderPhotoURL: string | null
  receiverId: string
  message: string
  status: "pending" | "accepted" | "declined"
  createdAt: Timestamp
}

// For AI Search Module
export interface SearchParameters {
  mainProductTerm: string
  alternativeTerms?: string[]
  expandedSemanticTerms?: string[]
  searchKeywords?: string[]
  priceRange?: { min?: number; max?: number }
  userPreferences?: string[]
}

// For AI Analysis Module
export interface AnalysisModuleDeal {
  id: string
  name: string
  score: number
  reason: string
  discountedPrice: number
  originalPrice: number
}

export interface AnalysisModuleOutput {
  selected: AnalysisModuleDeal[]
}

// For AI Response Module
export interface ResponseModuleInput {
  userQuery: string
  selectedDeals: AnalysisModuleDeal[]
  analysisContext?: string
  userWantsGoodPrice?: boolean
  userWantsHighQuality?: boolean
}
